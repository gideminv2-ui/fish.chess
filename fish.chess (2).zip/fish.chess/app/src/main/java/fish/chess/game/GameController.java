package fish.chess.game;

import fish.chess.chess.Board;
import fish.chess.chess.Move;
import fish.chess.chess.Openings;
import fish.chess.chess.Tracker;
import fish.chess.engine.EngineResult;
import fish.chess.engine.UciEngine;
import fish.chess.vision.BoardImage;
import fish.chess.vision.PositionBuilder;
import fish.chess.vision.Recognizer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Главный цикл: читает доску с экрана -> понимает, что сыграл соперник -> спрашивает Stockfish ->
 * делает ход жестами -> проверяет по экрану, что ход состоялся.
 * Работает в отдельном потоке; остановка - прерыванием потока.
 */
public final class GameController {
    /** Сколько подряд опросов экрана с непонятной позицией терпим, прежде чем считать доску заново. */
    private static final int RESYNC_POLLS = 14;

    private final BoardScreen screen;
    private final UciEngine engine;
    private final Recognizer rec;
    private final UiSink ui;

    private Thread worker;
    /** Явный флаг остановки: прерывание потока само по себе может потеряться (его иногда "съедают" библиотеки). */
    private volatile boolean stopRequested = false;
    private volatile Board current;
    /** Ход соперника, замеченный уже во время проверки нашего хода. */
    private Move pendingOpp;

    private static final class Opp {
        final Move move;
        final Board resync;
        final boolean timedOut;

        Opp(Move move, Board resync, boolean timedOut) {
            this.move = move;
            this.resync = resync;
            this.timedOut = timedOut;
        }
    }

    /** Сообщает о результате калибровки (вызывается в рабочем потоке). */
    public interface CalibrationListener {
        void onCalibrated(int good);
    }

    public GameController(BoardScreen screen, UciEngine engine, Recognizer rec, UiSink ui) {
        this.screen = screen;
        this.engine = engine;
        this.rec = rec;
        this.ui = ui;
    }

    public Board currentPosition() {
        return current;
    }

    public synchronized boolean isRunning() {
        return worker != null && worker.isAlive();
    }

    public synchronized boolean start(final GameConfig cfg) {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                runGame(cfg);
            }
        }, "fish-game");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    public synchronized void stop() {
        stopRequested = true;
        if (worker != null) worker.interrupt();
    }

    private void pause(long ms) throws InterruptedException {
        if (stopRequested) throw new InterruptedException();
        Thread.sleep(ms);
        if (stopRequested) throw new InterruptedException();
    }

    /** Калибровка в отдельном потоке. */
    public synchronized boolean calibrate(final GameConfig cfg, final CalibrationListener listener) {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ui.status("Калибровка…");
                    int good = calibrateNow(cfg);
                    if (good == 32) {
                        ui.log("Калибровка: распознано 32 из 32 фигур.");
                    } else if (good >= 0) {
                        ui.log("Калибровка: верно распознано лишь " + good + " из 32 фигур. Проверьте: на доске должна быть начальная расстановка, "
                                + "в настройках верно выбраны цвет и ориентация доски, а сетка лежит на доске целиком. Затем повторите.");
                    }
                    if (good >= 0 && listener != null) listener.onCalibrated(good);
                } catch (InterruptedException e) {
                    ui.log("Калибровка прервана.");
                } finally {
                    ui.status("Готов");
                }
            }
        }, "fish-calibrate");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    /** Автовыравнивание сетки в отдельном потоке (кнопка «Выровнять»). */
    public synchronized boolean align() {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ui.status("Выравниваю сетку…");
                    alignAndReport();
                } catch (InterruptedException e) {
                    ui.log("Прервано.");
                } finally {
                    ui.status("Готов");
                }
            }
        }, "fish-align");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    private boolean alignAndReport() throws InterruptedException {
        boolean ok = screen.alignGrid();
        ui.log(ok ? "Сетка выровнена по доске."
                : "Не удалось найти доску под сеткой: положите сетку на доску (хотя бы приблизительно, в пределах ~половины клетки) и повторите.");
        return ok;
    }

    /** Синхронная калибровка (для потока калибровки и тестов). Возвращает число верных фигур из 32 или -1 при неудаче снимка. */
    public int calibrateNow(GameConfig cfg) throws InterruptedException {
        alignAndReport();
        BoardImage img = screen.capture();
        if (img == null) {
            ui.log("Не удалось сделать снимок экрана. Включена ли служба специальных возможностей fish.chess?");
            return -1;
        }
        return rec.learn(img, cfg.whiteAtBottom);
    }

    // ------------------------------------------------------------------ партия

    private void runGame(GameConfig cfg) {
        ui.running(true);
        try {
            play(cfg);
        } catch (InterruptedException e) {
            ui.log("Остановлено.");
        } catch (RuntimeException e) {
            ui.log("Внутренняя ошибка: " + e);
        } finally {
            engine.close();
            ui.status("Остановлено");
            ui.running(false);
        }
    }

    private void play(GameConfig cfg) throws InterruptedException {
        if (!rec.isCalibrated()) {
            ui.log("Нет калибровки. Расставьте начальную позицию, совместите сетку с доской и нажмите «Калибровка».");
            return;
        }
        ui.status("Запускаю Stockfish…");
        String err = engine.start(cfg.threads, cfg.hashMb, cfg.skill);
        if (err != null) {
            ui.log(err);
            return;
        }
        engine.newGame();

        ui.status("Ищу доску…");
        if (!screen.alignGrid()) ui.log("Не удалось автоматически выровнять сетку - использую её как есть.");
        ui.status("Читаю доску…");
        Recognizer.Detail d = readDetailStable(cfg);
        if (d == null) {
            ui.log("Не удалось сделать снимок экрана. Включена ли служба специальных возможностей fish.chess?");
            return;
        }
        Board pos;
        String startFen = null;
        boolean guessWait = false;
        pendingOpp = null;
        if (Board.initial().cost(d.codes) <= Tracker.CONFIRMED) {
            pos = Board.initial();
            ui.log("Новая партия. Мы играем " + (cfg.ourWhite ? "белыми" : "чёрными") + ".");
        } else {
            boolean whiteToMove;
            String how;
            if (cfg.midgameTurn == 1) {
                whiteToMove = cfg.ourWhite;
                how = "по настройке";
            } else if (cfg.midgameTurn == 2) {
                whiteToMove = !cfg.ourWhite;
                how = "по настройке";
            } else {
                int lm = PositionBuilder.lastMover(d);
                if (lm != 0) {
                    whiteToMove = lm < 0;
                    how = "по подсветке последнего хода";
                } else {
                    whiteToMove = !cfg.ourWhite;
                    guessWait = true;
                    how = "подсветка не найдена";
                }
            }
            PositionBuilder.Built built = PositionBuilder.build(d, whiteToMove);
            if (built.board == null) {
                ui.log("Не удалось определить позицию: " + built.problem + ".");
                return;
            }
            pos = built.board;
            startFen = pos.fen();
            ui.log("Партия продолжается с текущей позиции. Ход " + (pos.whiteToMove ? "белых" : "чёрных") + " (" + how + ").");
        }
        current = pos;
        if (guessWait && pos.whiteToMove != cfg.ourWhite) {
            ui.status("Определяю, чей ход…");
            ui.log("Чей ход, определить не удалось: жду " + Math.max(1, cfg.guessWaitMs / 1000) + " с. Если соперник пойдёт - ход был его, иначе ходим мы.");
            Opp o = waitOpponent(cfg, pos, cfg.guessWaitMs);
            if (o.timedOut) {
                Recognizer.Detail d2 = readDetailStable(cfg);
                PositionBuilder.Built b2 = d2 == null ? null : PositionBuilder.build(d2, cfg.ourWhite);
                if (b2 == null || b2.board == null) {
                    ui.log("Не удалось определить позицию: " + (b2 == null ? "нет снимка экрана" : b2.problem) + ".");
                    return;
                }
                pos = b2.board;
                startFen = pos.fen();
                ui.log("Соперник не ходит - считаю, что ход наш.");
            } else if (o.resync != null) {
                pos = o.resync;
                startFen = pos.fen();
            } else {
                pendingOpp = o.move;
            }
            current = pos;
        }

        List<String> moves = new ArrayList<>();
        Map<String, Integer> seen = new HashMap<>();
        String lastOpening = null;
        Integer expected = null;
        int lastMaterial = Integer.MIN_VALUE;
        boolean repetitionWarned = false;

        while (true) {
            if (stopRequested || Thread.interrupted()) throw new InterruptedException();
            List<Move> legal = pos.legalMoves();
            if (legal.isEmpty()) {
                if (pos.inCheck()) {
                    boolean weWon = pos.whiteToMove != cfg.ourWhite;
                    ui.log(weWon ? "Мат! Мы победили." : "Нам поставили мат.");
                } else {
                    ui.log("Пат - ничья.");
                }
                return;
            }
            if (pos.insufficientMaterial()) {
                ui.log("Ничья: недостаточно материала для мата.");
                return;
            }
            Integer times = seen.get(pos.positionKey());
            times = times == null ? 1 : times + 1;
            seen.put(pos.positionKey(), times);
            if (times >= 3 && !repetitionWarned) {
                repetitionWarned = true;
                ui.log("Позиция повторилась трижды (по правилам это ничья, если площадка засчитает).");
            }

            boolean ourTurn = (pos.whiteToMove == cfg.ourWhite);
            if (ourTurn) {
                ui.status("Думаю…");
                EngineResult res = think(cfg, startFen, moves);
                if (res == null || res.best == null) {
                    ui.log("Stockfish не вернул ход. Остановлено.");
                    return;
                }
                Move mv = pos.parseUci(res.best);
                if (mv == null) {
                    ui.log("Stockfish предложил недопустимый ход " + res.best + ": позиция в программе и на экране разошлась. Остановлено.");
                    return;
                }
                if (expected != null && res.hasScore() && Math.abs(res.score()) < 90000 && Math.abs(expected) < 90000) {
                    int swing = res.score() - expected;
                    if (swing >= 150) {
                        ui.log("   Соперник ошибся: оценка выросла с " + Commentary.signed(expected) + " до " + Commentary.signed(res.score()) + ".");
                    } else if (swing <= -150) {
                        ui.log("   Сильный ответ соперника: оценка упала с " + Commentary.signed(expected) + " до " + Commentary.signed(res.score()) + ".");
                    }
                }
                String san = pos.san(mv, legal);
                Board after = pos.apply(mv);
                ui.log(Commentary.moveLabel(pos) + " мы: " + san + Commentary.flavor(pos, mv, after) + " | " + Commentary.evalText(res));
                String plan = Commentary.pvSan(pos, res.pv, 6);
                if (!plan.isEmpty()) ui.log("   линия: " + plan);

                if (!executeAndVerify(cfg, pos, mv, after)) {
                    ui.log("Не удалось сделать ход " + san + ". Остановлено: проверьте положение сетки, метод хода (нажатие/перетаскивание) и права службы.");
                    return;
                }
                moves.add(mv.uci());
                pos = after;
                current = pos;
                if (res.hasScore()) expected = res.score();
                lastOpening = announceOpening(startFen, moves, lastOpening);
                lastMaterial = announceMaterial(pos, cfg, lastMaterial);
            } else {
                Opp o;
                if (pendingOpp != null) {
                    o = new Opp(pendingOpp, null, false);
                    pendingOpp = null;
                } else {
                    ui.status("Жду ход соперника…");
                    o = waitOpponent(cfg, pos, 0);
                }
                if (o.resync != null) {
                    pos = o.resync;
                    startFen = pos.fen();
                    moves.clear();
                    seen.clear();
                    expected = null;
                    current = pos;
                    ui.log("Синхронизация: позицию считал с экрана заново (ход наш).");
                    continue;
                }
                Move om = o.move;
                String san = pos.san(om);
                Board after = pos.apply(om);
                ui.log(Commentary.moveLabel(pos) + " соперник: " + san + Commentary.flavor(pos, om, after));
                moves.add(om.uci());
                pos = after;
                current = pos;
                lastOpening = announceOpening(startFen, moves, lastOpening);
                lastMaterial = announceMaterial(pos, cfg, lastMaterial);
            }
        }
    }

    private String announceOpening(String startFen, List<String> moves, String last) {
        if (startFen != null || moves.size() > 14) return last;
        String name = Openings.name(moves);
        if (name != null && !name.equals(last)) {
            ui.log("   Дебют: " + name + ".");
            return name;
        }
        return last;
    }

    private int announceMaterial(Board pos, GameConfig cfg, int last) {
        int bal = cfg.ourWhite ? pos.materialBalance() : -pos.materialBalance();
        if (last != Integer.MIN_VALUE && bal != last) ui.log("   " + Commentary.material(bal) + ".");
        return bal;
    }

    private EngineResult think(GameConfig cfg, String startFen, List<String> moves) throws InterruptedException {
        for (int attempt = 0; attempt < 2; attempt++) {
            if (!engine.isAlive()) {
                ui.log("Перезапускаю Stockfish…");
                String err = engine.start(cfg.threads, cfg.hashMb, cfg.skill);
                if (err != null) {
                    ui.log(err);
                    return null;
                }
                engine.newGame();
            }
            EngineResult r = engine.bestMove(startFen, moves, cfg.thinkMs);
            if (r != null) return r;
        }
        return null;
    }

    // ----------------------------------------------------------- чтение экрана

    private int[] captureRecognize(GameConfig cfg) throws InterruptedException {
        if (stopRequested) throw new InterruptedException();
        BoardImage img = screen.capture();
        if (img == null) return null;
        return rec.recognize(img, cfg.whiteAtBottom);
    }

    private static int diff(int[] a, int[] b) {
        int n = 0;
        for (int i = 0; i < 64; i++) if (a[i] != b[i]) n++;
        return n;
    }

    /** Два снимка подряд с паузой, пока они не совпадут (чтобы не поймать анимацию). */
    private Recognizer.Detail readDetailStable(GameConfig cfg) throws InterruptedException {
        Recognizer.Detail prev = null;
        for (int i = 0; i < 8; i++) {
            BoardImage img = screen.capture();
            Recognizer.Detail dd = img == null ? null : rec.recognizeDetailed(img, cfg.whiteAtBottom);
            if (dd != null && prev != null && diff(prev.codes, dd.codes) <= 1) return dd;
            if (dd != null) prev = dd;
            pause(Math.max(1, cfg.stableMs));
        }
        return prev;
    }

    /** Ждёт, пока на экране не появится ход соперника. Если картинка долго необъяснима - считывает позицию заново. */
    private Opp waitOpponent(GameConfig cfg, Board pos, long timeoutMs) throws InterruptedException {
        int unclear = 0, nullReads = 0;
        boolean warned = false;
        long deadline = timeoutMs > 0 ? System.currentTimeMillis() + timeoutMs : Long.MAX_VALUE;
        while (true) {
            pause(Math.max(1, cfg.pollMs));
            if (System.currentTimeMillis() > deadline) return new Opp(null, null, true);
            int[] r = captureRecognize(cfg);
            if (r == null) {
                if (++nullReads == 5) ui.log("Не получается сделать снимок экрана…");
                continue;
            }
            nullReads = 0;
            if (pos.cost(r) <= Tracker.UNCHANGED) {
                unclear = 0;
                warned = false;
                continue;
            }
            Move m1 = Tracker.findMove(pos, r);
            if (m1 != null) {
                pause(Math.max(1, cfg.stableMs));
                int[] r2 = captureRecognize(cfg);
                if (r2 != null && m1.equals(Tracker.findMove(pos, r2))) return new Opp(m1, null, false);
                continue;
            }
            unclear++;
            if (unclear == 8 && !warned) {
                warned = true;
                ui.log("Позиция на экране не совпадает с партией (доска закрыта? идёт анимация? сдвинута сетка?). Если так и останется - считаю позицию заново.");
            }
            if (unclear >= RESYNC_POLLS) {
                Board b = Board.fromRecognition(r, cfg.ourWhite);
                if (b != null) {
                    pause(Math.max(1, cfg.stableMs));
                    int[] r2 = captureRecognize(cfg);
                    if (r2 != null && diff(r, r2) <= 1) return new Opp(null, b, false);
                }
            }
        }
    }

    // ------------------------------------------------------------ ход жестами

    private static int[] cellOf(int sq, boolean whiteAtBottom) {
        int file = sq % 8, rank = sq / 8;
        return new int[]{whiteAtBottom ? file : 7 - file, whiteAtBottom ? 7 - rank : rank};
    }

    private boolean performGesture(GameConfig cfg, Move mv) throws InterruptedException {
        int[] f = cellOf(mv.from, cfg.whiteAtBottom);
        int[] t = cellOf(mv.to, cfg.whiteAtBottom);
        boolean ok;
        if (cfg.dragMode) {
            ok = screen.drag(f[0] + 0.5, f[1] + 0.5, t[0] + 0.5, t[1] + 0.5, 280);
        } else {
            ok = screen.tap(f[0] + 0.5, f[1] + 0.5, 60);
            pause(Math.max(1, cfg.tapGapMs));
            ok &= screen.tap(t[0] + 0.5, t[1] + 0.5, 60);
        }
        if (mv.promo != 0 && cfg.promoTap) {
            pause(Math.max(1, cfg.promoWaitMs));
            int order = "qnrb".indexOf("??nbrq".charAt(mv.promo));
            double dir = (t[1] == 0) ? 1.0 : -1.0;
            screen.tap(t[0] + 0.5, t[1] + 0.5 + dir * order, 60);
        }
        return ok;
    }

    private boolean executeAndVerify(GameConfig cfg, Board pos, Move mv, Board after) throws InterruptedException {
        for (int attempt = 1; attempt <= 3; attempt++) {
            ui.status(attempt == 1 ? "Хожу…" : "Повторяю ход (" + attempt + " из 3)…");
            if (!performGesture(cfg, mv)) {
                ui.log("Жест не выполнен - проверьте, включена ли служба специальных возможностей.");
            }
            int[] last = null;
            long deadline = System.currentTimeMillis() + Math.max(1000, cfg.verifyTotalMs);
            while (System.currentTimeMillis() < deadline) {
                pause(Math.max(1, cfg.verifyMs));
                int[] r = captureRecognize(cfg);
                if (r == null) continue;
                last = r;
                if (Tracker.confirms(pos, after, r)) return true;
                // соперник мог ответить так быстро, что мы уже видим его ход
                Move om = Tracker.findMove(after, r);
                if (om != null) {
                    pause(Math.max(1, cfg.stableMs));
                    int[] r2 = captureRecognize(cfg);
                    if (r2 != null && om.equals(Tracker.findMove(after, r2))) {
                        pendingOpp = om;
                        return true;
                    }
                }
            }
            if (last != null && pos.cost(last) > Tracker.UNCHANGED) {
                ui.log("Экран не совпадает ни с позицией до хода, ни с ожидаемой после - повторять ход небезопасно.");
                return false;
            }
            ui.log("Ход не подтвердился на экране (попытка " + attempt + " из 3).");
        }
        return false;
    }
}
