package fish.chess.chess;

import java.util.ArrayList;
import java.util.List;

/**
 * Шахматная позиция и правила. Фигуры: 0 пусто, +1..+6 белые (P,N,B,R,Q,K), -1..-6 чёрные.
 * Клетка = rank*8 + file (a1=0). Проверено перфт-тестами.
 */
public final class Board {
    public static final int EMPTY = 0, PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
    /** Значение "не распознано" в массиве распознавания. */
    public static final int UNKNOWN = 99;
    public static final int CR_WK = 1, CR_WQ = 2, CR_BK = 4, CR_BQ = 8;

    private static final int[] KNIGHT_D = {1, 2, 2, 1, 2, -1, 1, -2, -1, -2, -2, -1, -2, 1, -1, 2};
    private static final int[] KING_D = {1, 0, 1, 1, 0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1};
    private static final int[] DIAG_D = {1, 1, -1, 1, -1, -1, 1, -1};
    private static final int[] ORTH_D = {1, 0, 0, 1, -1, 0, 0, -1};

    public final int[] sq = new int[64];
    public boolean whiteToMove = true;
    public int castle = 0;
    public int ep = -1;
    public int half = 0;
    public int full = 1;

    public static String squareName(int s) {
        return "" + (char) ('a' + (s % 8)) + (char) ('1' + (s / 8));
    }

    public Board copy() {
        Board b = new Board();
        System.arraycopy(sq, 0, b.sq, 0, 64);
        b.whiteToMove = whiteToMove;
        b.castle = castle;
        b.ep = ep;
        b.half = half;
        b.full = full;
        return b;
    }

    public static Board initial() {
        return fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    }

    public static Board fromFen(String fen) {
        String[] parts = fen.trim().split("\\s+");
        Board b = new Board();
        String[] rows = parts[0].split("/");
        for (int i = 0; i < 8; i++) {
            int rank = 7 - i;
            int f = 0;
            for (char ch : rows[i].toCharArray()) {
                if (ch >= '1' && ch <= '8') {
                    f += ch - '0';
                } else {
                    int t = "pnbrqk".indexOf(Character.toLowerCase(ch)) + 1;
                    b.sq[rank * 8 + f] = Character.isUpperCase(ch) ? t : -t;
                    f++;
                }
            }
        }
        b.whiteToMove = parts.length < 2 || parts[1].equals("w");
        String c = parts.length > 2 ? parts[2] : "-";
        if (c.indexOf('K') >= 0) b.castle |= CR_WK;
        if (c.indexOf('Q') >= 0) b.castle |= CR_WQ;
        if (c.indexOf('k') >= 0) b.castle |= CR_BK;
        if (c.indexOf('q') >= 0) b.castle |= CR_BQ;
        if (parts.length > 3 && !parts[3].equals("-")) {
            b.ep = (parts[3].charAt(1) - '1') * 8 + (parts[3].charAt(0) - 'a');
        }
        if (parts.length > 4) b.half = Integer.parseInt(parts[4]);
        if (parts.length > 5) b.full = Integer.parseInt(parts[5]);
        return b;
    }

    // ------------------------------------------------------------------ атаки

    public boolean attacked(int s, boolean byWhite) {
        int f = s % 8, r = s / 8;
        int pr = byWhite ? r - 1 : r + 1;
        int pawn = byWhite ? PAWN : -PAWN;
        if (pr >= 0 && pr < 8) {
            for (int df = -1; df <= 1; df += 2) {
                int pf = f + df;
                if (pf >= 0 && pf < 8 && sq[pr * 8 + pf] == pawn) return true;
            }
        }
        int kn = byWhite ? KNIGHT : -KNIGHT;
        for (int i = 0; i < KNIGHT_D.length; i += 2) {
            int nf = f + KNIGHT_D[i], nr = r + KNIGHT_D[i + 1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && sq[nr * 8 + nf] == kn) return true;
        }
        int kg = byWhite ? KING : -KING;
        for (int i = 0; i < KING_D.length; i += 2) {
            int nf = f + KING_D[i], nr = r + KING_D[i + 1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && sq[nr * 8 + nf] == kg) return true;
        }
        int bishop = byWhite ? BISHOP : -BISHOP;
        int rook = byWhite ? ROOK : -ROOK;
        int queen = byWhite ? QUEEN : -QUEEN;
        if (rayHits(f, r, DIAG_D, bishop, queen)) return true;
        return rayHits(f, r, ORTH_D, rook, queen);
    }

    private boolean rayHits(int f, int r, int[] dirs, int p1, int p2) {
        for (int i = 0; i < dirs.length; i += 2) {
            int nf = f + dirs[i], nr = r + dirs[i + 1];
            while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                int p = sq[nr * 8 + nf];
                if (p != 0) {
                    if (p == p1 || p == p2) return true;
                    break;
                }
                nf += dirs[i];
                nr += dirs[i + 1];
            }
        }
        return false;
    }

    public int kingSquare(boolean white) {
        int k = white ? KING : -KING;
        for (int i = 0; i < 64; i++) if (sq[i] == k) return i;
        return -1;
    }

    public boolean inCheck() {
        int ks = kingSquare(whiteToMove);
        return ks >= 0 && attacked(ks, !whiteToMove);
    }

    // ------------------------------------------------------------ генерация ходов

    private static void addPawnMove(List<Move> mv, int from, int to, boolean promo) {
        if (promo) {
            mv.add(new Move(from, to, QUEEN));
            mv.add(new Move(from, to, ROOK));
            mv.add(new Move(from, to, BISHOP));
            mv.add(new Move(from, to, KNIGHT));
        } else {
            mv.add(new Move(from, to, 0));
        }
    }

    private List<Move> pseudoMoves() {
        List<Move> mv = new ArrayList<>(48);
        boolean w = whiteToMove;
        for (int s = 0; s < 64; s++) {
            int p = sq[s];
            if (p == 0 || (p > 0) != w) continue;
            int t = Math.abs(p);
            int f = s % 8, r = s / 8;
            if (t == PAWN) {
                int d = w ? 1 : -1;
                int start = w ? 1 : 6;
                int last = w ? 7 : 0;
                int r1 = r + d;
                if (r1 >= 0 && r1 < 8) {
                    int to = r1 * 8 + f;
                    if (sq[to] == 0) {
                        addPawnMove(mv, s, to, r1 == last);
                        if (r == start && sq[(r + 2 * d) * 8 + f] == 0) mv.add(new Move(s, (r + 2 * d) * 8 + f, 0));
                    }
                    for (int df = -1; df <= 1; df += 2) {
                        int f1 = f + df;
                        if (f1 >= 0 && f1 < 8) {
                            to = r1 * 8 + f1;
                            int q = sq[to];
                            if (q != 0 && (q > 0) != w) addPawnMove(mv, s, to, r1 == last);
                            else if (q == 0 && to == ep) mv.add(new Move(s, to, 0));
                        }
                    }
                }
            } else if (t == KNIGHT || t == KING) {
                int[] dirs = (t == KNIGHT) ? KNIGHT_D : KING_D;
                for (int i = 0; i < dirs.length; i += 2) {
                    int nf = f + dirs[i], nr = r + dirs[i + 1];
                    if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                        int to = nr * 8 + nf;
                        int q = sq[to];
                        if (q == 0 || (q > 0) != w) mv.add(new Move(s, to, 0));
                    }
                }
                if (t == KING) addCastling(mv, s, w);
            } else {
                boolean diag = (t == BISHOP || t == QUEEN);
                boolean orth = (t == ROOK || t == QUEEN);
                if (diag) slide(mv, s, f, r, DIAG_D, w);
                if (orth) slide(mv, s, f, r, ORTH_D, w);
            }
        }
        return mv;
    }

    private void slide(List<Move> mv, int s, int f, int r, int[] dirs, boolean w) {
        for (int i = 0; i < dirs.length; i += 2) {
            int nf = f + dirs[i], nr = r + dirs[i + 1];
            while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                int to = nr * 8 + nf;
                int q = sq[to];
                if (q == 0) {
                    mv.add(new Move(s, to, 0));
                } else {
                    if ((q > 0) != w) mv.add(new Move(s, to, 0));
                    break;
                }
                nf += dirs[i];
                nr += dirs[i + 1];
            }
        }
    }

    private void addCastling(List<Move> mv, int s, boolean w) {
        if (w && s == 4) {
            if ((castle & CR_WK) != 0 && sq[5] == 0 && sq[6] == 0 && sq[7] == ROOK
                    && !attacked(4, false) && !attacked(5, false) && !attacked(6, false)) mv.add(new Move(4, 6, 0));
            if ((castle & CR_WQ) != 0 && sq[3] == 0 && sq[2] == 0 && sq[1] == 0 && sq[0] == ROOK
                    && !attacked(4, false) && !attacked(3, false) && !attacked(2, false)) mv.add(new Move(4, 2, 0));
        }
        if (!w && s == 60) {
            if ((castle & CR_BK) != 0 && sq[61] == 0 && sq[62] == 0 && sq[63] == -ROOK
                    && !attacked(60, true) && !attacked(61, true) && !attacked(62, true)) mv.add(new Move(60, 62, 0));
            if ((castle & CR_BQ) != 0 && sq[59] == 0 && sq[58] == 0 && sq[57] == 0 && sq[56] == -ROOK
                    && !attacked(60, true) && !attacked(59, true) && !attacked(58, true)) mv.add(new Move(60, 58, 0));
        }
    }

    /** Применяет ход (без проверки легальности) и возвращает НОВУЮ позицию. */
    public Board apply(Move m) {
        Board b = copy();
        int piece = b.sq[m.from];
        int captured = b.sq[m.to];
        int t = Math.abs(piece);
        if (t == PAWN && m.to == ep && captured == 0 && (m.from % 8) != (m.to % 8)) {
            b.sq[whiteToMove ? m.to - 8 : m.to + 8] = 0;
        }
        b.sq[m.to] = piece;
        b.sq[m.from] = 0;
        if (m.promo != 0) b.sq[m.to] = whiteToMove ? m.promo : -m.promo;
        if (t == KING && Math.abs(m.to - m.from) == 2) {
            if (m.to > m.from) {
                b.sq[m.from + 1] = b.sq[m.from + 3];
                b.sq[m.from + 3] = 0;
            } else {
                b.sq[m.from - 1] = b.sq[m.from - 4];
                b.sq[m.from - 4] = 0;
            }
        }
        if (t == KING) b.castle &= whiteToMove ? ~(CR_WK | CR_WQ) : ~(CR_BK | CR_BQ);
        for (int i = 0; i < 2; i++) {
            int s = (i == 0) ? m.from : m.to;
            if (s == 0) b.castle &= ~CR_WQ;
            else if (s == 7) b.castle &= ~CR_WK;
            else if (s == 56) b.castle &= ~CR_BQ;
            else if (s == 63) b.castle &= ~CR_BK;
        }
        b.ep = -1;
        if (t == PAWN && Math.abs(m.to - m.from) == 16) b.ep = (m.from + m.to) / 2;
        b.half = (t == PAWN || captured != 0) ? 0 : half + 1;
        if (!whiteToMove) b.full = full + 1;
        b.whiteToMove = !whiteToMove;
        return b;
    }

    public List<Move> legalMoves() {
        List<Move> res = new ArrayList<>(40);
        for (Move m : pseudoMoves()) {
            Board nb = apply(m);
            int ks = nb.kingSquare(whiteToMove);
            if (ks >= 0 && nb.attacked(ks, !whiteToMove)) continue;
            res.add(m);
        }
        return res;
    }

    /** Ищет среди легальных ходов тот, что записан в UCI (e2e4, e7e8q). null если такого нет. */
    public Move parseUci(String uci) {
        if (uci == null || uci.length() < 4) return null;
        for (Move m : legalMoves()) {
            if (m.uci().equals(uci)) return m;
        }
        return null;
    }

    // ----------------------------------------------------------------- FEN, SAN

    public String fen() {
        StringBuilder sb = new StringBuilder();
        for (int rank = 7; rank >= 0; rank--) {
            int empty = 0;
            for (int f = 0; f < 8; f++) {
                int p = sq[rank * 8 + f];
                if (p == 0) {
                    empty++;
                } else {
                    if (empty > 0) {
                        sb.append(empty);
                        empty = 0;
                    }
                    char c = "pnbrqk".charAt(Math.abs(p) - 1);
                    sb.append(p > 0 ? Character.toUpperCase(c) : c);
                }
            }
            if (empty > 0) sb.append(empty);
            if (rank > 0) sb.append('/');
        }
        sb.append(whiteToMove ? " w " : " b ");
        StringBuilder c = new StringBuilder();
        if ((castle & CR_WK) != 0) c.append('K');
        if ((castle & CR_WQ) != 0) c.append('Q');
        if ((castle & CR_BK) != 0) c.append('k');
        if ((castle & CR_BQ) != 0) c.append('q');
        sb.append(c.length() == 0 ? "-" : c.toString());
        sb.append(' ');
        sb.append(ep >= 0 && epCapturable() ? squareName(ep) : "-");
        sb.append(' ').append(half).append(' ').append(full);
        return sb.toString();
    }

    private boolean epCapturable() {
        for (Move m : legalMoves()) {
            if (Math.abs(sq[m.from]) == PAWN && m.to == ep && sq[m.to] == 0 && (m.from % 8) != (m.to % 8)) return true;
        }
        return false;
    }

    /** Ключ позиции для поиска повторений (без счётчиков ходов). */
    public String positionKey() {
        String f = fen();
        int i = f.indexOf(' ', f.indexOf(' ', f.indexOf(' ', f.indexOf(' ') + 1) + 1) + 1);
        return i > 0 ? f.substring(0, i) : f;
    }

    private static final String[] RU = {"", "", "К", "С", "Л", "Ф", "Кр"};

    /** Запись хода в русской алгебраической нотации (Кf3, Лad1, exd5, O-O, e8=Ф+). */
    public String san(Move m, List<Move> legal) {
        int piece = sq[m.from];
        int t = Math.abs(piece);
        StringBuilder s = new StringBuilder();
        if (t == KING && Math.abs(m.to - m.from) == 2) {
            s.append(m.to > m.from ? "O-O" : "O-O-O");
        } else {
            boolean capture = sq[m.to] != 0 || (t == PAWN && (m.from % 8) != (m.to % 8));
            if (t == PAWN) {
                if (capture) s.append((char) ('a' + m.from % 8));
            } else {
                s.append(RU[t]);
                boolean sameFile = false, sameRank = false, other = false;
                for (Move o : legal) {
                    if (o.equals(m) || sq[o.from] != piece || o.to != m.to) continue;
                    other = true;
                    if (o.from % 8 == m.from % 8) sameFile = true;
                    if (o.from / 8 == m.from / 8) sameRank = true;
                }
                if (other) {
                    if (!sameFile) s.append((char) ('a' + m.from % 8));
                    else if (!sameRank) s.append((char) ('1' + m.from / 8));
                    else s.append(squareName(m.from));
                }
            }
            if (capture) s.append('x');
            s.append(squareName(m.to));
            if (m.promo != 0) s.append('=').append(RU[m.promo]);
        }
        Board nb = apply(m);
        if (nb.inCheck()) s.append(nb.legalMoves().isEmpty() ? "#" : "+");
        return s.toString();
    }

    public String san(Move m) {
        return san(m, legalMoves());
    }

    // ------------------------------------------------------------- прочее

    public boolean insufficientMaterial() {
        int minors = 0;
        for (int i = 0; i < 64; i++) {
            int t = Math.abs(sq[i]);
            if (t == PAWN || t == ROOK || t == QUEEN) return false;
            if (t == KNIGHT || t == BISHOP) minors++;
        }
        return minors <= 1;
    }

    /** Баланс материала в пешках (белые минус чёрные). */
    public int materialBalance() {
        int[] val = {0, 1, 3, 3, 5, 9, 0};
        int sum = 0;
        for (int i = 0; i < 64; i++) {
            int p = sq[i];
            if (p == 0) continue;
            sum += p > 0 ? val[p] : -val[-p];
        }
        return sum;
    }

    /** Насколько позиция r (распознанная с экрана) отличается от этой: расхождение клетки = 1, "не распознано" = 0.5. */
    public float cost(int[] r) {
        float c = 0f;
        for (int s = 0; s < 64; s++) {
            if (r[s] == UNKNOWN) c += 0.5f;
            else if (r[s] != sq[s]) c += 1f;
        }
        return c;
    }

    /**
     * Строит позицию по распознанной доске. Права на рокировку выводятся из расположения короля и ладей.
     * Возвращает null, если позиция недопустима (нет короля, пешки на крайних горизонталях, есть нераспознанные клетки,
     * сторона, не имеющая хода, под шахом).
     */
    public static Board fromRecognition(int[] r, boolean whiteToMove) {
        Board b = new Board();
        int wk = 0, bk = 0, wp = 0, bp = 0, total = 0;
        for (int s = 0; s < 64; s++) {
            if (r[s] == UNKNOWN) return null;
            b.sq[s] = r[s];
            int p = r[s];
            if (p == KING) wk++;
            if (p == -KING) bk++;
            if (p == PAWN) {
                wp++;
                if (s < 8 || s >= 56) return null;
            }
            if (p == -PAWN) {
                bp++;
                if (s < 8 || s >= 56) return null;
            }
            if (p != 0) total++;
        }
        if (wk != 1 || bk != 1 || wp > 8 || bp > 8 || total > 32) return null;
        b.whiteToMove = whiteToMove;
        if (b.sq[4] == KING && b.sq[7] == ROOK) b.castle |= CR_WK;
        if (b.sq[4] == KING && b.sq[0] == ROOK) b.castle |= CR_WQ;
        if (b.sq[60] == -KING && b.sq[63] == -ROOK) b.castle |= CR_BK;
        if (b.sq[60] == -KING && b.sq[56] == -ROOK) b.castle |= CR_BQ;
        int ownerNotToMoveKing = b.kingSquare(!whiteToMove);
        if (b.attacked(ownerNotToMoveKing, whiteToMove)) return null;
        return b;
    }
}
