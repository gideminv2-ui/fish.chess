package fish.chess;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;

/** Стартовый экран: проверка, что всё готово, и кнопки для включения службы. Окна поверх приложений показывает служба. */
public class MainActivity extends Activity {
    private TextView statusView;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable box(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        return d;
    }

    private TextView label(String text, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams full(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(box(0xFF0E1620, 0));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(40), dp(16), dp(28));
        sv.addView(col);

        TextView title = label("fish.chess", 32, 0xFFFFFFFF);
        col.addView(title);
        col.addView(label("Шахматный бот: читает доску с экрана, считает ход в Stockfish и сам нажимает на клетки.", 14, 0xFF9FB3C8), full(4));

        statusView = label("", 15, 0xFFE6EEF6);
        statusView.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusView.setBackground(box(0xFF16212C, 14));
        col.addView(statusView, full(18));

        col.addView(label("Подготовка", 13, 0xFF7FA6D1), full(20));
        col.addView(button("1. Включить службу «fish.chess» в специальных возможностях", 0xFF2F6FED, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }), full(6));
        col.addView(button("Переключатель серый? (Android 13+) Сведения о приложении → ⋮ → «Разрешить ограниченные настройки»", 0xFF2B3C4E, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            }
        }), full(6));
        col.addView(button("2. Показать окна поверх приложений", 0xFF1B7F3A, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FishService s = FishService.instance;
                if (s != null) s.showOverlays();
                refresh();
            }
        }), full(6));

        TextView how = label("Как играть\n\n"
                + "1. Откройте приложение с шахматной доской (начальная позиция).\n"
                + "2. Положите сетку на доску хотя бы приблизительно - точно её выровняет программа сама.\n"
                + "3. В окне fish.chess откройте «⚙ Настройки» и выберите свой цвет и ориентацию доски.\n"
                + "4. «Калибровка»: программа запомнит вид ваших фигур. Это сохранится как «тема» - в следующий раз просто выберите её, калибровать заново не нужно. "
                + "Для других фигур/досок нажмите «+ Новая тема».\n"
                + "5. «Сетка: правка» переключает в режим игры, затем «Старт».\n"
                + "6. Партию можно остановить и продолжить с любой позиции: программа сама считает доску и (по подсветке последнего хода) поймёт, чей ход.\n\n"
                + "Окно с комментариями двигается за заголовок и растягивается за значок ◢ внизу справа.\n"
                + "Требуется Android 11 или новее.", 14, 0xFFC9D6E2);
        how.setPadding(dp(14), dp(12), dp(14), dp(12));
        how.setBackground(box(0xFF16212C, 14));
        col.addView(how, full(22));
        setContentView(sv);
    }

    private Button button(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackground(box(color, 12));
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        FishService s = FishService.instance;
        if (s != null) s.showOverlays();
        refresh();
    }

    private void refresh() {
        FishService s = FishService.instance;
        boolean sdkOk = Build.VERSION.SDK_INT >= 30;
        boolean engineOk = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so").exists();
        StringBuilder sb = new StringBuilder();
        sb.append(sdkOk ? "✓ " : "✗ ").append("Android ").append(Build.VERSION.RELEASE).append(sdkOk ? "" : " (нужен 11+)").append('\n');
        sb.append(s != null ? "✓ " : "✗ ").append("Служба специальных возможностей: ").append(s != null ? "включена" : "выключена").append('\n');
        sb.append(engineOk ? "✓ " : "✗ ").append("Stockfish: ").append(engineOk ? "встроен" : "НЕ встроен в приложение");
        statusView.setText(sb.toString());
    }
}
