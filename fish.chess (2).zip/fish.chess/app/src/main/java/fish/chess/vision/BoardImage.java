package fish.chess.vision;

/** Снимок области доски: пиксели ARGB (w x h). */
public final class BoardImage {
    public final int[] pixels;
    public final int w;
    public final int h;

    public BoardImage(int[] pixels, int w, int h) {
        this.pixels = pixels;
        this.w = w;
        this.h = h;
    }
}
