package fish.chess.vision;

/**
 * Автоматическое точное совмещение сетки с доской. Пользователь кладёт сетку приблизительно, а здесь по снимку
 * ищется "гребёнка" из 9 вертикальных и 9 горизонтальных границ клеток (на шахматной доске это самые резкие линии).
 */
public final class BoardLocator {
    public static final class Result {
        public final int left;
        public final int top;
        public final int size;
        public final float quality;

        Result(int left, int top, int size, float quality) {
            this.left = left;
            this.top = top;
            this.size = size;
            this.quality = quality;
        }
    }

    private static final float MIN_QUALITY = 1.8f;

    private BoardLocator() {
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float[] smooth(float[] g) {
        float[] s = new float[g.length];
        for (int i = 0; i < g.length; i++) {
            float a = g[Math.max(0, i - 1)], b = g[i], c = g[Math.min(g.length - 1, i + 1)];
            s[i] = (a + b + c) / 3f;
        }
        return s;
    }

    /**
     * Внутренние границы клеток (i=1..7) суммируются, а внешние (i=0 и i=8) берутся по более слабой из двух
     * с большим весом: так "съехавшая" на целую клетку гребёнка (одна из внешних линий уходит с доски) проигрывает.
     */
    private static double comb(float[] s, int start, double cell) {
        double sum = 0;
        for (int i = 1; i <= 7; i++) {
            sum += s[clamp((int) Math.floor(start + i * cell + 0.5), 0, s.length - 1)];
        }
        float o0 = s[clamp((int) Math.floor(start + 0.5), 0, s.length - 1)];
        float o8 = s[clamp((int) Math.floor(start + 8 * cell + 0.5), 0, s.length - 1)];
        return sum + 3.0 * Math.min(o0, o8);
    }

    /**
     * px - пиксели области (w x h); (ax, ay, as) - приблизительное положение доски в этой области.
     * Возвращает уточнённое положение (в координатах области) или null, если доска не найдена.
     */
    public static Result locate(int[] px, int w, int h, int ax, int ay, int as) {
        if (as < 64 || w < 16 || h < 16) return null;
        float[] lum = new float[w * h];
        for (int i = 0; i < w * h; i++) {
            int p = px[i];
            lum[i] = 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
        }
        float[] gx = new float[w];
        float[] gy = new float[h];
        int y0 = clamp(ay + (int) (0.12 * as), 1, h - 2), y1 = clamp(ay + (int) (0.88 * as), 1, h - 2);
        for (int y = y0; y <= y1; y++) {
            int base = y * w;
            for (int x = 1; x < w - 1; x++) gx[x] += Math.abs(lum[base + x + 1] - lum[base + x - 1]);
        }
        int x0 = clamp(ax + (int) (0.12 * as), 1, w - 2), x1 = clamp(ax + (int) (0.88 * as), 1, w - 2);
        for (int x = x0; x <= x1; x++) {
            for (int y = 1; y < h - 1; y++) gy[y] += Math.abs(lum[(y + 1) * w + x] - lum[(y - 1) * w + x]);
        }
        float[] sx = smooth(gx);
        float[] sy = smooth(gy);

        double c0 = as / 8.0;
        int range = (int) Math.round(0.10 * as);
        double bestTotal = -1, bestCell = c0;
        int bestL = ax, bestT = ay;
        for (double cell = c0 * 0.90; cell <= c0 * 1.10 + 1e-9; cell += 0.1) {
            double sxBest = -1, syBest = -1;
            int lBest = ax, tBest = ay;
            for (int l = ax - range; l <= ax + range; l++) {
                double v = comb(sx, l, cell);
                if (v > sxBest) {
                    sxBest = v;
                    lBest = l;
                }
            }
            for (int t = ay - range; t <= ay + range; t++) {
                double v = comb(sy, t, cell);
                if (v > syBest) {
                    syBest = v;
                    tBest = t;
                }
            }
            if (sxBest + syBest > bestTotal) {
                bestTotal = sxBest + syBest;
                bestCell = cell;
                bestL = lBest;
                bestT = tBest;
            }
        }
        // качество: резкость линий сетки по сравнению со средней резкостью внутри найденной доски
        double lineSum = 0;
        for (int i = 1; i <= 7; i++) {
            lineSum += sx[clamp((int) Math.floor(bestL + i * bestCell + 0.5), 0, w - 1)];
            lineSum += sy[clamp((int) Math.floor(bestT + i * bestCell + 0.5), 0, h - 1)];
        }
        double lineMean = lineSum / 14.0;
        double total = 0;
        int n = 0;
        int bx1 = clamp((int) Math.round(bestL + 8 * bestCell), 0, w - 1);
        for (int x = clamp(bestL, 0, w - 1); x <= bx1; x++) {
            total += sx[x];
            n++;
        }
        int by1 = clamp((int) Math.round(bestT + 8 * bestCell), 0, h - 1);
        for (int y = clamp(bestT, 0, h - 1); y <= by1; y++) {
            total += sy[y];
            n++;
        }
        double mean = n > 0 ? total / n : 1;
        float quality = (float) (lineMean / Math.max(mean, 1e-6));
        if (quality < MIN_QUALITY) return null;
        return new Result(bestL, bestT, (int) Math.round(8 * bestCell), quality);
    }
}
