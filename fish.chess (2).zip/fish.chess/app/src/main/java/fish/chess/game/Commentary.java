package fish.chess.game;

import fish.chess.chess.Board;
import fish.chess.chess.Move;
import fish.chess.engine.EngineResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Формирование текстовых комментариев к партии. */
final class Commentary {
    private Commentary() {
    }

    static String signed(int cp) {
        return String.format(Locale.US, "%+.2f", cp / 100.0);
    }

    /** Оценка позиции с точки зрения нашей стороны. */
    static String evalText(EngineResult r) {
        if (r.hasMate) {
            return r.mate > 0 ? "мат в " + r.mate + " в нашу пользу" : "нам грозит мат в " + (-r.mate);
        }
        if (r.hasCp) {
            return "оценка " + signed(r.cp) + (r.depth > 0 ? ", глубина " + r.depth : "");
        }
        return "оценка недоступна";
    }

    /** Основной вариант движка в виде записи ходов. */
    static String pvSan(Board pos, List<String> pv, int maxPlies) {
        StringBuilder sb = new StringBuilder();
        Board b = pos;
        int n = 0;
        for (String u : pv) {
            if (n >= maxPlies) break;
            Move m = b.parseUci(u);
            if (m == null) break;
            if (sb.length() > 0) sb.append(' ');
            if (b.whiteToMove) sb.append(b.full).append('.');
            else if (n == 0) sb.append(b.full).append("...");
            sb.append(b.san(m));
            b = b.apply(m);
            n++;
        }
        return sb.toString();
    }

    /** Пометки к ходу: взятие, шах, рокировка... */
    static String flavor(Board before, Move m, Board after) {
        List<String> tags = new ArrayList<>();
        int p = Math.abs(before.sq[m.from]);
        boolean capture = before.sq[m.to] != 0 || (p == Board.PAWN && (m.from % 8) != (m.to % 8));
        if (p == Board.KING && Math.abs(m.to - m.from) == 2) tags.add("рокировка");
        if (capture) tags.add("взятие");
        if (m.promo != 0) tags.add("превращение");
        if (after.inCheck()) tags.add(after.legalMoves().isEmpty() ? "мат" : "шах");
        return tags.isEmpty() ? "" : " (" + String.join(", ", tags) + ")";
    }

    static String moveLabel(Board pos) {
        return pos.whiteToMove ? pos.full + "." : pos.full + "...";
    }

    static String material(int balanceForUs) {
        if (balanceForUs == 0) return "материал: поровну";
        return balanceForUs > 0 ? "материал: мы впереди на " + balanceForUs : "материал: мы отстаём на " + (-balanceForUs);
    }
}
