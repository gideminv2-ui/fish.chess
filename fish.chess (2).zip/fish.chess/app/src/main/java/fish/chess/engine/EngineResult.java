package fish.chess.engine;

import java.util.ArrayList;
import java.util.List;

/** Результат поиска Stockfish. Оценка - с точки зрения стороны, которая ходит. */
public final class EngineResult {
    public String best;
    public int depth;
    public boolean hasCp;
    public int cp;
    public boolean hasMate;
    public int mate;
    public final List<String> pv = new ArrayList<>();

    /** Оценка в сантипешках в одном числе (мат -> очень большое значение). */
    public int score() {
        if (hasMate) return mate > 0 ? 100000 - mate : -100000 - mate;
        return hasCp ? cp : 0;
    }

    public boolean hasScore() {
        return hasCp || hasMate;
    }
}
