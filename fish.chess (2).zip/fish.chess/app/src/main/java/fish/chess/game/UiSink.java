package fish.chess.game;

/** Куда выводить комментарии и статус. Методы могут вызываться из любого потока. */
public interface UiSink {
    void log(String line);

    void status(String text);

    void running(boolean running);
}
