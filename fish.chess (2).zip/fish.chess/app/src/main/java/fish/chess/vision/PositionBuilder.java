package fish.chess.vision;

import fish.chess.chess.Board;

/** Построение допустимой позиции из распознанной доски (с исправлением типичных ошибок) и определение, кто ходил последним. */
public final class PositionBuilder {
    public static final class Built {
        public final Board board;
        public final String problem;

        Built(Board board, String problem) {
            this.board = board;
            this.problem = problem;
        }
    }

    private PositionBuilder() {
    }

    private static int bestType(Recognizer.Detail d, int sq, int exclude1, int exclude2) {
        int best = 0;
        float bs = -1f;
        for (int t = 1; t <= 6; t++) {
            if (t == exclude1 || t == exclude2) continue;
            if (d.scores[sq][t - 1] > bs) {
                bs = d.scores[sq][t - 1];
                best = t;
            }
        }
        return best;
    }

    /**
     * Строит позицию. Нераспознанные клетки с фигурой заменяются наиболее похожей фигурой; если королей не один на сторону -
     * выбирается самая "королеподобная" фигура; пешки на крайних горизонталях и лишние пешки заменяются другими фигурами.
     * Если позиция невозможна при заданной очереди хода, пробуется противоположная.
     */
    public static Built build(Recognizer.Detail d, boolean whiteToMove) {
        int[] c = d.codes.clone();
        int occupied = 0;
        for (int sq = 0; sq < 64; sq++) {
            if (c[sq] == Board.UNKNOWN) {
                int t = bestType(d, sq, 0, 0);
                c[sq] = d.white[sq] ? t : -t;
            }
            if (c[sq] != 0) occupied++;
        }
        if (occupied < 2) return new Built(null, "на доске не видно фигур (сетка не на доске или доску что-то закрывает)");
        for (int color = 1; color >= -1; color -= 2) {
            int kings = 0;
            int bestKing = -1;
            float bks = -1f;
            for (int sq = 0; sq < 64; sq++) {
                if (c[sq] * color <= 0) continue;
                if (Math.abs(c[sq]) == Board.KING) {
                    kings++;
                    if (d.scores[sq][Board.KING - 1] > bks) {
                        bks = d.scores[sq][Board.KING - 1];
                        bestKing = sq;
                    }
                }
            }
            if (kings == 0) {
                int cand = -1;
                float cs = -1f;
                for (int sq = 0; sq < 64; sq++) {
                    if (c[sq] * color > 0 && d.scores[sq][Board.KING - 1] > cs) {
                        cs = d.scores[sq][Board.KING - 1];
                        cand = sq;
                    }
                }
                if (cand < 0) return new Built(null, "не найден " + (color > 0 ? "белый" : "чёрный") + " король");
                c[cand] = color * Board.KING;
            } else if (kings > 1) {
                for (int sq = 0; sq < 64; sq++) {
                    if (sq != bestKing && c[sq] == color * Board.KING) c[sq] = color * bestType(d, sq, Board.KING, 0);
                }
            }
            // пешки на крайних горизонталях
            for (int sq = 0; sq < 64; sq++) {
                if (c[sq] == color * Board.PAWN && (sq < 8 || sq >= 56)) c[sq] = color * bestType(d, sq, Board.PAWN, Board.KING);
            }
            // лишние пешки
            while (true) {
                int pawns = 0;
                int worst = -1;
                float ws = 2f;
                for (int sq = 0; sq < 64; sq++) {
                    if (c[sq] == color * Board.PAWN) {
                        pawns++;
                        if (d.scores[sq][0] < ws) {
                            ws = d.scores[sq][0];
                            worst = sq;
                        }
                    }
                }
                if (pawns <= 8 || worst < 0) break;
                c[worst] = color * bestType(d, worst, Board.PAWN, Board.KING);
            }
        }
        Board b = Board.fromRecognition(c, whiteToMove);
        if (b == null) b = Board.fromRecognition(c, !whiteToMove);
        if (b == null) return new Built(null, "получилась невозможная позиция (проверьте, что сетка точно на доске и калибровка сделана для этой темы фигур)");
        return new Built(b, null);
    }

    /** Чей ход был последним по подсветке клеток: +1 белые, -1 чёрные, 0 - не удалось определить. */
    public static int lastMover(Recognizer.Detail d) {
        int w = 0, b = 0, wk = 0, bk = 0, n = 0;
        for (int sq = 0; sq < 64; sq++) {
            if (!d.highlighted[sq]) continue;
            n++;
            int p = d.codes[sq];
            if (p == 0 || p == Board.UNKNOWN) continue;
            if (p > 0) {
                w++;
                if (p == Board.KING) wk++;
            } else {
                b++;
                if (p == -Board.KING) bk++;
            }
        }
        if (n == 0 || n > 6) return 0;
        if (w > 0 && b == 0) return 1;
        if (b > 0 && w == 0) return -1;
        int w2 = w - wk, b2 = b - bk; // подсветка шаха на короле не считается
        if (w2 > 0 && b2 == 0) return 1;
        if (b2 > 0 && w2 == 0) return -1;
        return 0;
    }
}
