package fish.chess.chess;

/** Ход: клетки 0..63 (a1=0, h1=7, a8=56), promo = тип фигуры (2..5) или 0. */
public final class Move {
    public final int from;
    public final int to;
    public final int promo;

    public Move(int from, int to, int promo) {
        this.from = from;
        this.to = to;
        this.promo = promo;
    }

    public Move(int from, int to) {
        this(from, to, 0);
    }

    public String uci() {
        StringBuilder sb = new StringBuilder(Board.squareName(from)).append(Board.squareName(to));
        if (promo != 0) sb.append("??nbrq".charAt(promo));
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Move)) return false;
        Move m = (Move) o;
        return from == m.from && to == m.to && promo == m.promo;
    }

    @Override
    public int hashCode() {
        return (from * 64 + to) * 8 + promo;
    }

    @Override
    public String toString() {
        return uci();
    }
}
