package fish.chess.engine;

import fish.chess.vision.Recognizer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Сохранённые темы фигур (калибровки): по одному файлу на тему. */
public final class ProfileStore {
    private static final String EXT = ".prof";
    private final File dir;

    public ProfileStore(File dir) {
        this.dir = dir;
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
    }

    private static String encode(String name) {
        try {
            return java.net.URLEncoder.encode(name.trim(), "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return "theme";
        }
    }

    private static String decode(String fileBase) {
        try {
            return java.net.URLDecoder.decode(fileBase, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return fileBase;
        }
    }

    private File file(String name) {
        return new File(dir, encode(name) + EXT);
    }

    public List<String> names() {
        File[] fs = dir.listFiles();
        List<String> out = new ArrayList<>();
        if (fs == null) return out;
        Arrays.sort(fs, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                if (a.getName().length() != b.getName().length()) return a.getName().length() - b.getName().length();
                return a.getName().compareTo(b.getName());
            }
        });
        for (File f : fs) {
            String n = f.getName();
            if (n.endsWith(EXT)) out.add(decode(n.substring(0, n.length() - EXT.length())));
        }
        return out;
    }

    public boolean exists(String name) {
        return name != null && !name.isEmpty() && file(name).exists();
    }

    public boolean save(String name, Recognizer r) {
        try (FileOutputStream os = new FileOutputStream(file(name))) {
            r.save(os);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public boolean load(String name, Recognizer r) {
        if (!exists(name)) return false;
        try (FileInputStream in = new FileInputStream(file(name))) {
            return r.load(in);
        } catch (IOException e) {
            return false;
        }
    }

    public boolean delete(String name) {
        return file(name).delete();
    }

    public String nextName() {
        int n = 1;
        while (exists("Тема " + n)) n++;
        return "Тема " + n;
    }
}
