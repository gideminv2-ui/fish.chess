package fish.chess;

import android.content.Context;
import android.content.SharedPreferences;

import fish.chess.game.GameConfig;

/** Настройки приложения и положение окон. */
public final class Prefs {
    public static final int[] THINK_OPTIONS = {300, 500, 1000, 2000, 5000};
    public static final int[] SKILL_OPTIONS = {20, 15, 10, 5};

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getSharedPreferences("fishchess", Context.MODE_PRIVATE);
    }

    // ---- настройки игры

    public boolean ourWhite() {
        return sp.getBoolean("ourWhite", true);
    }

    public void setOurWhite(boolean v) {
        sp.edit().putBoolean("ourWhite", v).apply();
    }

    /** Доска перевёрнута: наши фигуры сверху. */
    public boolean flipped() {
        return sp.getBoolean("flipped", false);
    }

    public void setFlipped(boolean v) {
        sp.edit().putBoolean("flipped", v).apply();
    }

    public int thinkMs() {
        return sp.getInt("thinkMs", 1000);
    }

    public void setThinkMs(int v) {
        sp.edit().putInt("thinkMs", v).apply();
    }

    public boolean drag() {
        return sp.getBoolean("drag", false);
    }

    public void setDrag(boolean v) {
        sp.edit().putBoolean("drag", v).apply();
    }

    public int skill() {
        return sp.getInt("skill", 20);
    }

    public void setSkill(int v) {
        sp.edit().putInt("skill", v).apply();
    }

    public boolean gridInPlay() {
        return sp.getBoolean("gridInPlay", false);
    }

    public void setGridInPlay(boolean v) {
        sp.edit().putBoolean("gridInPlay", v).apply();
    }

    /** Старт с середины партии: 0 - определить автоматически, 1 - ход наш, 2 - ход соперника. */
    public int midTurn() {
        return sp.getInt("midTurn", 0);
    }

    public void setMidTurn(int v) {
        sp.edit().putInt("midTurn", v).apply();
    }

    /** Имя выбранной темы фигур ("" - нет). */
    public String profile() {
        return sp.getString("profile", "");
    }

    public void setProfile(String name) {
        sp.edit().putString("profile", name).apply();
    }

    public boolean promoTap() {
        return sp.getBoolean("promoTap", true);
    }

    public void setPromoTap(boolean v) {
        sp.edit().putBoolean("promoTap", v).apply();
    }

    public GameConfig toConfig() {
        GameConfig c = new GameConfig();
        c.ourWhite = ourWhite();
        c.whiteAtBottom = ourWhite() != flipped();
        c.thinkMs = thinkMs();
        c.dragMode = drag();
        c.skill = skill();
        c.promoTap = promoTap();
        c.midgameTurn = midTurn();
        int cores = Runtime.getRuntime().availableProcessors();
        c.threads = Math.max(1, Math.min(4, cores / 2));
        c.hashMb = 64;
        return c;
    }

    // ---- положение окон

    /** {left, top, size} в пикселях или null, если ещё не сохранено. */
    public int[] gridRect() {
        if (!sp.contains("gridSize")) return null;
        return new int[]{sp.getInt("gridLeft", 0), sp.getInt("gridTop", 0), sp.getInt("gridSize", 600)};
    }

    public void setGridRect(int left, int top, int size) {
        sp.edit().putInt("gridLeft", left).putInt("gridTop", top).putInt("gridSize", size).apply();
    }

    /** {x, y, w, h} в пикселях или null. */
    public int[] panelRect() {
        if (!sp.contains("panelW")) return null;
        return new int[]{sp.getInt("panelX", 0), sp.getInt("panelY", 0), sp.getInt("panelW", 600), sp.getInt("panelH", 500)};
    }

    public void setPanelRect(int x, int y, int w, int h) {
        sp.edit().putInt("panelX", x).putInt("panelY", y).putInt("panelW", w).putInt("panelH", h).apply();
    }
}
