package fish.chess;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import java.io.File;
import java.util.List;

import fish.chess.engine.ProfileStore;
import fish.chess.engine.UciEngine;
import fish.chess.game.GameController;
import fish.chess.game.UiSink;
import fish.chess.ui.GridOverlay;
import fish.chess.ui.PanelOverlay;
import fish.chess.vision.Recognizer;

/**
 * Служба специальных возможностей: даёт право делать снимки экрана и нажимать на экран за нас, а также
 * показывать окна поверх других приложений (без отдельного разрешения "поверх других окон").
 */
public class FishService extends AccessibilityService {
    public static volatile FishService instance;

    private Handler main;
    private Prefs prefs;
    private WindowManager wm;
    private GridOverlay grid;
    private PanelOverlay panel;
    private Recognizer recognizer;
    private UciEngine engine;
    private GameController controller;
    private ProfileStore store;

    private final UiSink uiSink = new UiSink() {
        @Override
        public void log(String line) {
            PanelOverlay p = panel;
            if (p != null) p.appendLog(line);
        }

        @Override
        public void status(String text) {
            PanelOverlay p = panel;
            if (p != null) p.setStatus(text);
        }

        @Override
        public void running(boolean running) {
            PanelOverlay p = panel;
            if (p != null) p.setRunning(running);
        }
    };

    private final class PanelListener implements PanelOverlay.Listener {
        @Override
        public void onStartStop() {
            if (controller.isRunning()) {
                controller.stop();
                return;
            }
            if (!recognizer.isCalibrated()) {
                panel.appendLog("Нет выбранной темы фигур: поставьте начальную позицию и нажмите «Калибровка» (или выберите сохранённую тему).");
                return;
            }
            grid.setEditing(false);
            panel.setGridEditing(false);
            if (!controller.start(prefs.toConfig())) panel.appendLog("Подождите секунду и повторите.");
        }

        @Override
        public void onCalibrate() {
            boolean started = controller.calibrate(prefs.toConfig(), new GameController.CalibrationListener() {
                @Override
                public void onCalibrated(int good) {
                    if (good >= 30) {
                        String name = prefs.profile();
                        if (name.isEmpty()) name = store.nextName();
                        store.save(name, recognizer);
                        prefs.setProfile(name);
                        uiSink.log("Тема «" + name + "» сохранена. В следующий раз калибровка не нужна: просто выберите эту тему.");
                        panel.setProfileLabel(profileLabel());
                    } else {
                        uiSink.log("Тема не сохранена: калибровка неточная.");
                    }
                }
            });
            if (!started) panel.appendLog("Сначала остановите игру.");
        }

        @Override
        public void onAlign() {
            if (!controller.align()) panel.appendLog("Сначала остановите игру.");
        }

        @Override
        public void onToggleGridMode() {
            boolean e = !grid.isEditing();
            grid.setEditing(e);
            panel.setGridEditing(e);
        }

        @Override
        public void onNextProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            List<String> names = store.names();
            if (names.isEmpty()) {
                panel.appendLog("Сохранённых тем пока нет: нажмите «Калибровка», чтобы создать первую.");
                return;
            }
            int idx = names.indexOf(prefs.profile());
            selectProfile(names.get((idx + 1) % names.size()));
        }

        @Override
        public void onNewProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            String name = store.nextName();
            prefs.setProfile(name);
            recognizer.reset();
            panel.setProfileLabel(profileLabel());
            panel.appendLog("Новая тема «" + name + "»: выберите в приложении нужные фигуры, поставьте начальную позицию и нажмите «Калибровка». Тема сохранится автоматически.");
        }

        @Override
        public void onDeleteProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            String name = prefs.profile();
            if (!store.exists(name)) {
                panel.appendLog("Эта тема ещё не сохранена - удалять нечего.");
                return;
            }
            store.delete(name);
            panel.appendLog("Тема «" + name + "» удалена.");
            List<String> names = store.names();
            if (names.isEmpty()) {
                prefs.setProfile("");
                recognizer.reset();
                panel.setProfileLabel(profileLabel());
            } else {
                selectProfile(names.get(0));
            }
        }

        @Override
        public void onClose() {
            hideOverlays();
        }

        @Override
        public void onSettingChanged() {
            grid.setLinesInPlay(prefs.gridInPlay());
        }

        @Override
        public void onGeometryChanged(int x, int y, int w, int h) {
            prefs.setPanelRect(x, y, w, h);
        }
    }

    private void selectProfile(String name) {
        if (store.load(name, recognizer)) {
            prefs.setProfile(name);
            panel.appendLog("Выбрана тема «" + name + "»: калибровка не нужна.");
        } else {
            recognizer.reset();
            panel.appendLog("Не удалось загрузить тему «" + name + "» - откалибруйте её заново.");
        }
        panel.setProfileLabel(profileLabel());
    }

    private String profileLabel() {
        String name = prefs.profile();
        if (name.isEmpty()) return "Тема: нет (нужна калибровка)";
        if (!recognizer.isCalibrated()) return "Тема: " + name + " (нужна калибровка)";
        String d = recognizer.describe();
        return "Тема: " + name + (d.isEmpty() ? "" : " · " + d) + "  ▸ сменить";
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        main = new Handler(Looper.getMainLooper());
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        recognizer = new Recognizer();
        store = new ProfileStore(new File(getFilesDir(), "profiles"));
        List<String> names = store.names();
        String name = prefs.profile();
        if (!store.exists(name)) name = names.isEmpty() ? "" : names.get(0);
        if (!name.isEmpty() && store.load(name, recognizer)) {
            prefs.setProfile(name);
        } else {
            recognizer.reset();
            prefs.setProfile(name);
        }
        engine = new UciEngine(new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so"));
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // события не нужны: служба используется только ради снимков экрана и жестов
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdown();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        instance = null;
        super.onDestroy();
    }

    private void shutdown() {
        hideOverlays();
        if (engine != null) engine.close();
    }

    public boolean stockfishPresent() {
        return new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so").exists();
    }

    private void buildOverlays() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float d = dm.density;
        int[] gr = prefs.gridRect();
        int gl;
        int gt;
        int gs;
        if (gr == null) {
            gs = dm.widthPixels - Math.round(48 * d);
            gl = Math.round(24 * d);
            gt = Math.max(0, (dm.heightPixels - gs) / 2 + Math.round(60 * d));
        } else {
            gl = gr[0];
            gt = gr[1];
            gs = gr[2];
        }
        grid = new GridOverlay(this, wm, gl, gt, gs, new GridOverlay.Listener() {
            @Override
            public void onBoardMoved(int left, int top, int size) {
                prefs.setGridRect(left, top, size);
            }
        });
        grid.setLinesInPlay(prefs.gridInPlay());

        int[] pr = prefs.panelRect();
        int px;
        int py;
        int pw;
        int ph;
        if (pr == null) {
            px = Math.round(8 * d);
            py = Math.round(24 * d);
            pw = dm.widthPixels - Math.round(16 * d);
            ph = Math.round(290 * d);
        } else {
            px = pr[0];
            py = pr[1];
            pw = pr[2];
            ph = pr[3];
        }
        panel = new PanelOverlay(this, wm, prefs, new PanelListener(), px, py, pw, ph);
        AndroidScreen screen = new AndroidScreen(this, grid, main, uiSink);
        controller = new GameController(screen, engine, recognizer, uiSink);
    }

    /** Показать окна (вызывается при открытии приложения). */
    public void showOverlays() {
        if (panel == null || grid == null) buildOverlays();
        panel.show();
        grid.show();
        panel.setGridEditing(grid.isEditing());
        panel.setProfileLabel(profileLabel());
        if (!stockfishPresent()) {
            uiSink.log("ВНИМАНИЕ: в приложение не встроен Stockfish (libstockfish.so). Игра невозможна, пока вы не положите его в app/src/main/jniLibs/arm64-v8a/ и не пересоберёте приложение.");
        }
        if (recognizer.isCalibrated()) {
            uiSink.log("Тема «" + prefs.profile() + "» загружена - калибровка не нужна. Положите сетку на доску и нажмите «Старт».");
        }
    }

    public void hideOverlays() {
        if (controller != null) controller.stop();
        if (panel != null) panel.hide();
        if (grid != null) grid.hide();
    }

    public boolean overlaysShown() {
        return panel != null && panel.isShown();
    }
}
