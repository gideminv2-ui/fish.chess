package fish.chess.ui;

import android.graphics.drawable.GradientDrawable;

/** Общие цвета и заготовки оформления fish.chess v3. */
public final class Ui {
    public static final int BG = 0xF2101822;
    public static final int CARD = 0xFF1A2531;
    public static final int CHIP = 0xFF243447;
    public static final int ACCENT = 0xFF22C55E;
    public static final int BLUE = 0xFF3B82F6;
    public static final int DANGER = 0xFFEF4444;
    public static final int TEXT = 0xFFEAF2FA;
    public static final int MUTED = 0xFF8EA3B8;
    public static final int LABEL = 0xFF7FA6D1;

    private Ui() {
    }

    public static GradientDrawable rounded(float density, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        return d;
    }

    public static GradientDrawable outlined(float density, int fill, int stroke, float radiusDp) {
        GradientDrawable d = rounded(density, fill, radiusDp);
        d.setStroke(Math.max(1, Math.round(1.5f * density)), stroke);
        return d;
    }
}
