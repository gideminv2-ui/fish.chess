package fish.chess;

import android.content.Context;
import android.content.SharedPreferences;

import fish.chess.game.GameConfig;

/** Настройки приложения и положение окон. */
public final class Prefs {
    public static final int[] THINK_OPTIONS = {100, 200, 300, 500, 1000, 2000, 3000, 5000, 10000};
    public static final String[] LEVEL_NAMES = {"Макс", "Сильный", "Средний", "Слабый", "Новичок"};
    public static final String[] SPEED_NAMES = {"Обычно", "Быстро", "Молния"};

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getSharedPreferences("fishchess", Context.MODE_PRIVATE);
    }

    // ---- настройки игры

    public boolean ourWhite() {
        return sp.getBoolean("ourWhite", true);
    }

    public void setOurWhite(boolean v) {
        sp.edit().putBoolean("ourWhite", v).apply();
    }

    /** Доска перевёрнута: наши фигуры сверху. */
    public boolean flipped() {
        return sp.getBoolean("flipped", false);
    }

    public void setFlipped(boolean v) {
        sp.edit().putBoolean("flipped", v).apply();
    }

    public int thinkMs() {
        return sp.getInt("thinkMs", 500);
    }

    public void setThinkMs(int v) {
        sp.edit().putInt("thinkMs", v).apply();
    }

    public boolean drag() {
        return sp.getBoolean("drag", false);
    }

    public void setDrag(boolean v) {
        sp.edit().putBoolean("drag", v).apply();
    }

    /** Сила игры: 0 - максимум (все ядра, большая хеш-таблица) ... 4 - новичок. */
    public int level() {
        return sp.getInt("level", 0);
    }

    public void setLevel(int v) {
        sp.edit().putInt("level", v).apply();
    }

    /** Скорость: 0 - обычно, 1 - быстро, 2 - молния. */
    public int speed() {
        return sp.getInt("speed", 1);
    }

    public void setSpeed(int v) {
        sp.edit().putInt("speed", v).apply();
    }

    /** Окна были включены (чтобы показать их сами, когда служба перезапустится). */
    public boolean overlaysOn() {
        return sp.getBoolean("overlaysOn", false);
    }

    public void setOverlaysOn(boolean v) {
        sp.edit().putBoolean("overlaysOn", v).apply();
    }

    public boolean gridInPlay() {
        return sp.getBoolean("gridInPlay", false);
    }

    public void setGridInPlay(boolean v) {
        sp.edit().putBoolean("gridInPlay", v).apply();
    }

    /** Старт с середины партии: 0 - определить автоматически, 1 - ход наш, 2 - ход соперника. */
    public int midTurn() {
        return sp.getInt("midTurn", 0);
    }

    public void setMidTurn(int v) {
        sp.edit().putInt("midTurn", v).apply();
    }

    /** Имя выбранной темы фигур ("" - нет). */
    public String profile() {
        return sp.getString("profile", "");
    }

    public void setProfile(String name) {
        sp.edit().putString("profile", name).apply();
    }

    public boolean promoTap() {
        return sp.getBoolean("promoTap", true);
    }

    public void setPromoTap(boolean v) {
        sp.edit().putBoolean("promoTap", v).apply();
    }

    public GameConfig toConfig() {
        GameConfig c = new GameConfig();
        c.ourWhite = ourWhite();
        c.whiteAtBottom = ourWhite() != flipped();
        GameConfig.applySpeed(c, speed());
        c.thinkMs = thinkMs();
        c.dragMode = drag();
        c.promoTap = promoTap();
        c.midgameTurn = midTurn();
        int cores = Runtime.getRuntime().availableProcessors();
        switch (level()) {
            case 0:
                c.skill = 20;
                c.threads = Math.max(1, Math.min(8, cores));
                c.hashMb = 256;
                break;
            case 1:
                c.skill = 20;
                c.threads = Math.max(1, Math.min(4, cores / 2));
                c.hashMb = 128;
                break;
            case 2:
                c.skill = 15;
                c.threads = 2;
                c.hashMb = 64;
                break;
            case 3:
                c.skill = 10;
                c.threads = 1;
                c.hashMb = 32;
                break;
            default:
                c.skill = 5;
                c.threads = 1;
                c.hashMb = 16;
                break;
        }
        return c;
    }

    // ---- положение окон

    /** {left, top, size} в пикселях или null, если ещё не сохранено. */
    public int[] gridRect() {
        if (!sp.contains("gridSize")) return null;
        return new int[]{sp.getInt("gridLeft", 0), sp.getInt("gridTop", 0), sp.getInt("gridSize", 600)};
    }

    public void setGridRect(int left, int top, int size) {
        sp.edit().putInt("gridLeft", left).putInt("gridTop", top).putInt("gridSize", size).apply();
    }

    /** {x, y, w, h} в пикселях или null. */
    public int[] panelRect() {
        if (!sp.contains("panelW")) return null;
        return new int[]{sp.getInt("panelX", 0), sp.getInt("panelY", 0), sp.getInt("panelW", 600), sp.getInt("panelH", 500)};
    }

    public void setPanelRect(int x, int y, int w, int h) {
        sp.edit().putInt("panelX", x).putInt("panelY", y).putInt("panelW", w).putInt("panelH", h).apply();
    }
}
