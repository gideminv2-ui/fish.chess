package fish.chess;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Плитка в шторке быстрых настроек: показать/скрыть окна fish.chess, не заходя в приложение. */
public class FishTileService extends TileService {
    private void refresh() {
        Tile tile = getQsTile();
        if (tile == null) return;
        FishService s = FishService.instance;
        tile.setLabel("fish.chess");
        if (s == null) tile.setState(Tile.STATE_UNAVAILABLE);
        else tile.setState(s.overlaysShown() ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.updateTile();
    }

    @Override
    public void onStartListening() {
        refresh();
    }

    @Override
    public void onClick() {
        FishService s = FishService.instance;
        if (s != null) s.toggleOverlays();
        refresh();
    }
}
