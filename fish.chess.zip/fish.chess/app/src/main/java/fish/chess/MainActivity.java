package fish.chess;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;

/** Стартовый экран: проверка, что всё готово, и кнопки для включения службы. Окна поверх приложений показывает служба. */
public class MainActivity extends Activity {
    private TextView statusView;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(36), dp(18), dp(24));
        sv.addView(col);

        TextView title = new TextView(this);
        title.setText("fish.chess");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        col.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Шахматный бот: читает доску с экрана, считает ход в Stockfish и сам нажимает на экран.");
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        sub.setPadding(0, dp(4), 0, dp(14));
        col.addView(sub);

        statusView = new TextView(this);
        statusView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        statusView.setPadding(0, 0, 0, dp(12));
        col.addView(statusView);

        col.addView(button("1. Включить службу «fish.chess» в специальных возможностях", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));
        col.addView(button("Если переключатель серый (Android 13+): «Сведения о приложении» → ⋮ → «Разрешить ограниченные настройки»", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }));
        col.addView(button("2. Показать окна поверх приложений", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FishService s = FishService.instance;
                if (s != null) s.showOverlays();
                refresh();
            }
        }));

        TextView how = new TextView(this);
        how.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        how.setPadding(0, dp(16), 0, 0);
        how.setText("Как играть:\n"
                + "• Откройте приложение с шахматной доской в начальной позиции.\n"
                + "• Двигайте зелёную/голубую сетку и тяните за круглые ручки, пока сетка точно не ляжет на 64 клетки доски.\n"
                + "• В окне fish.chess откройте ⚙ и выберите свой цвет и ориентацию доски.\n"
                + "• Нажмите «Калибровка» (на доске — начальная расстановка). Должно получиться 32 из 32.\n"
                + "• Нажмите «Сетка: правка», чтобы перейти в режим «игра» (окно перестанет перехватывать касания), затем «Старт».\n"
                + "• Окно с комментариями можно двигать за заголовок и растягивать за значок ◢ внизу справа.\n\n"
                + "Требуется Android 11 или новее.");
        col.addView(how);
        setContentView(sv);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        FishService s = FishService.instance;
        if (s != null) s.showOverlays();
        refresh();
    }

    private void refresh() {
        FishService s = FishService.instance;
        boolean sdkOk = Build.VERSION.SDK_INT >= 30;
        boolean engineOk = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so").exists();
        StringBuilder sb = new StringBuilder();
        sb.append(sdkOk ? "✓ " : "✗ ").append("Android ").append(Build.VERSION.RELEASE).append(sdkOk ? "" : " (нужен 11+)").append('\n');
        sb.append(s != null ? "✓ " : "✗ ").append("Служба специальных возможностей: ").append(s != null ? "включена" : "выключена").append('\n');
        sb.append(engineOk ? "✓ " : "✗ ").append("Stockfish (libstockfish.so): ").append(engineOk ? "найден" : "НЕ встроен в приложение");
        statusView.setText(sb.toString());
    }
}
