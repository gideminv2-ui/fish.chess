package fish.chess;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fish.chess.ui.Ui;

/** fish.chess v3: стартовый экран. Главное - большая кнопка «Показать/скрыть окна» и понятный статус. */
public class MainActivity extends Activity {
    private Prefs prefs;
    private LinearLayout statusBox;
    private Button toggleBtn;
    private TextView warnView;

    private float density() {
        return getResources().getDisplayMetrics().density;
    }

    private int dp(float v) {
        return Math.round(v * density());
    }

    private TextView label(String text, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams full(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    private Button button(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Ui.TEXT);
        b.setBackground(Ui.rounded(density(), color, 14));
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.rounded(density(), 0xFF0B121A, 0));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(44), dp(16), dp(28));
        sv.addView(col);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("🐟 fish.chess", 30, Ui.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        TextView badge = label("v3", 13, 0xFF04210F);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setPadding(dp(9), dp(3), dp(9), dp(3));
        badge.setBackground(Ui.rounded(density(), Ui.ACCENT, 10));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.leftMargin = dp(10);
        titleRow.addView(title);
        titleRow.addView(badge, bp);
        col.addView(titleRow);
        col.addView(label("Читает шахматную доску с экрана, считает ход в Stockfish и сам нажимает на клетки.", 14, Ui.MUTED), full(4));

        statusBox = new LinearLayout(this);
        statusBox.setOrientation(LinearLayout.VERTICAL);
        statusBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusBox.setBackground(Ui.rounded(density(), Ui.CARD, 16));
        col.addView(statusBox, full(18));

        toggleBtn = button("", Ui.ACCENT, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FishService s = FishService.instance;
                if (s != null) s.toggleOverlays();
                else startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                refresh();
            }
        });
        toggleBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        toggleBtn.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(toggleBtn, full(14));

        warnView = label("", 13, 0xFFFBBF24);
        warnView.setPadding(dp(14), dp(10), dp(14), dp(10));
        warnView.setBackground(Ui.rounded(density(), 0xFF2A2412, 14));
        col.addView(warnView, full(10));

        col.addView(label("ПОДГОТОВКА", 11, Ui.LABEL), full(20));
        col.addView(button("Специальные возможности: включить «fish.chess»", Ui.BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }), full(6));
        col.addView(button("Переключатель серый? Разрешить ограниченные настройки", Ui.CHIP, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            }
        }), full(6));
        col.addView(button("Не давать системе выключать приложение (экономия заряда)", Ui.CHIP, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        }), full(6));

        TextView how = label("КАК ИГРАТЬ", 11, Ui.LABEL);
        col.addView(how, full(20));
        TextView steps = label("1. Нажмите «Показать окна» и откройте приложение с шахматной доской.\n"
                + "2. Положите сетку на доску хотя бы приблизительно: точно её выровняет программа.\n"
                + "3. ⚙ → выберите свой цвет и ориентацию доски. «Калибровка» на начальной позиции запоминает вид ваших фигур как тему; "
                + "дальше калибровать не нужно, подходящая тема выбирается сама.\n"
                + "4. ▶ Старт. Партию можно продолжить с любой позиции. Бот сам не останавливается: при сбоях перечитывает доску и играет дальше.\n\n"
                + "⚡ Скорость «Быстро»/«Молния» и ⏱ короткое время хода нужны для игры с часами.\n"
                + "Окна можно включать и из шторки быстрых настроек: добавьте плитку fish.chess.\n"
                + "Нужен Android 11 или новее.", 14, 0xFFC9D6E2);
        steps.setPadding(dp(14), dp(12), dp(14), dp(12));
        steps.setBackground(Ui.rounded(density(), Ui.CARD, 16));
        col.addView(steps, full(6));
        setContentView(sv);
    }

    private void statusRow(boolean ok, String text) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        TextView dot = label("●", 14, ok ? Ui.ACCENT : Ui.DANGER);
        dot.setPadding(0, 0, dp(10), 0);
        r.addView(dot);
        r.addView(label(text, 15, Ui.TEXT));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(3);
        statusBox.addView(r, p);
    }

    @Override
    protected void onResume() {
        super.onResume();
        FishService s = FishService.instance;
        if (s != null && prefs.overlaysOn() && !s.overlaysShown()) s.showOverlays();
        refresh();
    }

    private void refresh() {
        FishService s = FishService.instance;
        boolean sdkOk = Build.VERSION.SDK_INT >= 30;
        boolean engineOk = EngineFiles.present(getApplicationInfo().nativeLibraryDir);
        statusBox.removeAllViews();
        statusRow(sdkOk, "Android " + Build.VERSION.RELEASE + (sdkOk ? "" : " (нужен 11+)"));
        statusRow(s != null, "Служба: " + (s != null ? "включена" : "выключена"));
        statusRow(engineOk, "Stockfish: " + (engineOk ? "встроен" : "НЕ встроен в приложение"));
        if (s == null) {
            toggleBtn.setText("Включить службу fish.chess");
            toggleBtn.setBackground(Ui.rounded(density(), Ui.BLUE, 14));
            warnView.setVisibility(View.VISIBLE);
            warnView.setText("Служба выключена. После обновления приложения Android выключает её: включите снова в специальных возможностях. "
                    + "Больше ничего давать не нужно, окна появятся сами.");
        } else {
            boolean shown = s.overlaysShown();
            toggleBtn.setText(shown ? "Скрыть окна" : "Показать окна");
            toggleBtn.setBackground(Ui.rounded(density(), shown ? Ui.DANGER : Ui.ACCENT, 14));
            warnView.setVisibility(engineOk ? View.GONE : View.VISIBLE);
            if (!engineOk) warnView.setText("Stockfish не встроен: игра невозможна. Соберите приложение через GitHub Actions (он скачает Stockfish сам).");
        }
    }
}
