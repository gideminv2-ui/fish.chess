package fish.chess.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fish.chess.Prefs;

/** Отдельное окно: темы фигур, калибровка, выравнивание сетки и все настройки игры. Не мешает окну комментариев. */
public final class ControlOverlay {
    public interface Listener {
        void onCalibrate();

        void onAlign();

        void onToggleGridMode();

        void onNextProfile();

        void onNewProfile();

        void onDeleteProfile();

        void onSettingChanged();
    }

    private abstract class Option {
        abstract String text();

        abstract void next();
    }

    private final Context ctx;
    private final WindowManager wm;
    private final Prefs prefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float density;

    private LinearLayout root;
    private TextView btnProfile;
    private TextView btnGrid;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;

    public ControlOverlay(Context ctx, WindowManager wm, Prefs prefs, Listener listener) {
        this.ctx = ctx;
        this.wm = wm;
        this.prefs = prefs;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        build();
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = ctx.getResources().getDisplayMetrics().heightPixels;
        int w = Math.min(sw - dp(16), dp(330));
        int h = Math.min(Math.round(sh * 0.62f), dp(470));
        lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(8);
        lp.y = dp(110);
    }

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        return d;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, int color) {
        TextView t = text(s, 12, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(9), dp(6), dp(9));
        t.setBackground(rounded(color, 8));
        return t;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private TextView section(String s) {
        TextView t = text(s, 11, 0xFF7FA6D1);
        t.setPadding(dp(4), dp(10), dp(4), dp(2));
        return t;
    }

    private void build() {
        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(0xF5101820, 14));
        root.setPadding(dp(8), dp(6), dp(8), dp(8));

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Настройки и калибровка", 14, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView btnClose = button("✕", 0xFF2B3C4E);
        header.addView(btnClose, new LinearLayout.LayoutParams(dp(38), dp(34)));
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    default:
                        return true;
                }
            }
        });
        root.addView(header);

        ScrollView sv = new ScrollView(ctx);
        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        body.addView(section("ТЕМА ФИГУР (нажмите, чтобы выбрать следующую)"));
        btnProfile = button("Тема: —", 0xFF2F4B6E);
        btnProfile.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        body.addView(btnProfile, full());
        LinearLayout profRow = new LinearLayout(ctx);
        profRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView btnNew = button("+ Новая тема", 0xFF2B3C4E);
        TextView btnDel = button("Удалить тему", 0xFF4A2B2B);
        profRow.addView(btnNew, weighted());
        profRow.addView(btnDel, weighted());
        body.addView(profRow);

        body.addView(section("ДОСКА"));
        LinearLayout boardRow = new LinearLayout(ctx);
        boardRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView btnCal = button("Калибровка", 0xFF2F6FED);
        TextView btnAlign = button("Выровнять сетку", 0xFF2B3C4E);
        boardRow.addView(btnCal, weighted());
        boardRow.addView(btnAlign, weighted());
        body.addView(boardRow);
        btnGrid = button("Сетка: правка", 0xFF2B3C4E);
        body.addView(btnGrid, full());

        body.addView(section("ИГРА (нажимайте на кнопки, чтобы менять значение)"));
        addOptionRow(body,
                new Option() {
                    String text() {
                        return "Мои: " + (prefs.ourWhite() ? "белые" : "чёрные");
                    }

                    void next() {
                        prefs.setOurWhite(!prefs.ourWhite());
                    }
                },
                new Option() {
                    String text() {
                        return "Доска: " + (prefs.flipped() ? "перевёрнута" : "мои снизу");
                    }

                    void next() {
                        prefs.setFlipped(!prefs.flipped());
                    }
                });
        addOptionRow(body,
                new Option() {
                    String text() {
                        return "Думать: " + thinkLabel(prefs.thinkMs());
                    }

                    void next() {
                        prefs.setThinkMs(nextOf(Prefs.THINK_OPTIONS, prefs.thinkMs()));
                    }
                },
                new Option() {
                    String text() {
                        return "Сила: " + prefs.skill() + (prefs.skill() == 20 ? " (макс.)" : "");
                    }

                    void next() {
                        prefs.setSkill(nextOf(Prefs.SKILL_OPTIONS, prefs.skill()));
                    }
                });
        addOptionRow(body,
                new Option() {
                    String text() {
                        return "Ход: " + (prefs.drag() ? "перетаскивание" : "два нажатия");
                    }

                    void next() {
                        prefs.setDrag(!prefs.drag());
                    }
                },
                new Option() {
                    String text() {
                        return "Превращение: " + (prefs.promoTap() ? "+нажатие" : "без нажатия");
                    }

                    void next() {
                        prefs.setPromoTap(!prefs.promoTap());
                    }
                });
        addOptionRow(body,
                new Option() {
                    String text() {
                        return "Сетка в игре: " + (prefs.gridInPlay() ? "видна" : "скрыта");
                    }

                    void next() {
                        prefs.setGridInPlay(!prefs.gridInPlay());
                    }
                },
                new Option() {
                    String text() {
                        String[] names = {"авто", "ход наш", "ход соперн."};
                        return "Партия идёт: " + names[prefs.midTurn() % 3];
                    }

                    void next() {
                        prefs.setMidTurn((prefs.midTurn() + 1) % 3);
                    }
                });
        TextView hint = text("Сетку достаточно положить на доску приблизительно - точно её выровняет программа. "
                + "Калибровка сохраняется как тема: в следующий раз просто выберите её.", 11, 0xFF8FA3B8);
        hint.setPadding(dp(4), dp(10), dp(4), dp(4));
        body.addView(hint);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hide();
            }
        });
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onNextProfile();
            }
        });
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onNewProfile();
            }
        });
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteProfile();
            }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCalibrate();
            }
        });
        btnAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onAlign();
            }
        });
        btnGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onToggleGridMode();
            }
        });
    }

    private void addOptionRow(LinearLayout body, Option a, Option b) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(optionButton(a), weighted());
        row.addView(optionButton(b), weighted());
        body.addView(row);
    }

    private TextView optionButton(final Option opt) {
        final TextView tv = button(opt.text(), 0xFF2B3C4E);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opt.next();
                tv.setText(opt.text());
                listener.onSettingChanged();
            }
        });
        return tv;
    }

    private static String thinkLabel(int ms) {
        return ms < 1000 ? (ms / 1000.0 + " с").replace('.', ',') : (ms / 1000) + " с";
    }

    private static int nextOf(int[] options, int current) {
        for (int i = 0; i < options.length; i++) {
            if (options[i] == current) return options[(i + 1) % options.length];
        }
        return options[0];
    }

    // ------------------------------------------------------------------- публичное

    public void show() {
        if (attached) return;
        wm.addView(root, lp);
        attached = true;
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(root);
        } catch (RuntimeException ignored) {
            // уже снято
        }
        attached = false;
    }

    public boolean isShown() {
        return attached;
    }

    public void setProfileLabel(final String label) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnProfile.setText(label);
            }
        });
    }

    public void setGridEditing(final boolean editing) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnGrid.setText(editing ? "Сетка: правка (двигайте и тяните)" : "Сетка: игра (нажмите для правки)");
            }
        });
    }
}
