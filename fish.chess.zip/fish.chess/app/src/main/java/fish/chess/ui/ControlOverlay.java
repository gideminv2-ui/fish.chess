package fish.chess.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fish.chess.Prefs;

/** fish.chess v3: компактное окно настроек. Темы фигур, калибровка, сетка и параметры игры в виде маленьких «чипов». */
public final class ControlOverlay {
    public interface Listener {
        void onCalibrate();

        void onAlign();

        void onToggleGridMode();

        void onNextProfile();

        void onNewProfile();

        void onDeleteProfile();

        void onSettingChanged();
    }

    private abstract class Option {
        abstract String text();

        abstract void next();
    }

    private final Context ctx;
    private final WindowManager wm;
    private final Prefs prefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float density;

    private LinearLayout root;
    private TextView btnProfile;
    private TextView btnGrid;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;

    public ControlOverlay(Context ctx, WindowManager wm, Prefs prefs, Listener listener) {
        this.ctx = ctx;
        this.wm = wm;
        this.prefs = prefs;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        build();
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = ctx.getResources().getDisplayMetrics().heightPixels;
        int w = Math.min(sw - dp(16), dp(330));
        int h = Math.min(Math.round(sh * 0.52f), dp(420));
        lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(8);
        lp.y = dp(120);
    }

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        return Ui.rounded(density, color, radiusDp);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, int color, float sp) {
        TextView t = text(s, sp, Ui.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(9), dp(4), dp(9));
        t.setBackground(rounded(color, 10));
        return t;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private TextView section(String s) {
        TextView t = text(s, 10, Ui.LABEL);
        t.setPadding(dp(4), dp(8), dp(4), dp(1));
        return t;
    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r);
        return r;
    }

    private void build() {
        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(0xF5101822, 16));
        root.setPadding(dp(8), dp(6), dp(8), dp(8));

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("⚙ Настройки · fish.chess v3", 13, Ui.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView btnClose = button("✕", Ui.CHIP, 12);
        header.addView(btnClose, new LinearLayout.LayoutParams(dp(36), dp(32)));
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    default:
                        return true;
                }
            }
        });
        root.addView(header);

        ScrollView sv = new ScrollView(ctx);
        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        body.addView(section("ТЕМА ФИГУР · нажмите, чтобы выбрать следующую"));
        btnProfile = button("Тема: —", Ui.BLUE, 13);
        body.addView(btnProfile, full());
        LinearLayout r1 = row(body);
        TextView btnNew = button("＋ Новая", Ui.CHIP, 11);
        TextView btnDel = button("🗑 Удалить", Ui.CHIP, 11);
        TextView btnAlign = button("🎯 Выровнять", Ui.CHIP, 11);
        r1.addView(btnNew, weighted());
        r1.addView(btnDel, weighted());
        r1.addView(btnAlign, weighted());

        body.addView(section("ДОСКА"));
        LinearLayout r2 = row(body);
        TextView btnCal = button("📷 Калибровка", Ui.ACCENT, 12);
        btnCal.setTypeface(Typeface.DEFAULT_BOLD);
        btnGrid = button("▦ Сетка: правка", Ui.CHIP, 12);
        r2.addView(btnCal, weighted());
        r2.addView(btnGrid, weighted());

        body.addView(section("ИГРА · нажимайте на кнопки, чтобы менять значения"));
        addChips(body,
                new Option() {
                    String text() {
                        return prefs.ourWhite() ? "♔ Белые" : "♚ Чёрные";
                    }

                    void next() {
                        prefs.setOurWhite(!prefs.ourWhite());
                    }
                },
                new Option() {
                    String text() {
                        return prefs.flipped() ? "⬆ Перевёрн." : "⬇ Мои снизу";
                    }

                    void next() {
                        prefs.setFlipped(!prefs.flipped());
                    }
                },
                new Option() {
                    String text() {
                        String[] names = {"Старт: авто", "Старт: мой ход", "Старт: ход сопер."};
                        return names[prefs.midTurn() % 3];
                    }

                    void next() {
                        prefs.setMidTurn((prefs.midTurn() + 1) % 3);
                    }
                });
        addChips(body,
                new Option() {
                    String text() {
                        return "⚡ " + Prefs.SPEED_NAMES[prefs.speed() % 3];
                    }

                    void next() {
                        prefs.setSpeed((prefs.speed() + 1) % 3);
                    }
                },
                new Option() {
                    String text() {
                        return "⏱ " + thinkLabel(prefs.thinkMs());
                    }

                    void next() {
                        prefs.setThinkMs(nextOf(Prefs.THINK_OPTIONS, prefs.thinkMs()));
                    }
                },
                new Option() {
                    String text() {
                        return "💪 " + Prefs.LEVEL_NAMES[prefs.level() % 5];
                    }

                    void next() {
                        prefs.setLevel((prefs.level() + 1) % 5);
                    }
                });
        addChips(body,
                new Option() {
                    String text() {
                        return prefs.drag() ? "✋ Ход: тянуть" : "👆 Ход: тап";
                    }

                    void next() {
                        prefs.setDrag(!prefs.drag());
                    }
                },
                new Option() {
                    String text() {
                        return prefs.promoTap() ? "♛ Превр.: тап" : "♛ Превр.: авто";
                    }

                    void next() {
                        prefs.setPromoTap(!prefs.promoTap());
                    }
                },
                new Option() {
                    String text() {
                        return prefs.gridInPlay() ? "▦ Сетка видна" : "▦ Сетка скрыта";
                    }

                    void next() {
                        prefs.setGridInPlay(!prefs.gridInPlay());
                    }
                });
        TextView hint = text("Сетку достаточно положить на доску приблизительно, точно её выровняет программа. "
                + "Калибровка сохраняется как тема; при старте подходящая тема выбирается сама. "
                + "⚡ и ⏱: чем быстрее скорость и короче время, тем быстрее ходы (для блица).", 10, Ui.MUTED);
        hint.setPadding(dp(4), dp(8), dp(4), dp(2));
        body.addView(hint);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hide();
            }
        });
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onNextProfile();
            }
        });
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onNewProfile();
            }
        });
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteProfile();
            }
        });
        btnAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onAlign();
            }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCalibrate();
            }
        });
        btnGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onToggleGridMode();
            }
        });
    }

    private void addChips(LinearLayout body, Option a, Option b, Option c) {
        LinearLayout r = row(body);
        r.addView(chip(a), weighted());
        r.addView(chip(b), weighted());
        r.addView(chip(c), weighted());
    }

    private TextView chip(final Option opt) {
        final TextView tv = button(opt.text(), Ui.CHIP, 11);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opt.next();
                tv.setText(opt.text());
                listener.onSettingChanged();
            }
        });
        return tv;
    }

    private static String thinkLabel(int ms) {
        return ms < 1000 ? (ms / 1000.0 + " с").replace('.', ',') : (ms / 1000) + " с";
    }

    private static int nextOf(int[] options, int current) {
        for (int i = 0; i < options.length; i++) {
            if (options[i] == current) return options[(i + 1) % options.length];
        }
        return options[0];
    }

    // ------------------------------------------------------------------- публичное

    public void show() {
        if (attached) return;
        wm.addView(root, lp);
        attached = true;
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(root);
        } catch (RuntimeException ignored) {
            // уже снято
        }
        attached = false;
    }

    public boolean isShown() {
        return attached;
    }

    public int[] screenRect() {
        return new int[]{lp.x, lp.y, lp.width, lp.height};
    }

    public void setCaptureHidden(final boolean hidden) {
        main.post(new Runnable() {
            @Override
            public void run() {
                root.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
            }
        });
    }

    public void setProfileLabel(final String label) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnProfile.setText(label);
            }
        });
    }

    public void setGridEditing(final boolean editing) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnGrid.setText(editing ? "▦ Сетка: правка" : "▦ Сетка: игра");
            }
        });
    }
}
