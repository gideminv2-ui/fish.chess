package fish.chess.engine;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Обёртка над внешним UCI-движком (Stockfish): отдельный процесс, команды в stdin, ответы из stdout. */
public final class UciEngine {
    private static final String EOF = "\u0000EOF";

    private final File[] binaries;
    private volatile Process proc;
    private volatile BufferedWriter out;
    private final LinkedBlockingQueue<String> lines = new LinkedBlockingQueue<>();
    private volatile boolean alive = false;

    /** Список вариантов движка по убыванию предпочтения: берётся первый, который запустится. */
    public UciEngine(File... binaries) {
        this.binaries = binaries;
    }

    public File binary() {
        return binaries[0];
    }

    public boolean isAlive() {
        Process p = proc;
        return alive && p != null && p.isAlive();
    }

    /** Запускает процесс и настраивает движок. Возвращает null при успехе или текст ошибки. */
    public String start(int threads, int hashMb, int skill) throws InterruptedException {
        String lastErr = "Файл движка не найден: " + binaries[0].getName() + ". Положите Stockfish для Android в app/src/main/jniLibs/arm64-v8a/libstockfish.so и пересоберите приложение.";
        for (File f : binaries) {
            if (!f.exists()) continue;
            String err = startOne(f, threads, hashMb, skill);
            if (err == null) return null;
            lastErr = err;
        }
        return lastErr;
    }

    private String startOne(File binary, int threads, int hashMb, int skill) throws InterruptedException {
        close();
        lines.clear();
        final Process p;
        try {
            ProcessBuilder pb = new ProcessBuilder(binary.getAbsolutePath());
            pb.redirectErrorStream(true);
            p = pb.start();
        } catch (IOException e) {
            return "Не удалось запустить Stockfish: " + e.getMessage();
        }
        proc = p;
        out = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
        Thread reader = new Thread(new Runnable() {
            @Override
            public void run() {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) lines.add(line);
                } catch (IOException ignored) {
                    // процесс закрыт
                }
                lines.add(EOF);
            }
        }, "uci-reader");
        reader.setDaemon(true);
        reader.start();
        alive = true;
        send("uci");
        if (!waitFor("uciok", 15000)) {
            close();
            return "Stockfish не ответил на команду uci (возможно, это бинарник не для вашего процессора).";
        }
        send("setoption name Threads value " + Math.max(1, threads));
        send("setoption name Hash value " + Math.max(1, hashMb));
        send("setoption name Skill Level value " + Math.max(0, Math.min(20, skill)));
        send("isready");
        if (!waitFor("readyok", 15000)) {
            close();
            return "Stockfish не подтвердил готовность.";
        }
        return null;
    }

    public void newGame() throws InterruptedException {
        send("ucinewgame");
        send("isready");
        waitFor("readyok", 8000);
    }

    /**
     * Ищет лучший ход. startFen = null означает начальную позицию. Возвращает null, если движок умер или завис.
     */
    public EngineResult bestMove(String startFen, List<String> moves, int moveTimeMs) throws InterruptedException {
        return bestMove(startFen, moves, moveTimeMs, null);
    }

    /** searchMoves - разрешённые ходы (UCI); null или пусто - любые. */
    public EngineResult bestMove(String startFen, List<String> moves, int moveTimeMs, List<String> searchMoves) throws InterruptedException {
        if (!isAlive()) return null;
        StringBuilder pos = new StringBuilder("position ");
        pos.append(startFen == null ? "startpos" : "fen " + startFen);
        if (!moves.isEmpty()) pos.append(" moves ").append(String.join(" ", moves));
        send(pos.toString());
        String go = "go movetime " + moveTimeMs;
        if (searchMoves != null && !searchMoves.isEmpty()) go += " searchmoves " + String.join(" ", searchMoves);
        send(go);
        EngineResult res = new EngineResult();
        long end = System.currentTimeMillis() + moveTimeMs + 15000L;
        boolean stopSent = false;
        while (true) {
            long left = Math.max(1L, end - System.currentTimeMillis());
            String l;
            try {
                l = lines.poll(left, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                send("stop");
                throw e;
            }
            if (l == null) {
                if (!stopSent) {
                    send("stop");
                    stopSent = true;
                    end = System.currentTimeMillis() + 4000L;
                    continue;
                }
                alive = false;
                return null;
            }
            if (EOF.equals(l)) {
                alive = false;
                return null;
            }
            if (l.startsWith("info ")) {
                parseInfo(l, res);
            } else if (l.startsWith("bestmove")) {
                String[] t = l.trim().split("\\s+");
                if (t.length >= 2 && !t[1].equals("(none)") && !t[1].equals("0000")) res.best = t[1];
                return res;
            }
        }
    }

    static void parseInfo(String line, EngineResult res) {
        String[] t = line.trim().split("\\s+");
        boolean hasScore = false, hasPv = false;
        int depth = res.depth, cp = 0, mate = 0;
        boolean isCp = false, isMate = false;
        java.util.ArrayList<String> pv = new java.util.ArrayList<>();
        for (int i = 1; i < t.length; i++) {
            String k = t[i];
            if (k.equals("multipv") && i + 1 < t.length) {
                if (!t[i + 1].equals("1")) return; // нас интересует только основная линия
                i++;
            } else if (k.equals("depth") && i + 1 < t.length) {
                depth = parseIntSafe(t[++i], depth);
            } else if (k.equals("score") && i + 2 < t.length) {
                String kind = t[++i];
                int v = parseIntSafe(t[++i], 0);
                if (kind.equals("cp")) {
                    isCp = true;
                    cp = v;
                    hasScore = true;
                } else if (kind.equals("mate")) {
                    isMate = true;
                    mate = v;
                    hasScore = true;
                }
            } else if (k.equals("pv")) {
                for (int j = i + 1; j < t.length; j++) pv.add(t[j]);
                hasPv = true;
                break;
            }
        }
        if (hasScore && hasPv) {
            res.depth = depth;
            res.hasCp = isCp;
            res.cp = cp;
            res.hasMate = isMate;
            res.mate = mate;
            res.pv.clear();
            res.pv.addAll(pv);
        }
    }

    private static int parseIntSafe(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private boolean waitFor(String token, long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        while (true) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) return false;
            String l = lines.poll(left, TimeUnit.MILLISECONDS);
            if (l == null) return false;
            if (EOF.equals(l)) {
                alive = false;
                return false;
            }
            if (l.startsWith(token)) return true;
        }
    }

    private void send(String cmd) {
        try {
            BufferedWriter w = out;
            if (w == null) {
                alive = false;
                return;
            }
            w.write(cmd);
            w.write('\n');
            w.flush();
        } catch (IOException e) {
            alive = false;
        }
    }

    public void close() {
        alive = false;
        Process p = proc;
        proc = null;
        BufferedWriter w = out;
        out = null;
        if (p != null) {
            try {
                if (w != null) {
                    w.write("quit\n");
                    w.flush();
                }
            } catch (IOException ignored) {
                // уже закрыт
            }
            p.destroy();
        }
    }
}
