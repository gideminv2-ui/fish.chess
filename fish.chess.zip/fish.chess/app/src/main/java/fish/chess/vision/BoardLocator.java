package fish.chess.vision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Автоматическое точное совмещение сетки с доской на любой площадке.
 * <ol>
 * <li>Период и фаза клеток находятся по ВНУТРЕННИМ границам клеток (внешние границы доски могут совпадать с краем экрана или
 * сливаться с фоном): для каждого столбца/строки считается доля пикселей с резким перепадом яркости, и ищется "гребёнка" из 7 линий.</li>
 * <li>Сдвиг на целое число клеток выбирается по чередованию светлых и тёмных клеток (по углам клеток, где нет фигур).</li>
 * <li>Если подсказка (где пользователь положил сетку) слишком далека - перебираются запасные положения по всему экрану.</li>
 * </ol>
 */
public final class BoardLocator {
    public static final class Result {
        public final int left;
        public final int top;
        public final int size;
        /** Доля клеток, подтверждающих чередование цветов (0..1). */
        public final float quality;

        Result(int left, int top, int size, float quality) {
            this.left = left;
            this.top = top;
            this.size = size;
            this.quality = quality;
        }
    }

    private static final float EDGE_T = 18f;
    private static final float MIN_QUALITY = 0.78f;
    private static final int MAX_SHIFT = 2;

    private BoardLocator() {
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float[] smooth(float[] g) {
        float[] s = new float[g.length];
        for (int i = 0; i < g.length; i++) {
            float a = g[Math.max(0, i - 1)], b = g[i], c = g[Math.min(g.length - 1, i + 1)];
            s[i] = (a + 2 * b + c) / 4f;
        }
        return s;
    }

    /** Совместимость: поиск с подсказкой в пределах области. */
    public static Result locate(int[] px, int w, int h, int ax, int ay, int as) {
        return locateAny(px, w, h, ax, ay, as);
    }

    /** Ищет доску по снимку (w x h); (hx, hy, hs) - где пользователь приблизительно положил сетку. */
    public static Result locateAny(int[] px, int w, int h, int hx, int hy, int hs) {
        if (w < 64 || h < 64) return null;
        float[] lum = new float[w * h];
        for (int i = 0; i < w * h; i++) {
            int p = px[i];
            lum[i] = 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
        }
        Result r = locateWith(px, lum, w, h, hx, hy, Math.max(64, hs));
        if (r != null) return r;
        // запасные положения: доска на всю ширину и чуть меньше, по разной высоте экрана
        List<int[]> alts = new ArrayList<>();
        int[] sizes = {w, (int) (w * 0.94), (int) (w * 0.86), (int) (Math.min(w, h) * 0.75)};
        for (int size : sizes) {
            if (size < 100) continue;
            for (int k = 0; k <= 8; k++) {
                int top = (int) ((h - size) * (k / 8.0));
                alts.add(new int[]{(w - size) / 2, top, size});
            }
        }
        Result best = null;
        for (int[] a : alts) {
            Result c = locateWith(px, lum, w, h, a[0], a[1], a[2]);
            if (c != null && (best == null || c.quality > best.quality)) best = c;
        }
        return best;
    }

    private static Result locateWith(int[] px, float[] lum, int w, int h, int hx, int hy, int hs) {
        int y0 = clamp(hy + (int) (0.12 * hs), 1, h - 2), y1 = clamp(hy + (int) (0.88 * hs), 1, h - 2);
        int x0 = clamp(hx + (int) (0.12 * hs), 1, w - 2), x1 = clamp(hx + (int) (0.88 * hs), 1, w - 2);
        if (y1 - y0 < 16 || x1 - x0 < 16) return null;
        float[] gx = new float[w];
        float[] gy = new float[h];
        for (int y = y0; y <= y1; y++) {
            int base = y * w;
            for (int x = 1; x < w - 1; x++) {
                if (Math.abs(lum[base + x + 1] - lum[base + x - 1]) > EDGE_T) gx[x] += 1f;
            }
        }
        for (int x = x0; x <= x1; x++) {
            for (int y = 1; y < h - 1; y++) {
                if (Math.abs(lum[(y + 1) * w + x] - lum[(y - 1) * w + x]) > EDGE_T) gy[y] += 1f;
            }
        }
        for (int x = 0; x < w; x++) gx[x] /= (y1 - y0 + 1);
        for (int y = 0; y < h; y++) gy[y] /= (x1 - x0 + 1);
        float[] sx = smooth(gx);
        float[] sy = smooth(gy);

        double c0 = hs / 8.0;
        double bestScore = -1, bestCell = c0;
        int bestL = hx, bestT = hy;
        for (double cell = c0 * 0.86; cell <= c0 * 1.14 + 1e-9; cell += 0.12) {
            int half = (int) Math.ceil(cell / 2);
            double bxs = -1, bys = -1;
            int lb = hx, tb = hy;
            for (int l = hx - half; l <= hx + half; l++) {
                double s = comb(sx, l, cell);
                if (s > bxs) {
                    bxs = s;
                    lb = l;
                }
            }
            for (int t = hy - half; t <= hy + half; t++) {
                double s = comb(sy, t, cell);
                if (s > bys) {
                    bys = s;
                    tb = t;
                }
            }
            if (bxs + bys > bestScore) {
                bestScore = bxs + bys;
                bestCell = cell;
                bestL = lb;
                bestT = tb;
            }
        }
        if (bestScore < 4.0) return null; // линий почти нет: доски тут нет
        // сдвиг на целое число клеток: по чередованию светлых и тёмных клеток
        float bestQ = -1f;
        int bl = bestL, bt = bestT, bestMag = 99;
        for (int ky = -MAX_SHIFT; ky <= MAX_SHIFT; ky++) {
            for (int kx = -MAX_SHIFT; kx <= MAX_SHIFT; kx++) {
                int l = (int) Math.round(bestL + kx * bestCell);
                int t = (int) Math.round(bestT + ky * bestCell);
                float q = checker(px, w, h, l, t, bestCell);
                int mag = Math.abs(kx) + Math.abs(ky);
                if (q > bestQ + 0.02f || (Math.abs(q - bestQ) <= 0.02f && mag < bestMag)) {
                    bestQ = q;
                    bl = l;
                    bt = t;
                    bestMag = mag;
                }
            }
        }
        if (bestQ < MIN_QUALITY) return null;
        return new Result(bl, bt, (int) Math.round(8 * bestCell), bestQ);
    }

    /** Сумма долей резких границ по 7 внутренним линиям клеток. */
    private static double comb(float[] s, int start, double cell) {
        double sum = 0;
        for (int i = 1; i <= 7; i++) {
            int pos = (int) Math.floor(start + i * cell + 0.5);
            if (pos >= 0 && pos < s.length) sum += s[pos];
        }
        return sum;
    }

    private static float median4(float a, float b, float c, float d) {
        float[] v = {a, b, c, d};
        Arrays.sort(v);
        return (v[1] + v[2]) / 2f;
    }

    private static float median(float[] v, int n) {
        float[] a = Arrays.copyOf(v, n);
        Arrays.sort(a);
        return a[n / 2];
    }

    /** Доля клеток, цвет которых (по углам клетки) соответствует чётности: светлые и тёмные клетки чередуются. */
    private static float checker(int[] px, int w, int h, int left, int top, double cell) {
        int patch = Math.max(3, (int) Math.round(cell * 0.14));
        int inset = Math.max(1, (int) Math.round(cell * 0.06));
        float[][] col = new float[64][3];
        boolean[] valid = new boolean[64];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                int cx0 = (int) Math.round(left + j * cell), cy0 = (int) Math.round(top + i * cell);
                int cx1 = (int) Math.round(left + (j + 1) * cell), cy1 = (int) Math.round(top + (i + 1) * cell);
                int[][] corners = {{cx0 + inset, cy0 + inset}, {cx1 - inset - patch, cy0 + inset},
                        {cx0 + inset, cy1 - inset - patch}, {cx1 - inset - patch, cy1 - inset - patch}};
                float[][] m = new float[4][3];
                boolean ok = true;
                for (int c = 0; c < 4 && ok; c++) {
                    int px0 = corners[c][0], py0 = corners[c][1];
                    if (px0 < 0 || py0 < 0 || px0 + patch > w || py0 + patch > h) {
                        ok = false;
                        break;
                    }
                    long sr = 0, sg = 0, sb = 0;
                    for (int y = py0; y < py0 + patch; y++) {
                        int base = y * w;
                        for (int x = px0; x < px0 + patch; x++) {
                            int p = px[base + x];
                            sr += (p >> 16) & 255;
                            sg += (p >> 8) & 255;
                            sb += p & 255;
                        }
                    }
                    int n = patch * patch;
                    m[c][0] = (float) sr / n;
                    m[c][1] = (float) sg / n;
                    m[c][2] = (float) sb / n;
                }
                if (!ok) continue;
                int idx = i * 8 + j;
                valid[idx] = true;
                for (int ch = 0; ch < 3; ch++) col[idx][ch] = median4(m[0][ch], m[1][ch], m[2][ch], m[3][ch]);
            }
        }
        float[][] ref = new float[2][3];
        for (int par = 0; par < 2; par++) {
            for (int ch = 0; ch < 3; ch++) {
                float[] v = new float[32];
                int n = 0;
                for (int idx = 0; idx < 64; idx++) {
                    if (valid[idx] && (((idx / 8) + (idx % 8)) & 1) == par) v[n++] = col[idx][ch];
                }
                if (n < 8) return 0f;
                ref[par][ch] = median(v, n);
            }
        }
        float sep = Math.abs(ref[0][0] - ref[1][0]) + Math.abs(ref[0][1] - ref[1][1]) + Math.abs(ref[0][2] - ref[1][2]);
        if (sep < 45f) return 0f;
        int good = 0;
        for (int idx = 0; idx < 64; idx++) {
            if (!valid[idx]) continue;
            int par = ((idx / 8) + (idx % 8)) & 1;
            float dEq = Math.abs(col[idx][0] - ref[par][0]) + Math.abs(col[idx][1] - ref[par][1]) + Math.abs(col[idx][2] - ref[par][2]);
            float dOt = Math.abs(col[idx][0] - ref[1 - par][0]) + Math.abs(col[idx][1] - ref[1 - par][1]) + Math.abs(col[idx][2] - ref[1 - par][2]);
            if (dEq <= 55f && dEq < dOt) good++;
        }
        return good / 64f;
    }
}
