package fish.chess.chess;

import java.util.List;

/** Сопоставление распознанной с экрана доски с легальными ходами (устойчиво к единичным ошибкам распознавания). */
public final class Tracker {
    /** Максимальное расхождение (в клетках), при котором ход ещё принимается. */
    public static final float ACCEPT = 4.5f;
    /** Ход должен объяснять экран лучше, чем "ничего не изменилось", минимум на столько. */
    public static final float MARGIN_NOCHANGE = 1.0f;
    /** ...и лучше следующего по качеству хода минимум на столько. */
    public static final float MARGIN_SECOND = 1.0f;
    /** Доска считается неизменившейся, если расхождение не больше этого. */
    public static final float UNCHANGED = 1.5f;
    /** Ожидаемая позиция считается подтверждённой, если расхождение не больше этого. */
    public static final float CONFIRMED = 3.0f;

    private Tracker() {
    }

    /** Найденный ход и расхождение экрана с позицией после него (0 - полное совпадение). */
    public static final class Match {
        public final Move move;
        public final float cost;

        Match(Move move, float cost) {
            this.move = move;
            this.cost = cost;
        }
    }

    /** Какой легальный ход из pos привёл к картинке r? null, если однозначно сказать нельзя. */
    public static Move findMove(Board pos, int[] r) {
        Match m = findMatch(pos, r);
        return m == null ? null : m.move;
    }

    public static Match findMatch(Board pos, int[] r) {
        List<Move> legal = pos.legalMoves();
        float d0 = pos.cost(r);
        Move best = null;
        float bc = 1e9f, second = 1e9f;
        for (Move m : legal) {
            float c = pos.apply(m).cost(r);
            if (c < bc) {
                second = bc;
                bc = c;
                best = m;
            } else if (c < second) {
                second = c;
            }
        }
        if (best != null && bc <= ACCEPT && d0 - bc >= MARGIN_NOCHANGE && second - bc >= MARGIN_SECOND) return new Match(best, bc);
        return null;
    }

    /** Совпадает ли экран r с ожидаемой позицией после нашего хода (и отличается ли от позиции до хода). */
    public static boolean confirms(Board before, Board after, int[] r) {
        float ca = after.cost(r);
        return ca <= CONFIRMED && before.cost(r) - ca >= 1.5f;
    }
}
