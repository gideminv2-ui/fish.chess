package fish.chess;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import java.io.File;
import java.util.List;

import fish.chess.engine.ProfileStore;
import fish.chess.engine.UciEngine;
import fish.chess.game.GameController;
import fish.chess.game.UiSink;
import fish.chess.ui.ControlOverlay;
import fish.chess.ui.GridOverlay;
import fish.chess.ui.PanelOverlay;
import fish.chess.vision.BoardImage;
import fish.chess.vision.PositionBuilder;
import fish.chess.vision.Recognizer;

/**
 * Служба специальных возможностей: даёт право делать снимки экрана и нажимать на экран за нас, а также
 * показывать окна поверх других приложений (без отдельного разрешения "поверх других окон").
 */
public class FishService extends AccessibilityService {
    public static volatile FishService instance;

    private Handler main;
    private Prefs prefs;
    private WindowManager wm;
    private GridOverlay grid;
    private PanelOverlay panel;
    private ControlOverlay control;
    private Recognizer recognizer;
    private UciEngine engine;
    private GameController controller;
    private ProfileStore store;

    private final UiSink uiSink = new UiSink() {
        @Override
        public void log(String line) {
            PanelOverlay p = panel;
            if (p != null) p.appendLog(line);
        }

        @Override
        public void status(String text) {
            PanelOverlay p = panel;
            if (p != null) p.setStatus(text);
        }

        @Override
        public void running(boolean running) {
            PanelOverlay p = panel;
            if (p != null) p.setRunning(running);
        }
    };

    /** Окно комментариев: только запуск/остановка, открытие настроек, закрытие. */
    private final class PanelListener implements PanelOverlay.Listener {
        @Override
        public void onStartStop() {
            if (controller.isRunning()) {
                controller.stop();
                return;
            }
            if (!recognizer.isCalibrated()) {
                panel.appendLog("Нет выбранной темы фигур: откройте ⚙, поставьте начальную позицию и нажмите «Калибровка» (или выберите сохранённую тему).");
                if (!control.isShown()) control.show();
                return;
            }
            grid.setEditing(false);
            control.setGridEditing(false);
            // окна не должны лежать на доске: бот видит их вместо клеток
            if (control.isShown()) control.hide();
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int[] r = grid.boardRect();
            if (panel.avoidBoard(r[0], r[1], r[2], dm.widthPixels, dm.heightPixels)) {
                panel.appendLog("Окно комментариев закрывало доску - я его сдвинул (или свернул в пузырёк 🐟: нажмите на него, чтобы развернуть).");
            }
            if (!controller.start(prefs.toConfig())) panel.appendLog("Подождите секунду и повторите.");
        }

        @Override
        public void onOpenControls() {
            if (control.isShown()) control.hide();
            else control.show();
        }

        @Override
        public void onClose() {
            hideOverlays();
        }

        @Override
        public void onGeometryChanged(int x, int y, int w, int h) {
            prefs.setPanelRect(x, y, w, h);
        }
    }

    /** Окно настроек: темы, калибровка, сетка, параметры игры. */
    private final class ControlListener implements ControlOverlay.Listener {
        @Override
        public void onCalibrate() {
            boolean started = controller.calibrate(prefs.toConfig(), new GameController.CalibrationListener() {
                @Override
                public void onCalibrated(int good) {
                    if (good >= 30) {
                        String name = prefs.profile();
                        if (name.isEmpty()) name = store.nextName();
                        store.save(name, recognizer);
                        prefs.setProfile(name);
                        uiSink.log("Тема «" + name + "» сохранена. В следующий раз калибровка не нужна: просто выберите эту тему.");
                        control.setProfileLabel(profileLabel());
                    } else {
                        uiSink.log("Тема не сохранена: калибровка неточная.");
                    }
                }
            });
            if (!started) panel.appendLog("Сначала остановите игру.");
        }

        @Override
        public void onAlign() {
            if (!controller.align()) panel.appendLog("Сначала остановите игру.");
        }

        @Override
        public void onToggleGridMode() {
            boolean e = !grid.isEditing();
            grid.setEditing(e);
            control.setGridEditing(e);
        }

        @Override
        public void onNextProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            List<String> names = store.names();
            if (names.isEmpty()) {
                panel.appendLog("Сохранённых тем пока нет: нажмите «Калибровка», чтобы создать первую.");
                return;
            }
            int idx = names.indexOf(prefs.profile());
            selectProfile(names.get((idx + 1) % names.size()));
        }

        @Override
        public void onNewProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            String name = store.nextName();
            prefs.setProfile(name);
            recognizer.reset();
            control.setProfileLabel(profileLabel());
            panel.appendLog("Новая тема «" + name + "»: выберите в приложении нужные фигуры, поставьте начальную позицию и нажмите «Калибровка». Тема сохранится автоматически.");
        }

        @Override
        public void onDeleteProfile() {
            if (controller.isRunning()) {
                panel.appendLog("Сначала остановите игру.");
                return;
            }
            String name = prefs.profile();
            if (!store.exists(name)) {
                panel.appendLog("Эта тема ещё не сохранена - удалять нечего.");
                return;
            }
            store.delete(name);
            panel.appendLog("Тема «" + name + "» удалена.");
            List<String> names = store.names();
            if (names.isEmpty()) {
                prefs.setProfile("");
                recognizer.reset();
                control.setProfileLabel(profileLabel());
            } else {
                selectProfile(names.get(0));
            }
        }

        @Override
        public void onSettingChanged() {
            grid.setLinesInPlay(prefs.gridInPlay());
        }
    }

    private void selectProfile(String name) {
        if (store.load(name, recognizer)) {
            prefs.setProfile(name);
            panel.appendLog("Выбрана тема «" + name + "»: калибровка не нужна.");
        } else {
            recognizer.reset();
            panel.appendLog("Не удалось загрузить тему «" + name + "» - откалибруйте её заново.");
        }
        control.setProfileLabel(profileLabel());
    }

    private String profileLabel() {
        String name = prefs.profile();
        if (name.isEmpty()) return "Тема: нет (нужна калибровка)";
        if (!recognizer.isCalibrated()) return "Тема: " + name + " (нужна калибровка)";
        String d = recognizer.describe();
        return "Тема: " + name + (d.isEmpty() ? "" : " · " + d) + "  ▸ сменить";
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        main = new Handler(Looper.getMainLooper());
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        recognizer = new Recognizer();
        store = new ProfileStore(new File(getFilesDir(), "profiles"));
        List<String> names = store.names();
        String name = prefs.profile();
        if (!store.exists(name)) name = names.isEmpty() ? "" : names.get(0);
        if (!name.isEmpty() && store.load(name, recognizer)) {
            prefs.setProfile(name);
        } else {
            recognizer.reset();
            prefs.setProfile(name);
        }
        engine = new UciEngine(EngineFiles.candidates(getApplicationInfo().nativeLibraryDir));
        // окна были включены - показываем их сами (служба могла перезапуститься), заново ничего включать не нужно
        if (prefs.overlaysOn()) showOverlays();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // события не нужны: служба используется только ради снимков экрана и жестов
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdown();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        instance = null;
        super.onDestroy();
    }

    private void shutdown() {
        removeOverlays();
        if (engine != null) engine.close();
    }

    public boolean stockfishPresent() {
        return EngineFiles.present(getApplicationInfo().nativeLibraryDir);
    }

    private void buildOverlays() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float d = dm.density;
        int[] gr = prefs.gridRect();
        int gl;
        int gt;
        int gs;
        if (gr == null) {
            gs = dm.widthPixels; // на телефоне доска обычно занимает всю ширину; точнее выровняет программа
            gl = 0;
            gt = Math.max(0, (dm.heightPixels - gs) / 2 + Math.round(40 * d));
        } else {
            gl = gr[0];
            gt = gr[1];
            gs = gr[2];
        }
        grid = new GridOverlay(this, wm, gl, gt, gs, new GridOverlay.Listener() {
            @Override
            public void onBoardMoved(int left, int top, int size) {
                prefs.setGridRect(left, top, size);
            }
        });
        grid.setLinesInPlay(prefs.gridInPlay());

        int[] pr = prefs.panelRect();
        int px;
        int py;
        int pw;
        int ph;
        if (pr == null) {
            px = Math.round(8 * d);
            py = Math.round(24 * d);
            pw = dm.widthPixels - Math.round(16 * d);
            ph = Math.round(190 * d);
        } else {
            px = pr[0];
            py = pr[1];
            pw = pr[2];
            ph = pr[3];
        }
        panel = new PanelOverlay(this, wm, new PanelListener(), px, py, pw, ph);
        control = new ControlOverlay(this, wm, prefs, new ControlListener());
        AndroidScreen screen = new AndroidScreen(this, grid, main, uiSink);
        screen.setCovers(new AndroidScreen.Covers() {
            @Override
            public boolean hideOverlapping(int left, int top, int size) {
                boolean any = false;
                if (panel != null && panel.isShown() && overlaps(panel.screenRect(), left, top, size)) {
                    panel.setCaptureHidden(true);
                    any = true;
                }
                if (control != null && control.isShown() && overlaps(control.screenRect(), left, top, size)) {
                    control.setCaptureHidden(true);
                    any = true;
                }
                return any;
            }

            @Override
            public boolean hideAll() {
                boolean any = false;
                if (panel != null && panel.isShown()) {
                    panel.setCaptureHidden(true);
                    any = true;
                }
                if (control != null && control.isShown()) {
                    control.setCaptureHidden(true);
                    any = true;
                }
                return any;
            }

            @Override
            public void restore() {
                if (panel != null) panel.setCaptureHidden(false);
                if (control != null) control.setCaptureHidden(false);
            }

            @Override
            public String describe(int left, int top, int size) {
                StringBuilder sb = new StringBuilder();
                if (panel != null && panel.isShown() && overlaps(panel.screenRect(), left, top, size)) sb.append("окно комментариев");
                if (control != null && control.isShown() && overlaps(control.screenRect(), left, top, size)) {
                    if (sb.length() > 0) sb.append(", ");
                    sb.append("окно настроек");
                }
                return sb.toString();
            }
        });
        controller = new GameController(screen, engine, recognizer, uiSink);
        controller.setThemePicker(new GameController.ThemePicker() {
            @Override
            public void pick(BoardImage img, boolean whiteAtBottom) {
                pickBestTheme(img, whiteAtBottom);
            }
        });
    }

    private static boolean overlaps(int[] r, int left, int top, int size) {
        return r != null && r[0] < left + size && r[0] + r[2] > left && r[1] < top + size && r[1] + r[3] > top;
    }

    /** Из сохранённых тем выбирает ту, что лучше всего читает текущую доску (например, после переключения с chess.com на lichess). */
    private void pickBestTheme(BoardImage img, boolean whiteAtBottom) {
        List<String> names = store.names();
        if (names.isEmpty()) return;
        String cur = prefs.profile();
        boolean curLoaded = recognizer.isCalibrated() && store.exists(cur);
        Recognizer tmp = new Recognizer();
        String best = null;
        int bestQ = Integer.MIN_VALUE;
        int curQ = Integer.MIN_VALUE;
        for (String n : names) {
            if (!store.load(n, tmp)) continue;
            Recognizer.Detail d = tmp.recognizeDetailed(img, whiteAtBottom);
            if (d == null) continue;
            int q = PositionBuilder.quality(d);
            if (n.equals(cur)) curQ = q;
            if (q > bestQ) {
                bestQ = q;
                best = n;
            }
        }
        // не меняем загруженную тему, пока другая не читает доску заметно лучше и не даёт допустимую позицию (иначе закрытая доска сбила бы выбор)
        if (best == null || (curLoaded && (best.equals(cur) || curQ >= bestQ - 6 || bestQ < 100))) return;
        if (store.load(best, recognizer)) {
            prefs.setProfile(best);
            uiSink.log("Автовыбор темы: «" + best + "» лучше всего читает эту доску.");
            control.setProfileLabel(profileLabel());
        }
    }

    /** Показать окна (кнопка в приложении, плитка в шторке или автоматически после перезапуска службы). */
    public void showOverlays() {
        prefs.setOverlaysOn(true);
        if (panel == null || grid == null) buildOverlays();
        panel.show();
        grid.show();
        control.setGridEditing(grid.isEditing());
        control.setProfileLabel(profileLabel());
        if (!recognizer.isCalibrated()) control.show();
        if (!stockfishPresent()) {
            uiSink.log("ВНИМАНИЕ: в приложение не встроен Stockfish (libstockfish.so). Игра невозможна, пока вы не положите его в app/src/main/jniLibs/arm64-v8a/ и не пересоберёте приложение.");
        }
        if (recognizer.isCalibrated()) {
            uiSink.log("Тема «" + prefs.profile() + "» загружена - калибровка не нужна. Положите сетку на доску и нажмите «Старт».");
        }
    }

    /** Убрать окна по желанию пользователя (запоминается: после перезапуска службы они не появятся сами). */
    public void hideOverlays() {
        prefs.setOverlaysOn(false);
        removeOverlays();
    }

    private void removeOverlays() {
        if (controller != null) controller.stop();
        if (control != null) control.hide();
        if (panel != null) panel.hide();
        if (grid != null) grid.hide();
    }

    public void toggleOverlays() {
        if (overlaysShown()) hideOverlays();
        else showOverlays();
    }

    public boolean overlaysShown() {
        return panel != null && panel.isShown();
    }
}
