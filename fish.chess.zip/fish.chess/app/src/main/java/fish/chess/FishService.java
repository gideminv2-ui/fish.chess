package fish.chess;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import fish.chess.engine.UciEngine;
import fish.chess.game.GameController;
import fish.chess.game.UiSink;
import fish.chess.ui.GridOverlay;
import fish.chess.ui.PanelOverlay;
import fish.chess.vision.Recognizer;

/**
 * Служба специальных возможностей: даёт право делать снимки экрана и нажимать на экран за нас, а также
 * показывать окна поверх других приложений (без отдельного разрешения "поверх других окон").
 */
public class FishService extends AccessibilityService {
    public static volatile FishService instance;

    private Handler main;
    private Prefs prefs;
    private WindowManager wm;
    private GridOverlay grid;
    private PanelOverlay panel;
    private Recognizer recognizer;
    private UciEngine engine;
    private GameController controller;
    private File templateFile;

    private final UiSink uiSink = new UiSink() {
        @Override
        public void log(String line) {
            PanelOverlay p = panel;
            if (p != null) p.appendLog(line);
        }

        @Override
        public void status(String text) {
            PanelOverlay p = panel;
            if (p != null) p.setStatus(text);
        }

        @Override
        public void running(boolean running) {
            PanelOverlay p = panel;
            if (p != null) p.setRunning(running);
        }
    };

    private final class PanelListener implements PanelOverlay.Listener {
        @Override
        public void onStartStop() {
            if (controller.isRunning()) {
                controller.stop();
                return;
            }
            grid.setEditing(false);
            panel.setGridEditing(false);
            if (!controller.start(prefs.toConfig())) panel.appendLog("Подождите секунду и повторите.");
        }

        @Override
        public void onCalibrate() {
            if (!controller.calibrate(prefs.toConfig())) panel.appendLog("Сначала остановите игру.");
        }

        @Override
        public void onToggleGridMode() {
            boolean e = !grid.isEditing();
            grid.setEditing(e);
            panel.setGridEditing(e);
        }

        @Override
        public void onClose() {
            hideOverlays();
        }

        @Override
        public void onSettingChanged() {
            grid.setLinesInPlay(prefs.gridInPlay());
        }

        @Override
        public void onGeometryChanged(int x, int y, int w, int h) {
            prefs.setPanelRect(x, y, w, h);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        main = new Handler(Looper.getMainLooper());
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        recognizer = new Recognizer();
        templateFile = new File(getFilesDir(), "templates.bin");
        if (templateFile.exists()) {
            try (FileInputStream in = new FileInputStream(templateFile)) {
                recognizer.load(in);
            } catch (IOException e) {
                // калибровку просто придётся сделать заново
            }
        }
        engine = new UciEngine(new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so"));
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // события не нужны: служба используется только ради снимков экрана и жестов
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        shutdown();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        shutdown();
        instance = null;
        super.onDestroy();
    }

    private void shutdown() {
        hideOverlays();
        if (engine != null) engine.close();
    }

    public boolean stockfishPresent() {
        return new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so").exists();
    }

    private void buildOverlays() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float d = dm.density;
        int[] gr = prefs.gridRect();
        int gl;
        int gt;
        int gs;
        if (gr == null) {
            gs = dm.widthPixels - Math.round(48 * d);
            gl = Math.round(24 * d);
            gt = Math.max(0, (dm.heightPixels - gs) / 2);
        } else {
            gl = gr[0];
            gt = gr[1];
            gs = gr[2];
        }
        grid = new GridOverlay(this, wm, gl, gt, gs, new GridOverlay.Listener() {
            @Override
            public void onBoardMoved(int left, int top, int size) {
                prefs.setGridRect(left, top, size);
            }
        });
        grid.setLinesInPlay(prefs.gridInPlay());

        int[] pr = prefs.panelRect();
        int px;
        int py;
        int pw;
        int ph;
        if (pr == null) {
            px = Math.round(8 * d);
            py = Math.round(24 * d);
            pw = dm.widthPixels - Math.round(16 * d);
            ph = Math.round(200 * d);
        } else {
            px = pr[0];
            py = pr[1];
            pw = pr[2];
            ph = pr[3];
        }
        panel = new PanelOverlay(this, wm, prefs, new PanelListener(), px, py, pw, ph);
        AndroidScreen screen = new AndroidScreen(this, grid, main, uiSink);
        controller = new GameController(screen, engine, recognizer, uiSink, templateFile);
    }

    /** Показать окна (вызывается при открытии приложения). */
    public void showOverlays() {
        if (panel == null || grid == null) buildOverlays();
        panel.show();
        grid.show();
        panel.setGridEditing(grid.isEditing());
        if (!stockfishPresent()) {
            uiSink.log("ВНИМАНИЕ: в приложение не встроен Stockfish (libstockfish.so). Игра невозможна, пока вы не положите его в app/src/main/jniLibs/arm64-v8a/ и не пересоберёте приложение.");
        }
        if (!recognizer.isCalibrated()) {
            uiSink.log("Сначала калибровка: на доске должна быть начальная расстановка.");
        }
    }

    public void hideOverlays() {
        if (controller != null) controller.stop();
        if (panel != null) panel.hide();
        if (grid != null) grid.hide();
    }

    public boolean overlaysShown() {
        return panel != null && panel.isShown();
    }
}
