package fish.chess;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Где лежит Stockfish в приложении: быстрая версия для процессоров с dotprod (если есть) и обычная. */
public final class EngineFiles {
    private EngineFiles() {
    }

    /** Файлы движка по убыванию предпочтения (только существующие). Если ничего нет - обычное имя, чтобы показать понятную ошибку. */
    public static File[] candidates(String nativeLibDir) {
        File dir = new File(nativeLibDir);
        List<File> out = new ArrayList<>();
        File dp = new File(dir, "libstockfish_dp.so");
        File plain = new File(dir, "libstockfish.so");
        if (dp.exists() && cpuHasDotprod()) out.add(dp);
        out.add(plain);
        return out.toArray(new File[0]);
    }

    public static boolean present(String nativeLibDir) {
        File dir = new File(nativeLibDir);
        return new File(dir, "libstockfish.so").exists() || new File(dir, "libstockfish_dp.so").exists();
    }

    static boolean cpuHasDotprod() {
        try (BufferedReader br = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Features") && line.contains("asimddp")) return true;
            }
        } catch (IOException e) {
            // нет доступа - используем обычную версию
        }
        return false;
    }
}
