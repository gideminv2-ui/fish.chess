package fish.chess.game;

import fish.chess.vision.BoardImage;

/** Экран, на котором лежит доска. Все координаты - в клетках от левого верхнего угла доски (центр клетки col,row = col+0.5,row+0.5). */
public interface BoardScreen {
    /** Снимок области доски; null при неудаче. Блокирующий вызов. */
    BoardImage capture() throws InterruptedException;

    /** Автоматически точно совместить сетку с доской по снимку экрана. true, если доска найдена. */
    boolean alignGrid() throws InterruptedException;

    /** Короткое описание положения сетки и того, что может перекрывать доску (для сообщений об ошибках). */
    String diagnose();

    /** Нажатие. true, если жест выполнен. */
    boolean tap(double x, double y, int holdMs) throws InterruptedException;

    /** Перетаскивание. true, если жест выполнен. */
    boolean drag(double x1, double y1, double x2, double y2, int durationMs) throws InterruptedException;
}
