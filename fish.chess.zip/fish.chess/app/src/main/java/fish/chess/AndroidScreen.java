package fish.chess;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import fish.chess.game.BoardScreen;
import fish.chess.game.UiSink;
import fish.chess.ui.GridOverlay;
import fish.chess.vision.BoardImage;
import fish.chess.vision.BoardLocator;

/** Реальный экран телефона: снимок области под сеткой и жесты через службу специальных возможностей. */
final class AndroidScreen implements BoardScreen {
    private static final long MIN_SHOT_FLOOR_MS = 340;

    private final AccessibilityService svc;
    private final GridOverlay grid;
    private final Handler main;
    private final UiSink ui;
    private final Executor cbExec = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "fish-shot");
            t.setDaemon(true);
            return t;
        }
    });
    private long lastShot = 0;
    /** Минимальный интервал между снимками: подстраивается под ограничение конкретной версии Android. */
    private long minShotMs = MIN_SHOT_FLOOR_MS;
    private int okStreak = 0;
    private long lastWarn = 0;

    AndroidScreen(AccessibilityService svc, GridOverlay grid, Handler main, UiSink ui) {
        this.svc = svc;
        this.grid = grid;
        this.main = main;
        this.ui = ui;
    }

    private void warnRateLimited(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastWarn > 10000) {
            lastWarn = now;
            ui.log(msg);
        }
    }

    @Override
    public BoardImage capture() throws InterruptedException {
        boolean hide = grid.linesVisible();
        if (hide) {
            grid.setSuppressLines(true);
            Thread.sleep(150);
        }
        try {
            int[] rect = grid.boardRect();
            return captureRegion(rect[0], rect[1], rect[2], rect[2], true, new int[2]);
        } finally {
            if (hide) grid.setSuppressLines(false);
        }
    }

    /** Находит доску под приблизительно поставленной сеткой и точно совмещает с ней сетку. */
    @Override
    public boolean alignGrid() throws InterruptedException {
        int[] rect = grid.boardRect();
        DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        BoardImage region;
        int[] origin = new int[2];
        grid.setHideAll(true);
        try {
            Thread.sleep(180);
            // весь экран: доска может лежать где угодно (на chess.com она занимает всю ширину)
            region = captureRegion(0, 0, dm.widthPixels, dm.heightPixels, false, origin);
        } finally {
            grid.setHideAll(false);
        }
        if (region == null) return false;
        BoardLocator.Result r = BoardLocator.locateAny(region.pixels, region.w, region.h, rect[0] - origin[0], rect[1] - origin[1], rect[2]);
        if (r == null) return false;
        grid.setBoardRect(origin[0] + r.left, origin[1] + r.top, r.size);
        return true;
    }

    private BoardImage captureRegion(int x, int y, int w, int h, boolean strict, int[] origin) throws InterruptedException {
        for (int attempt = 0; attempt < 4; attempt++) {
            long wait = minShotMs - (System.currentTimeMillis() - lastShot);
            if (wait > 0) Thread.sleep(wait);
            lastShot = System.currentTimeMillis();
            int[] err = new int[1];
            BoardImage img = shoot(err, x, y, w, h, strict, origin);
            if (img != null) {
                if (++okStreak >= 15 && minShotMs > MIN_SHOT_FLOOR_MS) {
                    minShotMs = Math.max(MIN_SHOT_FLOOR_MS, minShotMs - 20);
                    okStreak = 0;
                }
                return img;
            }
            if (err[0] != AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                if (err[0] != 0) warnRateLimited("Снимок экрана не получен (код " + err[0] + ").");
                break;
            }
            // система просит реже: увеличиваем интервал
            minShotMs = Math.min(1100, minShotMs + 200);
            okStreak = 0;
            Thread.sleep(minShotMs);
        }
        return null;
    }

    private BoardImage shoot(final int[] errOut, final int x, final int y, final int w, final int h, final boolean strict, final int[] origin)
            throws InterruptedException {
        final BoardImage[] out = new BoardImage[1];
        final CountDownLatch latch = new CountDownLatch(1);
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, cbExec, new AccessibilityService.TakeScreenshotCallback() {
                @Override
                public void onSuccess(AccessibilityService.ScreenshotResult result) {
                    try {
                        out[0] = convert(result, x, y, w, h, strict, origin);
                    } catch (Throwable t) {
                        errOut[0] = -2;
                    } finally {
                        latch.countDown();
                    }
                }

                @Override
                public void onFailure(int errorCode) {
                    errOut[0] = errorCode;
                    latch.countDown();
                }
            });
        } catch (RuntimeException e) {
            errOut[0] = -1;
            return null;
        }
        if (!latch.await(4, TimeUnit.SECONDS)) {
            errOut[0] = -3;
            return null;
        }
        return out[0];
    }

    private BoardImage convert(AccessibilityService.ScreenshotResult result, int x, int y, int w, int h, boolean strict, int[] origin) {
        HardwareBuffer hb = result.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
            if (hw == null) return null;
            Bitmap soft = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            if (soft == null) return null;
            try {
                int bw = soft.getWidth();
                int bh = soft.getHeight();
                if (strict && (x < -2 || y < -2 || x + w > bw + 2 || y + h > bh + 2)) {
                    warnRateLimited("Сетка выходит за пределы экрана - сдвиньте её на доску целиком.");
                    return null;
                }
                int x0 = Math.max(0, x);
                int y0 = Math.max(0, y);
                int cw = Math.min(bw, x + w) - x0;
                int ch = Math.min(bh, y + h) - y0;
                if (cw < 64 || ch < 64) return null;
                origin[0] = x0;
                origin[1] = y0;
                int[] px = new int[cw * ch];
                soft.getPixels(px, 0, cw, x0, y0, cw, ch);
                return new BoardImage(px, cw, ch);
            } finally {
                soft.recycle();
            }
        } finally {
            hb.close();
        }
    }

    // ------------------------------------------------------------------- жесты

    private float clampX(float v) {
        DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        return Math.max(1f, Math.min(dm.widthPixels - 2f, v));
    }

    private float clampY(float v) {
        DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        return Math.max(1f, Math.min(dm.heightPixels - 2f, v));
    }

    private float px(double cells, int[] rect, boolean horizontal) {
        double v = (horizontal ? rect[0] : rect[1]) + cells * rect[2] / 8.0;
        return horizontal ? clampX((float) v) : clampY((float) v);
    }

    @Override
    public boolean tap(double x, double y, int holdMs) throws InterruptedException {
        int[] rect = grid.boardRect();
        Path p = new Path();
        p.moveTo(px(x, rect, true), px(y, rect, false));
        return dispatch(new GestureDescription.StrokeDescription(p, 0, Math.max(1, holdMs)));
    }

    @Override
    public boolean drag(double x1, double y1, double x2, double y2, int durationMs) throws InterruptedException {
        int[] rect = grid.boardRect();
        Path p = new Path();
        p.moveTo(px(x1, rect, true), px(y1, rect, false));
        p.lineTo(px(x2, rect, true), px(y2, rect, false));
        return dispatch(new GestureDescription.StrokeDescription(p, 0, Math.max(100, durationMs)));
    }

    private boolean dispatch(GestureDescription.StrokeDescription stroke) throws InterruptedException {
        final GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = new boolean[1];
        main.post(new Runnable() {
            @Override
            public void run() {
                boolean accepted = svc.dispatchGesture(gesture, new AccessibilityService.GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        ok[0] = true;
                        latch.countDown();
                    }

                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        latch.countDown();
                    }
                }, null);
                if (!accepted) latch.countDown();
            }
        });
        latch.await(4, TimeUnit.SECONDS);
        return ok[0];
    }
}
