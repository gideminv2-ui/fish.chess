package fish.chess;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import fish.chess.game.BoardScreen;
import fish.chess.game.UiSink;
import fish.chess.ui.GridOverlay;
import fish.chess.vision.BoardImage;

/** Реальный экран телефона: снимок области под сеткой и жесты через службу специальных возможностей. */
final class AndroidScreen implements BoardScreen {
    private static final long MIN_SHOT_INTERVAL_MS = 450;

    private final AccessibilityService svc;
    private final GridOverlay grid;
    private final Handler main;
    private final UiSink ui;
    private final Executor cbExec = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "fish-shot");
            t.setDaemon(true);
            return t;
        }
    });
    private long lastShot = 0;
    private long lastWarn = 0;

    AndroidScreen(AccessibilityService svc, GridOverlay grid, Handler main, UiSink ui) {
        this.svc = svc;
        this.grid = grid;
        this.main = main;
        this.ui = ui;
    }

    private void warnRateLimited(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastWarn > 10000) {
            lastWarn = now;
            ui.log(msg);
        }
    }

    @Override
    public BoardImage capture() throws InterruptedException {
        boolean hide = grid.linesVisible();
        if (hide) {
            grid.setSuppressLines(true);
            Thread.sleep(150);
        }
        try {
            for (int attempt = 0; attempt < 4; attempt++) {
                long wait = MIN_SHOT_INTERVAL_MS - (System.currentTimeMillis() - lastShot);
                if (wait > 0) Thread.sleep(wait);
                lastShot = System.currentTimeMillis();
                int[] err = new int[1];
                BoardImage img = shoot(err);
                if (img != null) return img;
                if (err[0] != AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
                    if (err[0] != 0) warnRateLimited("Снимок экрана не получен (код " + err[0] + ").");
                    break;
                }
                Thread.sleep(700);
            }
            return null;
        } finally {
            if (hide) grid.setSuppressLines(false);
        }
    }

    private BoardImage shoot(final int[] errOut) throws InterruptedException {
        final int[] rect = grid.boardRect();
        final BoardImage[] out = new BoardImage[1];
        final CountDownLatch latch = new CountDownLatch(1);
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, cbExec, new AccessibilityService.TakeScreenshotCallback() {
                @Override
                public void onSuccess(AccessibilityService.ScreenshotResult result) {
                    try {
                        out[0] = convert(result, rect);
                    } catch (Throwable t) {
                        errOut[0] = -2;
                    } finally {
                        latch.countDown();
                    }
                }

                @Override
                public void onFailure(int errorCode) {
                    errOut[0] = errorCode;
                    latch.countDown();
                }
            });
        } catch (RuntimeException e) {
            errOut[0] = -1;
            return null;
        }
        if (!latch.await(4, TimeUnit.SECONDS)) {
            errOut[0] = -3;
            return null;
        }
        return out[0];
    }

    private BoardImage convert(AccessibilityService.ScreenshotResult result, int[] rect) {
        HardwareBuffer hb = result.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
            if (hw == null) return null;
            Bitmap soft = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            if (soft == null) return null;
            try {
                int bw = soft.getWidth();
                int bh = soft.getHeight();
                int left = rect[0];
                int top = rect[1];
                int size = rect[2];
                if (left < -2 || top < -2 || left + size > bw + 2 || top + size > bh + 2) {
                    warnRateLimited("Сетка выходит за пределы экрана - сдвиньте её на доску целиком.");
                    return null;
                }
                int x0 = Math.max(0, left);
                int y0 = Math.max(0, top);
                int w = Math.min(bw, left + size) - x0;
                int h = Math.min(bh, top + size) - y0;
                if (w < 64 || h < 64) return null;
                int[] px = new int[w * h];
                soft.getPixels(px, 0, w, x0, y0, w, h);
                return new BoardImage(px, w, h);
            } finally {
                soft.recycle();
            }
        } finally {
            hb.close();
        }
    }

    // ------------------------------------------------------------------- жесты

    private float clampX(float v) {
        DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        return Math.max(1f, Math.min(dm.widthPixels - 2f, v));
    }

    private float clampY(float v) {
        DisplayMetrics dm = svc.getResources().getDisplayMetrics();
        return Math.max(1f, Math.min(dm.heightPixels - 2f, v));
    }

    private float px(double cells, int[] rect, boolean horizontal) {
        double v = (horizontal ? rect[0] : rect[1]) + cells * rect[2] / 8.0;
        return horizontal ? clampX((float) v) : clampY((float) v);
    }

    @Override
    public boolean tap(double x, double y, int holdMs) throws InterruptedException {
        int[] rect = grid.boardRect();
        Path p = new Path();
        p.moveTo(px(x, rect, true), px(y, rect, false));
        return dispatch(new GestureDescription.StrokeDescription(p, 0, Math.max(1, holdMs)));
    }

    @Override
    public boolean drag(double x1, double y1, double x2, double y2, int durationMs) throws InterruptedException {
        int[] rect = grid.boardRect();
        Path p = new Path();
        p.moveTo(px(x1, rect, true), px(y1, rect, false));
        p.lineTo(px(x2, rect, true), px(y2, rect, false));
        return dispatch(new GestureDescription.StrokeDescription(p, 0, Math.max(100, durationMs)));
    }

    private boolean dispatch(GestureDescription.StrokeDescription stroke) throws InterruptedException {
        final GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = new boolean[1];
        main.post(new Runnable() {
            @Override
            public void run() {
                boolean accepted = svc.dispatchGesture(gesture, new AccessibilityService.GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        ok[0] = true;
                        latch.countDown();
                    }

                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        latch.countDown();
                    }
                }, null);
                if (!accepted) latch.countDown();
            }
        });
        latch.await(4, TimeUnit.SECONDS);
        return ok[0];
    }
}
