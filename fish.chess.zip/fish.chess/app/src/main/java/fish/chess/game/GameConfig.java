package fish.chess.game;

/** Настройки партии (снимок на момент старта). */
public final class GameConfig {
    public boolean ourWhite = true;
    /** Белые внизу экрана (иначе доска перевёрнута). */
    public boolean whiteAtBottom = true;
    public int thinkMs = 1000;
    /** true - перетаскивать фигуру, false - нажать на клетку "откуда", затем "куда". */
    public boolean dragMode = false;
    public int skill = 20;
    public int threads = 2;
    public int hashMb = 64;
    /** После хода на последнюю горизонталь ещё раз нажать (выбор фигуры в окошке превращения). */
    public boolean promoTap = true;
    /** При старте с середины партии: сейчас ход наш (иначе соперника). */
    public boolean midgameOurTurn = true;
    public int pollMs = 700;
    public int stableMs = 350;
    public int verifyMs = 450;
    /** Сколько всего ждать, пока наш ход появится на экране (доску могут на время перекрыть окна). */
    public int verifyTotalMs = 7000;
    public int tapGapMs = 220;
    public int promoWaitMs = 500;
}
