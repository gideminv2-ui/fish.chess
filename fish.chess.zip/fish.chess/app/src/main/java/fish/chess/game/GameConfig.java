package fish.chess.game;

/** Настройки партии (снимок на момент старта). */
public final class GameConfig {
    public boolean ourWhite = true;
    /** Белые внизу экрана (иначе доска перевёрнута). */
    public boolean whiteAtBottom = true;
    public int thinkMs = 1000;
    /** true - перетаскивать фигуру, false - нажать на клетку "откуда", затем "куда". */
    public boolean dragMode = false;
    public int skill = 20;
    public int threads = 2;
    public int hashMb = 64;
    /** После хода на последнюю горизонталь ещё раз нажать (выбор фигуры в окошке превращения). */
    public boolean promoTap = true;
    /** Старт с середины партии: 0 - определить автоматически, 1 - сейчас ход наш, 2 - ход соперника. */
    public int midgameTurn = 0;
    /** Сколько ждать ход соперника, если очередь хода определить не удалось. */
    public int guessWaitMs = 6000;
    public int pollMs = 700;
    public int stableMs = 350;
    public int verifyMs = 450;
    /** Сколько всего ждать, пока наш ход появится на экране (доску могут на время перекрыть окна). */
    public int verifyTotalMs = 4000;
    public int tapGapMs = 220;
    public int promoWaitMs = 500;
    /** Сколько удерживать касание и как долго тянуть фигуру в режиме перетаскивания. */
    public int tapHoldMs = 60;
    public int dragMs = 280;
    /** Ход соперника, который в точности совпал с экраном, принимается сразу, без повторного снимка. */
    public boolean fastAccept = false;

    /** Скорость работы: 0 - обычно, 1 - быстро, 2 - молния (для игры с часами). */
    public static void applySpeed(GameConfig c, int level) {
        switch (level) {
            case 2:
                c.pollMs = 120; c.stableMs = 80; c.verifyMs = 120; c.tapGapMs = 40; c.promoWaitMs = 200;
                c.tapHoldMs = 30; c.dragMs = 110; c.fastAccept = true;
                break;
            case 1:
                c.pollMs = 250; c.stableMs = 150; c.verifyMs = 200; c.tapGapMs = 90; c.promoWaitMs = 300;
                c.tapHoldMs = 40; c.dragMs = 160; c.fastAccept = true;
                break;
            default:
                c.pollMs = 700; c.stableMs = 350; c.verifyMs = 450; c.tapGapMs = 220; c.promoWaitMs = 500;
                c.tapHoldMs = 60; c.dragMs = 280; c.fastAccept = false;
                break;
        }
    }
}
