package fish.chess.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;

/**
 * Прозрачная сетка 8x8 поверх других приложений. Окно чуть больше самой доски: по краям запас под ручки.
 * В режиме "правка" сетку можно двигать (перетаскивать внутри) и менять размер (за круглые ручки по углам).
 * В режиме "игра" окно не перехватывает касания, внутри доски ничего не рисуется (чтобы не мешать распознаванию),
 * а тонкая рамка находится снаружи доски.
 */
public final class GridOverlay {
    public interface Listener {
        void onBoardMoved(int left, int top, int size);
    }

    private final Context ctx;
    private final WindowManager wm;
    private final Listener listener;
    private final float density;
    private final int margin;
    private final int handleR;
    private final int screenW;
    private final int screenH;

    private GridView view;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;
    private volatile boolean editing = true;
    private volatile boolean linesInPlay = false;
    private volatile boolean suppress = false;
    private volatile int bLeft;
    private volatile int bTop;
    private volatile int bSize;
    private int offX = 0;
    private int offY = 0;

    public GridOverlay(Context ctx, WindowManager wm, int left, int top, int size, Listener listener) {
        this.ctx = ctx;
        this.wm = wm;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        this.margin = Math.round(32 * density);
        this.handleR = Math.round(14 * density);
        this.screenW = ctx.getResources().getDisplayMetrics().widthPixels;
        this.screenH = ctx.getResources().getDisplayMetrics().heightPixels;
        this.bLeft = left;
        this.bTop = top;
        this.bSize = size;
    }

    private int flags() {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!editing) f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        return f;
    }

    public void show() {
        if (attached) return;
        view = new GridView(ctx);
        lp = new WindowManager.LayoutParams(
                bSize + 2 * margin, bSize + 2 * margin,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags(), PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = bLeft - margin;
        lp.y = bTop - margin;
        lp.alpha = editing ? 1f : 0.8f;
        wm.addView(view, lp);
        attached = true;
        final ViewTreeObserver vto = view.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (view != null && view.getWidth() > 0) {
                    view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    measureOffset();
                }
            }
        });
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(view);
        } catch (RuntimeException ignored) {
            // окно уже снято
        }
        attached = false;
        view = null;
    }

    public boolean isShown() {
        return attached;
    }

    /** Разница между реальным положением окна на экране и значениями lp.x/lp.y (обычно 0). */
    private void measureOffset() {
        if (!attached || view == null || view.getWidth() <= 0) return;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        int nx = loc[0] - lp.x;
        int ny = loc[1] - lp.y;
        if (nx != offX || ny != offY) {
            offX = nx;
            offY = ny;
            applyLayout();
        }
    }

    private void applyLayout() {
        if (!attached || view == null) return;
        lp.width = bSize + 2 * margin;
        lp.height = bSize + 2 * margin;
        lp.x = bLeft - margin - offX;
        lp.y = bTop - margin - offY;
        wm.updateViewLayout(view, lp);
        view.invalidate();
    }

    private void setBoard(int left, int top, int size) {
        bLeft = left;
        bTop = top;
        bSize = size;
        applyLayout();
    }

    public void setEditing(boolean e) {
        editing = e;
        if (attached && view != null) {
            lp.flags = flags();
            lp.alpha = e ? 1f : 0.8f;
            wm.updateViewLayout(view, lp);
            view.invalidate();
        }
    }

    public boolean isEditing() {
        return editing;
    }

    public void setLinesInPlay(boolean v) {
        linesInPlay = v;
        if (view != null) view.postInvalidate();
    }

    /** Линии внутри доски сейчас рисуются (значит, на время снимка их надо скрыть). */
    public boolean linesVisible() {
        return editing || linesInPlay;
    }

    public void setSuppressLines(boolean s) {
        suppress = s;
        if (view != null) view.postInvalidate();
    }

    /** {left, top, size} доски в пикселях экрана. */
    public int[] boardRect() {
        return new int[]{bLeft, bTop, bSize};
    }

    private final class GridView extends View {
        private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint darkLine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lightLine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handleFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handleStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int mode = 0;
        private float downX;
        private float downY;
        private int sLeft;
        private int sTop;
        private int sSize;

        GridView(Context c) {
            super(c);
            framePaint.setStyle(Paint.Style.STROKE);
            framePaint.setStrokeWidth(2 * density);
            darkLine.setStyle(Paint.Style.STROKE);
            darkLine.setStrokeWidth(2f * density);
            darkLine.setColor(0x66000000);
            lightLine.setStyle(Paint.Style.STROKE);
            lightLine.setStrokeWidth(1f * density);
            lightLine.setColor(0xCCFFFFFF);
            handleFill.setStyle(Paint.Style.FILL);
            handleFill.setColor(0xCC00E5FF);
            handleStroke.setStyle(Paint.Style.STROKE);
            handleStroke.setStrokeWidth(2 * density);
            handleStroke.setColor(0xFF004D5A);
        }

        private float[] cornerCentre(int corner) {
            float s = bSize;
            float m = margin;
            float r = handleR;
            switch (corner) {
                case 0:
                    return new float[]{m - r, m - r};
                case 1:
                    return new float[]{m + s + r, m - r};
                case 2:
                    return new float[]{m - r, m + s + r};
                default:
                    return new float[]{m + s + r, m + s + r};
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float m = margin;
            float s = bSize;
            float inset = 3 * density;
            framePaint.setColor(editing ? 0xFF00E5FF : 0xFF00E676);
            c.drawRect(m - inset, m - inset, m + s + inset, m + s + inset, framePaint);
            if ((editing || linesInPlay) && !suppress) {
                c.drawRect(m, m, m + s, m + s, darkLine);
                c.drawRect(m, m, m + s, m + s, lightLine);
                for (int i = 1; i < 8; i++) {
                    float p = s * i / 8f;
                    c.drawLine(m + p, m, m + p, m + s, darkLine);
                    c.drawLine(m + p, m, m + p, m + s, lightLine);
                    c.drawLine(m, m + p, m + s, m + p, darkLine);
                    c.drawLine(m, m + p, m + s, m + p, lightLine);
                }
            }
            if (editing) {
                for (int i = 0; i < 4; i++) {
                    float[] ctr = cornerCentre(i);
                    c.drawCircle(ctr[0], ctr[1], handleR, handleFill);
                    c.drawCircle(ctr[0], ctr[1], handleR, handleStroke);
                }
            }
        }

        private int hitTest(float x, float y) {
            for (int i = 0; i < 4; i++) {
                float[] ctr = cornerCentre(i);
                if (Math.hypot(x - ctr[0], y - ctr[1]) <= handleR * 1.6) return 2 + i;
            }
            return 1;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!editing) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    mode = hitTest(e.getX(), e.getY());
                    downX = e.getRawX();
                    downY = e.getRawY();
                    sLeft = bLeft;
                    sTop = bTop;
                    sSize = bSize;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    if (mode == 1) {
                        setBoard(Math.round(sLeft + dx), Math.round(sTop + dy), sSize);
                    } else if (mode >= 2) {
                        int corner = mode - 2;
                        boolean left = (corner == 0 || corner == 2);
                        boolean top = (corner == 0 || corner == 1);
                        float ax = left ? sLeft + sSize : sLeft;
                        float ay = top ? sTop + sSize : sTop;
                        float cx = (left ? sLeft : sLeft + sSize) + dx;
                        float cy = (top ? sTop : sTop + sSize) + dy;
                        int size = Math.round(Math.max(Math.abs(cx - ax), Math.abs(cy - ay)));
                        int minSize = Math.round(120 * density);
                        int maxSize = Math.max(screenW, screenH);
                        size = Math.max(minSize, Math.min(maxSize, size));
                        int nl = left ? Math.round(ax) - size : Math.round(ax);
                        int nt = top ? Math.round(ay) - size : Math.round(ay);
                        setBoard(nl, nt, size);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    mode = 0;
                    if (listener != null) listener.onBoardMoved(bLeft, bTop, bSize);
                    return true;
                default:
                    return true;
            }
        }
    }
}
