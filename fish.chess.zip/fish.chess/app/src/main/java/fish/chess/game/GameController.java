package fish.chess.game;

import fish.chess.chess.Board;
import fish.chess.chess.Move;
import fish.chess.chess.Openings;
import fish.chess.chess.Tracker;
import fish.chess.engine.EngineResult;
import fish.chess.engine.UciEngine;
import fish.chess.vision.BoardImage;
import fish.chess.vision.PositionBuilder;
import fish.chess.vision.Recognizer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Главный цикл: читает доску с экрана -> понимает, что сыграл соперник -> спрашивает Stockfish ->
 * делает ход жестами -> проверяет по экрану, что ход состоялся.
 * Бот сам не останавливается: любая неудача (экран не совпал, ход не принят, сбой движка) приводит к
 * перечитыванию доски и продолжению партии. Остановка - только кнопкой «Стоп», концом партии или отсутствием движка.
 */
public final class GameController {
    /** Сколько подряд опросов экрана с непонятной позицией терпим, прежде чем считать доску заново. */
    private static final int RESYNC_POLLS = 14;
    private static final int OK = 1;
    private static final int UNCHANGED = 0;
    private static final int MISMATCH = -1;
    /** Сколько раз подряд ход может не пройти, прежде чем мы решим, что площадка его не принимает. */
    private static final int BAN_AFTER = 3;

    private final BoardScreen screen;
    private final UciEngine engine;
    private final Recognizer rec;
    private final UiSink ui;

    private Thread worker;
    /** Явный флаг остановки: прерывание потока само по себе может потеряться (его иногда "съедают" библиотеки). */
    private volatile boolean stopRequested = false;
    private volatile Board current;
    /** Ход соперника, замеченный уже во время проверки нашего хода. */
    private Move pendingOpp;

    // ---- состояние партии
    private Board pos;
    private String startFen;
    private final List<String> moves = new ArrayList<>();
    private final Map<String, Integer> seen = new HashMap<>();
    private final Set<String> banned = new HashSet<>();
    private final Map<String, Integer> moveFails = new HashMap<>();
    private Integer expected;
    private String lastOpening;
    private int lastMaterial;
    private boolean repetitionWarned;

    private static final class Opp {
        final Move move;
        final Board resync;
        final boolean timedOut;

        Opp(Move move, Board resync, boolean timedOut) {
            this.move = move;
            this.resync = resync;
            this.timedOut = timedOut;
        }
    }

    /** Рассинхронизация с экраном: восстанавливаемся, а не останавливаемся. */
    private static final class Desync extends RuntimeException {
        private static final long serialVersionUID = 1L;

        Desync(String message) {
            super(message);
        }
    }

    /** Неустранимая проблема (нет движка): только тут бот останавливается сам. */
    private static final class Fatal extends RuntimeException {
        private static final long serialVersionUID = 1L;

        Fatal(String message) {
            super(message);
        }
    }

    /** Сообщает о результате калибровки (вызывается в рабочем потоке). */
    public interface CalibrationListener {
        void onCalibrated(int good);
    }

    /** Подбирает из сохранённых тем ту, что лучше всего читает текущую доску (и загружает её). */
    public interface ThemePicker {
        void pick(BoardImage img, boolean whiteAtBottom);
    }

    private ThemePicker themePicker;

    public void setThemePicker(ThemePicker picker) {
        this.themePicker = picker;
    }

    public GameController(BoardScreen screen, UciEngine engine, Recognizer rec, UiSink ui) {
        this.screen = screen;
        this.engine = engine;
        this.rec = rec;
        this.ui = ui;
    }

    public Board currentPosition() {
        return current;
    }

    public synchronized boolean isRunning() {
        return worker != null && worker.isAlive();
    }

    public synchronized boolean start(final GameConfig cfg) {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                runGame(cfg);
            }
        }, "fish-game");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    public synchronized void stop() {
        stopRequested = true;
        if (worker != null) worker.interrupt();
    }

    private void pause(long ms) throws InterruptedException {
        if (stopRequested) throw new InterruptedException();
        Thread.sleep(ms);
        if (stopRequested) throw new InterruptedException();
    }

    /** Калибровка в отдельном потоке. */
    public synchronized boolean calibrate(final GameConfig cfg, final CalibrationListener listener) {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ui.status("Калибровка…");
                    int good = calibrateNow(cfg);
                    if (good == 32) {
                        ui.log("Калибровка: распознано 32 из 32 фигур.");
                    } else if (good >= 0) {
                        ui.log("Калибровка: верно распознано лишь " + good + " из 32 фигур. Проверьте: на доске должна быть начальная расстановка, "
                                + "в настройках верно выбраны цвет и ориентация доски, а сетка лежит на доске целиком. Затем повторите.");
                    }
                    if (good >= 0 && listener != null) listener.onCalibrated(good);
                } catch (InterruptedException e) {
                    ui.log("Калибровка прервана.");
                } finally {
                    ui.status("Готов");
                }
            }
        }, "fish-calibrate");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    /** Автовыравнивание сетки в отдельном потоке (кнопка «Выровнять»). */
    public synchronized boolean align() {
        if (isRunning()) return false;
        stopRequested = false;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ui.status("Выравниваю сетку…");
                    alignAndReport();
                } catch (InterruptedException e) {
                    ui.log("Прервано.");
                } finally {
                    ui.status("Готов");
                }
            }
        }, "fish-align");
        worker.setDaemon(true);
        worker.start();
        return true;
    }

    private boolean alignAndReport() throws InterruptedException {
        boolean ok = screen.alignGrid();
        ui.log(ok ? "Сетка выровнена по доске."
                : "Не удалось найти доску под сеткой: положите сетку на доску (хотя бы приблизительно, в пределах ~половины клетки) и повторите.");
        return ok;
    }

    /** Синхронная калибровка (для потока калибровки и тестов). Возвращает число верных фигур из 32 или -1 при неудаче снимка. */
    public int calibrateNow(GameConfig cfg) throws InterruptedException {
        alignAndReport();
        BoardImage img = screen.capture();
        if (img == null) {
            ui.log("Не удалось сделать снимок экрана. Включена ли служба специальных возможностей fish.chess?");
            return -1;
        }
        return rec.learn(img, cfg.whiteAtBottom);
    }

    // ------------------------------------------------------------------ партия

    private void runGame(GameConfig cfg) {
        ui.running(true);
        try {
            play(cfg);
        } catch (InterruptedException e) {
            ui.log("Остановлено.");
        } catch (Fatal e) {
            ui.log(e.getMessage());
        } catch (RuntimeException e) {
            ui.log("Внутренняя ошибка: " + e);
        } finally {
            engine.close();
            ui.status("Остановлено");
            ui.running(false);
        }
    }

    private void resetGameState() {
        pos = null;
        startFen = null;
        moves.clear();
        seen.clear();
        banned.clear();
        moveFails.clear();
        expected = null;
        lastOpening = null;
        lastMaterial = Integer.MIN_VALUE;
        repetitionWarned = false;
        pendingOpp = null;
    }

    /** Принять позицию, считанную с экрана, как новую точку отсчёта. */
    private void adopt(Board b) {
        pos = b;
        startFen = b.fen();
        moves.clear();
        seen.clear();
        banned.clear();
        moveFails.clear();
        expected = null;
        pendingOpp = null;
        current = b;
    }

    private void play(GameConfig cfg) throws InterruptedException {
        ui.status("Ищу доску…");
        if (!screen.alignGrid()) ui.log("Не удалось автоматически выровнять сетку - использую её как есть.");
        if (themePicker != null) {
            BoardImage img = screen.capture();
            if (img != null) themePicker.pick(img, cfg.whiteAtBottom);
        }
        if (!rec.isCalibrated()) {
            ui.log("Нет выбранной темы фигур. Откройте ⚙, поставьте начальную позицию и нажмите «Калибровка» (или выберите сохранённую тему).");
            return;
        }
        ui.status("Запускаю Stockfish…");
        String err = engine.start(cfg.threads, cfg.hashMb, cfg.skill);
        if (err != null) {
            ui.log(err);
            return;
        }
        engine.newGame();
        resetGameState();
        establishPosition(cfg);

        int failStreak = 0;
        final long base = Math.max(20L, cfg.pollMs * 2L);
        while (true) {
            if (stopRequested || Thread.interrupted()) throw new InterruptedException();
            try {
                if (gameFinished(cfg)) return;
                if (pos.whiteToMove == cfg.ourWhite) ourMove(cfg);
                else opponentMove(cfg);
                failStreak = 0;
            } catch (Desync e) {
                failStreak++;
                if (failStreak <= 3 || failStreak % 5 == 0) ui.log(e.getMessage());
                pause(Math.min(base * 6, base * failStreak));
                recover(cfg);
            } catch (Fatal e) {
                throw e;
            } catch (RuntimeException e) {
                failStreak++;
                if (failStreak <= 3 || failStreak % 5 == 0) ui.log("Сбой: " + e + " - продолжаю.");
                pause(Math.min(base * 6, base * failStreak));
                recover(cfg);
            }
        }
    }

    /** Определяет позицию в начале игры (с любого момента партии). Не сдаётся: повторяет, пока не получится или не нажмут «Стоп». */
    private void establishPosition(GameConfig cfg) throws InterruptedException {
        int attempts = 0;
        while (true) {
            ui.status("Читаю доску…");
            Recognizer.Detail d = readDetailStable(cfg);
            String problem;
            if (d == null) {
                problem = "нет снимка экрана (включена ли служба специальных возможностей?)";
            } else if (Board.initial().cost(d.codes) <= Tracker.CONFIRMED) {
                pos = Board.initial();
                startFen = null;
                current = pos;
                ui.log("Новая партия. Мы играем " + (cfg.ourWhite ? "белыми" : "чёрными") + ".");
                return;
            } else {
                boolean whiteToMove;
                String how;
                boolean guessWait = false;
                if (cfg.midgameTurn == 1) {
                    whiteToMove = cfg.ourWhite;
                    how = "по настройке";
                } else if (cfg.midgameTurn == 2) {
                    whiteToMove = !cfg.ourWhite;
                    how = "по настройке";
                } else {
                    int lm = PositionBuilder.lastMover(d);
                    if (lm != 0) {
                        whiteToMove = lm < 0;
                        how = "по подсветке последнего хода";
                    } else {
                        whiteToMove = !cfg.ourWhite;
                        guessWait = true;
                        how = "подсветка не найдена";
                    }
                }
                PositionBuilder.Built built = PositionBuilder.build(d, whiteToMove);
                if (built.board != null) {
                    pos = built.board;
                    startFen = pos.fen();
                    current = pos;
                    ui.log("Партия продолжается с текущей позиции. Ход " + (pos.whiteToMove ? "белых" : "чёрных") + " (" + how + ").");
                    if (guessWait && pos.whiteToMove != cfg.ourWhite) guessTurn(cfg);
                    return;
                }
                problem = built.problem;
            }
            attempts++;
            if (attempts == 1 || attempts % 5 == 0) ui.log("Не получается считать позицию: " + problem + ". Пробую снова…");
            pause(Math.max(50L, cfg.pollMs * 3L));
            if (attempts % 3 == 0) screen.alignGrid();
        }
    }

    /** Очередь хода неизвестна: ждём. Пойдёт соперник - значит, ход был его; не пойдёт - ходим мы. */
    private void guessTurn(GameConfig cfg) throws InterruptedException {
        ui.status("Определяю, чей ход…");
        ui.log("Чей ход, определить не удалось: жду " + Math.max(1, cfg.guessWaitMs / 1000) + " с. Если соперник пойдёт - ход был его, иначе ходим мы.");
        Opp o = waitOpponent(cfg, pos, cfg.guessWaitMs);
        if (o.timedOut) {
            Recognizer.Detail d2 = readDetailStable(cfg);
            PositionBuilder.Built b2 = d2 == null ? null : PositionBuilder.build(d2, cfg.ourWhite);
            if (b2 != null && b2.board != null) {
                pos = b2.board;
                startFen = pos.fen();
                current = pos;
            } else {
                ui.log("Считать позицию заново не удалось, продолжаю с прежней.");
            }
            ui.log("Соперник не ходит - считаю, что ход наш.");
            // если ход всё же не наш, нас поправит обычное восстановление
            if (pos.whiteToMove != cfg.ourWhite) {
                Board flipped = Board.fromRecognition(pos.sq, cfg.ourWhite);
                if (flipped != null) {
                    pos = flipped;
                    startFen = pos.fen();
                    current = pos;
                }
            }
        } else if (o.resync != null) {
            pos = o.resync;
            startFen = pos.fen();
            current = pos;
        } else {
            pendingOpp = o.move;
        }
    }

    /** Перечитать позицию с экрана и продолжить партию с неё. */
    private void recover(GameConfig cfg) throws InterruptedException {
        screen.alignGrid(); // доска могла сдвинуться или измениться в размере
        Recognizer.Detail d = readDetailStable(cfg);
        if (d == null) return;
        int lm = PositionBuilder.lastMover(d);
        boolean wtm = lm != 0 ? lm < 0 : pos.whiteToMove;
        PositionBuilder.Built b = PositionBuilder.build(d, wtm);
        if (b.board == null) {
            ui.log("Пока не получается считать позицию: " + b.problem + ".");
            return;
        }
        if (pos.cost(b.board.sq) <= 1.5f) return; // экран и так совпадает с отслеживаемой позицией
        adopt(b.board);
        ui.log("Синхронизация: позицию считал с экрана заново. Ход " + (pos.whiteToMove ? "белых" : "чёрных") + ".");
    }

    /** true - партия действительно закончилась. */
    private boolean gameFinished(GameConfig cfg) throws InterruptedException {
        List<Move> legal = pos.legalMoves();
        if (legal.isEmpty() || pos.insufficientMaterial()) {
            // подтверждаем по экрану: случайная ошибка распознавания не должна заканчивать партию
            Recognizer.Detail d = readDetailStable(cfg);
            if (d != null) {
                PositionBuilder.Built b = PositionBuilder.build(d, pos.whiteToMove);
                if (b.board == null || pos.cost(b.board.sq) > 2.0f) {
                    throw new Desync("Конец партии не подтверждается экраном - перечитываю позицию.");
                }
            }
            if (legal.isEmpty()) {
                if (pos.inCheck()) {
                    boolean weWon = pos.whiteToMove != cfg.ourWhite;
                    ui.log(weWon ? "Мат! Мы победили." : "Нам поставили мат.");
                } else {
                    ui.log("Пат - ничья.");
                }
            } else {
                ui.log("Ничья: недостаточно материала для мата.");
            }
            return true;
        }
        String key = pos.positionKey();
        Integer times = seen.get(key);
        times = times == null ? 1 : times + 1;
        seen.put(key, times);
        if (times >= 3 && !repetitionWarned) {
            repetitionWarned = true;
            ui.log("Позиция повторилась трижды (по правилам это ничья, если площадка засчитает).");
        }
        return false;
    }

    private void ourMove(GameConfig cfg) throws InterruptedException {
        List<Move> legal = pos.legalMoves();
        List<String> allowed = null;
        if (!banned.isEmpty()) {
            allowed = new ArrayList<>();
            for (Move m : legal) if (!banned.contains(m.uci())) allowed.add(m.uci());
            if (allowed.isEmpty()) {
                banned.clear();
                allowed = null;
            }
        }
        ui.status("Думаю…");
        EngineResult res = think(cfg, allowed);
        Move mv = pos.parseUci(res.best);
        if (mv == null) throw new Desync("Stockfish предложил недопустимый ход " + res.best + " - перечитываю позицию с экрана.");
        if (expected != null && res.hasScore() && Math.abs(res.score()) < 90000 && Math.abs(expected) < 90000) {
            int swing = res.score() - expected;
            if (swing >= 150) {
                ui.log("   Соперник ошибся: оценка выросла с " + Commentary.signed(expected) + " до " + Commentary.signed(res.score()) + ".");
            } else if (swing <= -150) {
                ui.log("   Сильный ответ соперника: оценка упала с " + Commentary.signed(expected) + " до " + Commentary.signed(res.score()) + ".");
            }
            expected = null;
        }
        String san = pos.san(mv, legal);
        Board after = pos.apply(mv);
        boolean firstTry = !moveFails.containsKey(pos.positionKey() + " " + mv.uci());
        if (firstTry) {
            ui.log(Commentary.moveLabel(pos) + " мы: " + san + Commentary.flavor(pos, mv, after) + " | " + Commentary.evalText(res));
            String plan = Commentary.pvSan(pos, res.pv, 6);
            if (!plan.isEmpty()) ui.log("   линия: " + plan);
        }
        int outcome = executeAndVerify(cfg, pos, mv, after);
        if (outcome == OK) {
            moves.add(mv.uci());
            pos = after;
            current = pos;
            banned.clear();
            moveFails.clear();
            if (res.hasScore()) expected = res.score();
            announceOpening();
            announceMaterial(cfg);
        } else if (outcome == UNCHANGED) {
            String key = pos.positionKey() + " " + mv.uci();
            Integer prev = moveFails.get(key);
            int n = prev == null ? 1 : prev + 1;
            moveFails.put(key, n);
            boolean castling = Math.abs(pos.sq[mv.from]) == Board.KING && Math.abs(mv.to - mv.from) == 2;
            if (n >= BAN_AFTER || castling) {
                banned.add(mv.uci());
                ui.log("Площадка не принимает ход " + san + " - исключаю его и выберу другой.");
                if (castling) {
                    // скорее всего, права на рокировку мы угадали неверно
                    pos.castle &= pos.whiteToMove ? ~(Board.CR_WK | Board.CR_WQ) : ~(Board.CR_BK | Board.CR_BQ);
                    startFen = pos.fen();
                    moves.clear();
                }
            } else {
                ui.log("Ход не прошёл, пробую ещё раз.");
            }
            pause(Math.max(10L, cfg.pollMs));
        } else {
            throw new Desync("Экран не совпадает ни с позицией до хода, ни с ожидаемой после - перечитываю позицию с экрана.");
        }
    }

    private void opponentMove(GameConfig cfg) throws InterruptedException {
        Opp o;
        if (pendingOpp != null) {
            o = new Opp(pendingOpp, null, false);
            pendingOpp = null;
        } else {
            ui.status("Жду ход соперника…");
            o = waitOpponent(cfg, pos, 0);
        }
        if (o.resync != null) {
            adopt(o.resync);
            ui.log("Синхронизация: позицию считал с экрана заново (ход наш).");
            return;
        }
        Move om = o.move;
        String san = pos.san(om);
        Board after = pos.apply(om);
        ui.log(Commentary.moveLabel(pos) + " соперник: " + san + Commentary.flavor(pos, om, after));
        moves.add(om.uci());
        pos = after;
        current = pos;
        banned.clear();
        moveFails.clear();
        announceOpening();
        announceMaterial(cfg);
    }

    private void announceOpening() {
        if (startFen != null || moves.size() > 14) return;
        String name = Openings.name(moves);
        if (name != null && !name.equals(lastOpening)) {
            ui.log("   Дебют: " + name + ".");
            lastOpening = name;
        }
    }

    private void announceMaterial(GameConfig cfg) {
        int bal = cfg.ourWhite ? pos.materialBalance() : -pos.materialBalance();
        if (lastMaterial != Integer.MIN_VALUE && bal != lastMaterial) ui.log("   " + Commentary.material(bal) + ".");
        lastMaterial = bal;
    }

    private EngineResult think(GameConfig cfg, List<String> allowed) throws InterruptedException {
        for (int attempt = 0; attempt < 3; attempt++) {
            if (!engine.isAlive()) {
                ui.log("Перезапускаю Stockfish…");
                String err = engine.start(cfg.threads, cfg.hashMb, cfg.skill);
                if (err != null) throw new Fatal(err);
                engine.newGame();
            }
            EngineResult r = engine.bestMove(startFen, moves, cfg.thinkMs, allowed);
            if (r != null && r.best != null) return r;
            if (r != null) throw new Desync("Stockfish не нашёл ход в этой позиции - перечитываю позицию с экрана.");
        }
        throw new Desync("Stockfish не отвечает - перезапускаю его.");
    }

    // ----------------------------------------------------------- чтение экрана

    private int[] captureRecognize(GameConfig cfg) throws InterruptedException {
        if (stopRequested) throw new InterruptedException();
        BoardImage img = screen.capture();
        if (img == null) return null;
        return rec.recognize(img, cfg.whiteAtBottom);
    }

    private static int diff(int[] a, int[] b) {
        int n = 0;
        for (int i = 0; i < 64; i++) if (a[i] != b[i]) n++;
        return n;
    }

    /** Два снимка подряд с паузой, пока они не совпадут (чтобы не поймать анимацию). */
    private Recognizer.Detail readDetailStable(GameConfig cfg) throws InterruptedException {
        Recognizer.Detail prev = null;
        for (int i = 0; i < 8; i++) {
            if (stopRequested) throw new InterruptedException();
            BoardImage img = screen.capture();
            Recognizer.Detail dd = img == null ? null : rec.recognizeDetailed(img, cfg.whiteAtBottom);
            if (dd != null && prev != null && diff(prev.codes, dd.codes) <= 1) return dd;
            if (dd != null) prev = dd;
            pause(Math.max(1, cfg.stableMs));
        }
        return prev;
    }

    /** Ждёт, пока на экране не появится ход соперника. Если картинка долго необъяснима - считывает позицию заново. */
    private Opp waitOpponent(GameConfig cfg, Board pos, long timeoutMs) throws InterruptedException {
        int unclear = 0, nullReads = 0;
        boolean warned = false;
        long deadline = timeoutMs > 0 ? System.currentTimeMillis() + timeoutMs : Long.MAX_VALUE;
        while (true) {
            pause(Math.max(1, cfg.pollMs));
            if (System.currentTimeMillis() > deadline) return new Opp(null, null, true);
            int[] r = captureRecognize(cfg);
            if (r == null) {
                if (++nullReads == 5) ui.log("Не получается сделать снимок экрана (экран выключен?)…");
                continue;
            }
            nullReads = 0;
            if (pos.cost(r) <= Tracker.UNCHANGED) {
                unclear = 0;
                warned = false;
                continue;
            }
            Tracker.Match mt = Tracker.findMatch(pos, r);
            Move m1 = mt == null ? null : mt.move;
            if (m1 != null && cfg.fastAccept && mt.cost <= 0.01f) return new Opp(m1, null, false);
            if (m1 != null) {
                pause(Math.max(1, cfg.stableMs));
                int[] r2 = captureRecognize(cfg);
                if (r2 != null && m1.equals(Tracker.findMove(pos, r2))) return new Opp(m1, null, false);
                continue;
            }
            unclear++;
            if (unclear == 5) screen.alignGrid();
            if (unclear == 8 && !warned) {
                warned = true;
                ui.log("Позиция на экране не совпадает с партией (доска закрыта? идёт анимация? сдвинута сетка?). Если так и останется - считаю позицию заново.");
            }
            if (unclear >= RESYNC_POLLS) {
                Recognizer.Detail d = null;
                BoardImage img = screen.capture();
                if (img != null) d = rec.recognizeDetailed(img, cfg.whiteAtBottom);
                if (d != null) {
                    int lm = PositionBuilder.lastMover(d);
                    PositionBuilder.Built b = PositionBuilder.build(d, lm != 0 ? lm < 0 : cfg.ourWhite);
                    if (b.board != null) {
                        pause(Math.max(1, cfg.stableMs));
                        int[] r2 = captureRecognize(cfg);
                        if (r2 != null && diff(d.codes, r2) <= 1) return new Opp(null, b.board, false);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ ход жестами

    private static int[] cellOf(int sq, boolean whiteAtBottom) {
        int file = sq % 8, rank = sq / 8;
        return new int[]{whiteAtBottom ? file : 7 - file, whiteAtBottom ? 7 - rank : rank};
    }

    private boolean performGesture(GameConfig cfg, Move mv) throws InterruptedException {
        int[] f = cellOf(mv.from, cfg.whiteAtBottom);
        int[] t = cellOf(mv.to, cfg.whiteAtBottom);
        boolean ok;
        if (cfg.dragMode) {
            ok = screen.drag(f[0] + 0.5, f[1] + 0.5, t[0] + 0.5, t[1] + 0.5, cfg.dragMs);
        } else {
            ok = screen.tap(f[0] + 0.5, f[1] + 0.5, cfg.tapHoldMs);
            pause(Math.max(1, cfg.tapGapMs));
            ok &= screen.tap(t[0] + 0.5, t[1] + 0.5, cfg.tapHoldMs);
        }
        if (mv.promo != 0 && cfg.promoTap) {
            pause(Math.max(1, cfg.promoWaitMs));
            int order = "qnrb".indexOf("??nbrq".charAt(mv.promo));
            double dir = (t[1] == 0) ? 1.0 : -1.0;
            screen.tap(t[0] + 0.5, t[1] + 0.5 + dir * order, cfg.tapHoldMs);
        }
        return ok;
    }

    /** Делает ход и ждёт подтверждения на экране: OK - ход состоялся, UNCHANGED - экран прежний, MISMATCH - экран стал другим. */
    private int executeAndVerify(GameConfig cfg, Board before, Move mv, Board after) throws InterruptedException {
        ui.status("Хожу…");
        if (!performGesture(cfg, mv)) {
            ui.log("Жест не выполнен - проверьте, включена ли служба специальных возможностей.");
        }
        int[] last = null;
        long deadline = System.currentTimeMillis() + Math.max(1000, cfg.verifyTotalMs);
        while (System.currentTimeMillis() < deadline) {
            pause(Math.max(1, cfg.verifyMs));
            int[] r = captureRecognize(cfg);
            if (r == null) continue;
            last = r;
            if (Tracker.confirms(before, after, r)) return OK;
            // соперник мог ответить так быстро, что мы уже видим его ход
            Tracker.Match omm = Tracker.findMatch(after, r);
            Move om = omm == null ? null : omm.move;
            if (om != null && cfg.fastAccept && omm.cost <= 0.01f) {
                pendingOpp = om;
                return OK;
            }
            if (om != null) {
                pause(Math.max(1, cfg.stableMs));
                int[] r2 = captureRecognize(cfg);
                if (r2 != null && om.equals(Tracker.findMove(after, r2))) {
                    pendingOpp = om;
                    return OK;
                }
            }
        }
        if (last == null || before.cost(last) <= Tracker.UNCHANGED) return UNCHANGED;
        return MISMATCH;
    }
}
