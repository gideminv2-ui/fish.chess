package fish.chess.vision;

import fish.chess.chess.Board;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

/**
 * Распознавание шахматной доски на картинке без нейросети и без заранее известных картинок фигур.
 * <p>
 * Как это работает:
 * 1) Калибровка: пока на доске начальная расстановка, мы знаем, какая фигура на какой клетке, и запоминаем
 * силуэты всех 12 фигур и яркость белых/чёрных (поэтому подойдёт любая площадка и любой набор фигур).
 * 2) Распознавание: для каждой клетки оценивается цвет фона по краю клетки, выделяется силуэт фигуры
 * (всё, что не фон), цвет определяется по яркости, тип - по сходству силуэта с запомненными (с допуском на сдвиг).
 * Круглые небольшие пятна (точки-подсказки возможных ходов) за фигуры не считаются.
 * Ошибки отдельных клеток потом гасятся сопоставлением с легальными ходами (см. Tracker).
 */
public final class Recognizer {
    public static final int NS = 32;
    private static final double INSET = 0.07;
    private static final int RING = 3;
    private static final int T_FG = 48;
    private static final int LUM_DIFF = T_FG / 2;
    private static final int LUM_PCT = 75;
    private static final float EMPTY_FILL = 0.14f;
    private static final float MIN_SCORE = 0.40f;
    private static final int SHIFT = 2;
    private static final double CORNER = 6.0;
    private static final float DOT_AREA = 0.60f;
    private static final int DOT_MAXDIM = 14;
    private static final int C0 = NS / 4, C1 = NS - NS / 4;
    private static final int MAGIC = 0x46534833; // "FSH3" (с картами яркости)
    private static final int MAGIC_V2 = 0x46534832; // "FSH2" (старые темы: без карт яркости)

    private static final boolean[] RING_MASK = new boolean[NS * NS];
    private static final boolean[] CORNER_KEEP = new boolean[NS * NS];

    static {
        for (int i = 0; i < NS; i++) {
            for (int j = 0; j < NS; j++) {
                RING_MASK[i * NS + j] = i < RING || i >= NS - RING || j < RING || j >= NS - RING;
                boolean keep = true;
                int[][] corners = {{0, 0}, {0, NS - 1}, {NS - 1, 0}, {NS - 1, NS - 1}};
                for (int[] c : corners) {
                    if (Math.hypot(i - c[0], j - c[1]) < CORNER) keep = false;
                }
                CORNER_KEEP[i * NS + j] = keep;
            }
        }
    }

    /** Признаки одной клетки. */
    private static final class Feat {
        boolean[] mask = new boolean[NS * NS];
        float lum;
        float centerFill;
        float bgR, bgG, bgB;
        float[] lumPix = new float[NS * NS];
        int area;
        int bw, bh;
        float fillRatio;
    }

    private float[][] tmpl; // 12 x (NS*NS): белые P,N,B,R,Q,K, затем чёрные
    private float lumThr = 128f;
    private float pawnArea = 300f;
    private boolean calibrated = false;
    private final float[] lightBg = new float[3];
    private final float[] darkBg = new float[3];
    private boolean hasBg = false;
    private float[][] lumMap; // 12 x (NS*NS): средняя яркость пикселей фигуры каждого вида
    private boolean hasLumMap = false;
    private static final float HL_T = 40f;

    public synchronized boolean isCalibrated() {
        return calibrated;
    }

    private static int idx(int code) {
        return code > 0 ? code - 1 : 5 - code;
    }

    // -------------------------------------------------------------- признаки

    private static void cropSquare(int[] px, int w, int h, double x0, double y0, double x1, double y1, float[] out) {
        int[] xa = new int[NS], xb = new int[NS], ya = new int[NS], yb = new int[NS];
        for (int j = 0; j < NS; j++) {
            double a = x0 + (x1 - x0) * j / NS, b = x0 + (x1 - x0) * (j + 1) / NS;
            int ia = (int) Math.floor(a + 0.5), ib = (int) Math.floor(b + 0.5);
            if (ib < ia + 1) ib = ia + 1;
            int ca = Math.min(Math.max(ia, 0), w - 1);
            xa[j] = ca;
            xb[j] = Math.min(Math.max(ib, ca + 1), w);
            a = y0 + (y1 - y0) * j / NS;
            b = y0 + (y1 - y0) * (j + 1) / NS;
            ia = (int) Math.floor(a + 0.5);
            ib = (int) Math.floor(b + 0.5);
            if (ib < ia + 1) ib = ia + 1;
            ca = Math.min(Math.max(ia, 0), h - 1);
            ya[j] = ca;
            yb[j] = Math.min(Math.max(ib, ca + 1), h);
        }
        for (int i = 0; i < NS; i++) {
            for (int j = 0; j < NS; j++) {
                long sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int y = ya[i]; y < yb[i]; y++) {
                    int base = y * w;
                    for (int x = xa[j]; x < xb[j]; x++) {
                        int p = px[base + x];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                        n++;
                    }
                }
                int o = (i * NS + j) * 3;
                out[o] = (float) sr / n;
                out[o + 1] = (float) sg / n;
                out[o + 2] = (float) sb / n;
            }
        }
    }

    private static int medianOfRing(float[] crop, int ch) {
        int n = 0;
        int[] v = new int[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            if (RING_MASK[k]) v[n++] = Math.round(crop[k * 3 + ch]);
        }
        Arrays.sort(v, 0, n);
        return v[n / 2];
    }

    private static Feat features(float[] crop) {
        int bgR = medianOfRing(crop, 0), bgG = medianOfRing(crop, 1), bgB = medianOfRing(crop, 2);
        float[] diff = new float[NS * NS];
        boolean[] fg0 = new boolean[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            diff[k] = Math.abs(crop[k * 3] - bgR) + Math.abs(crop[k * 3 + 1] - bgG) + Math.abs(crop[k * 3 + 2] - bgB);
            fg0[k] = diff[k] > T_FG;
        }
        // заливка фона от границы клетки
        boolean[] outside = new boolean[NS * NS];
        int[] queue = new int[NS * NS];
        int qh = 0, qt = 0;
        for (int k = 0; k < NS * NS; k++) {
            if (RING_MASK[k] && !fg0[k]) {
                outside[k] = true;
                queue[qt++] = k;
            }
        }
        while (qh < qt) {
            int k = queue[qh++];
            int i = k / NS, j = k % NS;
            if (i > 0) qt = push(queue, qt, outside, fg0, k - NS);
            if (i < NS - 1) qt = push(queue, qt, outside, fg0, k + NS);
            if (j > 0) qt = push(queue, qt, outside, fg0, k - 1);
            if (j < NS - 1) qt = push(queue, qt, outside, fg0, k + 1);
        }
        Feat f = new Feat();
        for (int k = 0; k < NS * NS; k++) f.lumPix[k] = 0.299f * crop[k * 3] + 0.587f * crop[k * 3 + 1] + 0.114f * crop[k * 3 + 2];
        f.bgR = bgR;
        f.bgG = bgG;
        f.bgB = bgB;
        int centerCount = 0, area = 0, realCount = 0;
        float[] realLum = new float[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            boolean m = !outside[k] && CORNER_KEEP[k];
            f.mask[k] = m;
            if (!m) continue;
            area++;
            int i = k / NS, j = k % NS;
            if (i >= C0 && i < C1 && j >= C0 && j < C1) centerCount++;
            if (diff[k] > LUM_DIFF) {
                realLum[realCount++] = 0.299f * crop[k * 3] + 0.587f * crop[k * 3 + 1] + 0.114f * crop[k * 3 + 2];
            }
        }
        f.area = area;
        f.centerFill = (float) centerCount / ((C1 - C0) * (C1 - C0));
        f.lum = realCount >= 8 ? percentile(realLum, realCount, LUM_PCT) : 128f;
        int minI = NS, maxI = -1, minJ = NS, maxJ = -1, cnt = 0;
        for (int i = 3; i < NS - 3; i++) {
            for (int j = 3; j < NS - 3; j++) {
                if (f.mask[i * NS + j]) {
                    cnt++;
                    if (i < minI) minI = i;
                    if (i > maxI) maxI = i;
                    if (j < minJ) minJ = j;
                    if (j > maxJ) maxJ = j;
                }
            }
        }
        if (cnt > 0) {
            f.bh = maxI - minI + 1;
            f.bw = maxJ - minJ + 1;
            f.fillRatio = (float) cnt / (f.bh * f.bw);
        }
        return f;
    }

    private static int push(int[] queue, int qt, boolean[] outside, boolean[] fg0, int k) {
        if (!outside[k] && !fg0[k]) {
            outside[k] = true;
            queue[qt++] = k;
        }
        return qt;
    }

    private static float percentile(float[] v, int n, int pct) {
        float[] a = Arrays.copyOf(v, n);
        Arrays.sort(a);
        double pos = (pct / 100.0) * (n - 1);
        int lo = (int) Math.floor(pos), hi = (int) Math.ceil(pos);
        return (float) (a[lo] + (a[hi] - a[lo]) * (pos - lo));
    }

    private Feat[] squareFeats(BoardImage img, boolean whiteAtBottom) {
        Feat[] feats = new Feat[64];
        double cw = img.w / 8.0, ch = img.h / 8.0;
        float[] crop = new float[NS * NS * 3];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                double x0 = col * cw + INSET * cw, x1 = (col + 1) * cw - INSET * cw;
                double y0 = row * ch + INSET * ch, y1 = (row + 1) * ch - INSET * ch;
                cropSquare(img.pixels, img.w, img.h, x0, y0, x1, y1, crop);
                int sq = whiteAtBottom ? (7 - row) * 8 + col : row * 8 + (7 - col);
                feats[sq] = features(crop);
            }
        }
        return feats;
    }

    // -------------------------------------------------------- сходство силуэтов

    private static float score(boolean[] mask, float[] t, int[] shiftOut) {
        float best = 0f;
        for (int dy = -SHIFT; dy <= SHIFT; dy++) {
            for (int dx = -SHIFT; dx <= SHIFT; dx++) {
                float inter = 0f, uni = 0f;
                for (int i = 0; i < NS; i++) {
                    int ti = i + dy;
                    for (int j = 0; j < NS; j++) {
                        int tj = j + dx;
                        float tv = (ti >= 0 && ti < NS && tj >= 0 && tj < NS) ? t[ti * NS + tj] : 0f;
                        if (mask[i * NS + j]) {
                            inter += tv < 1f ? tv : 1f;
                            uni += 1f;
                        } else {
                            uni += tv;
                        }
                    }
                }
                if (uni > 0f) {
                    float s = inter / uni;
                    if (s > best) {
                        best = s;
                        shiftOut[0] = dy;
                        shiftOut[1] = dx;
                    }
                }
            }
        }
        return best;
    }

    /** Подробный результат распознавания (нужен для восстановления позиции и определения подсветки последнего хода). */
    public static final class Detail {
        public final int[] codes = new int[64];
        /** Сходство силуэта с шаблонами P,N,B,R,Q,K (лучшее из двух цветов). */
        public final float[][] scores = new float[64][6];
        /** Фигура светлая (по яркости). */
        public final boolean[] white = new boolean[64];
        /** Фон клетки заметно отличается от обычного цвета клетки (подсветка хода, шах и т.п.). */
        public final boolean[] highlighted = new boolean[64];
    }

    /** Среднеквадратичное расхождение яркости фигуры с картой яркости данного класса (по общим пикселям); 1e9 - нельзя оценить. */
    private float lumDist(Feat f, int cls, int dy, int dx) {
        float[] t = tmpl[cls];
        float[] lm = lumMap[cls];
        double sum = 0;
        int n = 0;
        for (int i = 0; i < NS; i++) {
            int ti = i + dy;
            if (ti < 0 || ti >= NS) continue;
            for (int j = 0; j < NS; j++) {
                int tj = j + dx;
                if (tj < 0 || tj >= NS || !f.mask[i * NS + j] || t[ti * NS + tj] < 0.5f) continue;
                float d = f.lumPix[i * NS + j] - lm[ti * NS + tj];
                sum += d * d;
                n++;
            }
        }
        return n >= 20 ? (float) Math.sqrt(sum / n) : 1e9f;
    }

    private int[] classify(Feat[] feats) {
        return classifyDetailed(feats, null, null).codes;
    }

    /** Клетка выглядит так же, как на прошлом кадре: результат можно не пересчитывать. */
    private static boolean sameLook(Feat a, Feat b) {
        if (Math.abs(a.centerFill - b.centerFill) > 0.02f || Math.abs(a.area - b.area) > 14 || Math.abs(a.lum - b.lum) > 6f) return false;
        if (Math.abs(a.bgR - b.bgR) + Math.abs(a.bgG - b.bgG) + Math.abs(a.bgB - b.bgB) > 8f) return false;
        int diff = 0;
        for (int k = 0; k < NS * NS; k++) {
            if (a.mask[k] != b.mask[k] && ++diff > 10) return false;
        }
        return true;
    }

    private Feat[] lastFeats;
    private Detail lastDetail;
    private boolean lastWab;

    private Detail classifyDetailed(Feat[] feats, Feat[] prevFeats, Detail prev) {
        Detail d = new Detail();
        for (int sq = 0; sq < 64; sq++) {
            Feat f = feats[sq];
            if (prevFeats != null && sameLook(prevFeats[sq], f)) {
                d.codes[sq] = prev.codes[sq];
                d.white[sq] = prev.white[sq];
                d.highlighted[sq] = prev.highlighted[sq];
                System.arraycopy(prev.scores[sq], 0, d.scores[sq], 0, 6);
                continue;
            }
            if (hasBg) {
                float[] e = ((sq % 8) + (sq / 8)) % 2 == 1 ? lightBg : darkBg;
                float dev = Math.abs(f.bgR - e[0]) + Math.abs(f.bgG - e[1]) + Math.abs(f.bgB - e[2]);
                d.highlighted[sq] = dev > HL_T;
            }
            if (f.centerFill < EMPTY_FILL) {
                d.codes[sq] = Board.EMPTY;
                continue;
            }
            boolean dotLike = (f.area < DOT_AREA * pawnArea || (f.bw <= DOT_MAXDIM && f.bh <= DOT_MAXDIM))
                    && f.fillRatio > 0.62f && f.bh > 0 && (float) f.bw / f.bh > 0.75f && (float) f.bw / f.bh < 1.33f;
            if (dotLike) {
                d.codes[sq] = Board.EMPTY;
                continue;
            }
            float best = -1f;
            int bestType = 0;
            int[] bestShW = new int[2];
            int[] bestShB = new int[2];
            for (int t = 1; t <= 6; t++) {
                int[] shW = new int[2];
                int[] shB = new int[2];
                float sc = Math.max(score(f.mask, tmpl[idx(t)], shW), score(f.mask, tmpl[idx(-t)], shB));
                d.scores[sq][t - 1] = sc;
                if (sc > best) {
                    best = sc;
                    bestType = t;
                    bestShW = shW;
                    bestShB = shB;
                }
            }
            // цвет: сначала по порогу яркости, затем уточняем сравнением яркостного рисунка с картами белой и чёрной фигуры
            boolean white = f.lum > lumThr;
            if (hasLumMap && best >= MIN_SCORE) {
                float dw = lumDist(f, idx(bestType), bestShW[0], bestShW[1]);
                float db = lumDist(f, idx(-bestType), bestShB[0], bestShB[1]);
                if (dw < 1e8f && db < 1e8f && Math.abs(dw - db) >= 5f) white = dw < db;
            }
            d.white[sq] = white;
            d.codes[sq] = best >= MIN_SCORE ? (white ? bestType : -bestType) : Board.UNKNOWN;
        }
        return d;
    }

    // ------------------------------------------------------------- публичное API

    /**
     * Калибровка по начальной расстановке. Возвращает, сколько из 32 фигур после обучения распознаются верно
     * (меньше 32 - сетка плохо совмещена с доской).
     */
    public synchronized int learn(BoardImage img, boolean whiteAtBottom) {
        Feat[] feats = squareFeats(img, whiteAtBottom);
        int[] layout = Board.initial().sq;
        double[] ls = new double[3], ds = new double[3];
        int nl = 0, nd = 0;
        for (int sq = 0; sq < 64; sq++) {
            if (layout[sq] != 0) continue;
            boolean light = ((sq % 8) + (sq / 8)) % 2 == 1;
            double[] acc0 = light ? ls : ds;
            acc0[0] += feats[sq].bgR;
            acc0[1] += feats[sq].bgG;
            acc0[2] += feats[sq].bgB;
            if (light) nl++;
            else nd++;
        }
        for (int k = 0; k < 3; k++) {
            lightBg[k] = (float) (ls[k] / Math.max(1, nl));
            darkBg[k] = (float) (ds[k] / Math.max(1, nd));
        }
        hasBg = nl > 0 && nd > 0;
        float[][] acc = new float[12][NS * NS];
        float[][] lsum = new float[12][NS * NS];
        int[] cnt = new int[12];
        double sumW = 0, sumB = 0, sumPawn = 0;
        int nW = 0, nB = 0, nP = 0;
        for (int sq = 0; sq < 64; sq++) {
            int p = layout[sq];
            if (p == 0) continue;
            int i = idx(p);
            for (int k = 0; k < NS * NS; k++) {
                if (feats[sq].mask[k]) {
                    acc[i][k] += 1f;
                    lsum[i][k] += feats[sq].lumPix[k];
                }
            }
            cnt[i]++;
            if (p > 0) {
                sumW += feats[sq].lum;
                nW++;
            } else {
                sumB += feats[sq].lum;
                nB++;
            }
            if (Math.abs(p) == Board.PAWN) {
                sumPawn += feats[sq].area;
                nP++;
            }
        }
        float[][] lm = new float[12][NS * NS];
        for (int i = 0; i < 12; i++) {
            for (int k = 0; k < NS * NS; k++) {
                lm[i][k] = acc[i][k] > 0f ? lsum[i][k] / acc[i][k] : 128f;
                acc[i][k] /= Math.max(cnt[i], 1);
            }
        }
        lumMap = lm;
        hasLumMap = true;
        tmpl = acc;
        lumThr = (float) ((sumW / nW + sumB / nB) / 2.0);
        pawnArea = (float) (sumPawn / nP);
        calibrated = true;
        lastFeats = null;
        int[] got = classify(feats);
        int good = 0;
        for (int sq = 0; sq < 64; sq++) if (layout[sq] != 0 && got[sq] == layout[sq]) good++;
        return good;
    }

    /** Распознаёт доску: 64 кода (0 пусто, ±1..6 фигуры, Board.UNKNOWN). null, если калибровки ещё не было. */
    public synchronized int[] recognize(BoardImage img, boolean whiteAtBottom) {
        Detail d = recognizeDetailed(img, whiteAtBottom);
        return d == null ? null : d.codes;
    }

    public synchronized Detail recognizeDetailed(BoardImage img, boolean whiteAtBottom) {
        if (!calibrated) return null;
        Feat[] feats = squareFeats(img, whiteAtBottom);
        boolean reuse = lastFeats != null && lastWab == whiteAtBottom;
        Detail d = classifyDetailed(feats, reuse ? lastFeats : null, reuse ? lastDetail : null);
        lastFeats = feats;
        lastDetail = d;
        lastWab = whiteAtBottom;
        return d;
    }

    /** Сбросить калибровку (нет выбранной темы фигур). */
    public synchronized void reset() {
        calibrated = false;
        hasBg = false;
        hasLumMap = false;
        lastFeats = null;
        tmpl = null;
    }

    /** Короткое описание темы по цвету тёмных клеток (для подписи в списке тем). */
    public synchronized String describe() {
        if (!calibrated || !hasBg) return "";
        float r = darkBg[0] / 255f, g = darkBg[1] / 255f, b = darkBg[2] / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float delta = max - min;
        if (delta < 0.08f) return "серая доска";
        float hue;
        if (max == r) hue = 60f * (((g - b) / delta) % 6f);
        else if (max == g) hue = 60f * (((b - r) / delta) + 2f);
        else hue = 60f * (((r - g) / delta) + 4f);
        if (hue < 0) hue += 360f;
        if (hue >= 65f && hue < 170f) return "зелёная доска";
        if (hue >= 170f && hue < 265f) return "синяя доска";
        if (hue >= 265f && hue < 335f) return "фиолетовая доска";
        return "коричневая доска";
    }

    public synchronized void save(OutputStream os) throws IOException {
        DataOutputStream out = new DataOutputStream(os);
        out.writeInt(MAGIC);
        out.writeInt(NS);
        out.writeFloat(lumThr);
        out.writeFloat(pawnArea);
        out.writeBoolean(hasBg);
        for (int k = 0; k < 3; k++) out.writeFloat(lightBg[k]);
        for (int k = 0; k < 3; k++) out.writeFloat(darkBg[k]);
        for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) out.writeFloat(tmpl[i][k]);
        out.writeBoolean(hasLumMap);
        if (hasLumMap) {
            for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) out.writeFloat(lumMap[i][k]);
        }
        out.flush();
    }

    public synchronized boolean load(InputStream is) throws IOException {
        DataInputStream in = new DataInputStream(is);
        int magic = in.readInt();
        if ((magic != MAGIC && magic != MAGIC_V2) || in.readInt() != NS) return false;
        float thr = in.readFloat();
        float pa = in.readFloat();
        boolean bg = in.readBoolean();
        float[] lb = new float[3];
        float[] db = new float[3];
        for (int k = 0; k < 3; k++) lb[k] = in.readFloat();
        for (int k = 0; k < 3; k++) db[k] = in.readFloat();
        float[][] t = new float[12][NS * NS];
        for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) t[i][k] = in.readFloat();
        boolean hasLm = false;
        float[][] lm = null;
        if (magic == MAGIC) {
            hasLm = in.readBoolean();
            if (hasLm) {
                lm = new float[12][NS * NS];
                for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) lm[i][k] = in.readFloat();
            }
        }
        tmpl = t;
        lumThr = thr;
        pawnArea = pa;
        lastFeats = null;
        hasBg = bg;
        lumMap = lm;
        hasLumMap = hasLm;
        System.arraycopy(lb, 0, lightBg, 0, 3);
        System.arraycopy(db, 0, darkBg, 0, 3);
        calibrated = true;
        return true;
    }
}
