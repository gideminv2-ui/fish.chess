package fish.chess.vision;

import fish.chess.chess.Board;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

/**
 * Распознавание шахматной доски на картинке без нейросети и без заранее известных картинок фигур.
 * <p>
 * Как это работает:
 * 1) Калибровка: пока на доске начальная расстановка, мы знаем, какая фигура на какой клетке, и запоминаем
 * силуэты всех 12 фигур и яркость белых/чёрных (поэтому подойдёт любая площадка и любой набор фигур).
 * 2) Распознавание: для каждой клетки оценивается цвет фона по краю клетки, выделяется силуэт фигуры
 * (всё, что не фон), цвет определяется по яркости, тип - по сходству силуэта с запомненными (с допуском на сдвиг).
 * Круглые небольшие пятна (точки-подсказки возможных ходов) за фигуры не считаются.
 * Ошибки отдельных клеток потом гасятся сопоставлением с легальными ходами (см. Tracker).
 */
public final class Recognizer {
    public static final int NS = 32;
    private static final double INSET = 0.07;
    private static final int RING = 3;
    private static final int T_FG = 48;
    private static final int LUM_DIFF = T_FG / 2;
    private static final int LUM_PCT = 75;
    private static final float EMPTY_FILL = 0.14f;
    private static final float MIN_SCORE = 0.40f;
    private static final int SHIFT = 2;
    private static final double CORNER = 6.0;
    private static final float DOT_AREA = 0.60f;
    private static final int DOT_MAXDIM = 14;
    private static final int C0 = NS / 4, C1 = NS - NS / 4;
    private static final int MAGIC = 0x46534831; // "FSH1"

    private static final boolean[] RING_MASK = new boolean[NS * NS];
    private static final boolean[] CORNER_KEEP = new boolean[NS * NS];

    static {
        for (int i = 0; i < NS; i++) {
            for (int j = 0; j < NS; j++) {
                RING_MASK[i * NS + j] = i < RING || i >= NS - RING || j < RING || j >= NS - RING;
                boolean keep = true;
                int[][] corners = {{0, 0}, {0, NS - 1}, {NS - 1, 0}, {NS - 1, NS - 1}};
                for (int[] c : corners) {
                    if (Math.hypot(i - c[0], j - c[1]) < CORNER) keep = false;
                }
                CORNER_KEEP[i * NS + j] = keep;
            }
        }
    }

    /** Признаки одной клетки. */
    private static final class Feat {
        boolean[] mask = new boolean[NS * NS];
        float lum;
        float centerFill;
        int area;
        int bw, bh;
        float fillRatio;
    }

    private float[][] tmpl; // 12 x (NS*NS): белые P,N,B,R,Q,K, затем чёрные
    private float lumThr = 128f;
    private float pawnArea = 300f;
    private boolean calibrated = false;

    public synchronized boolean isCalibrated() {
        return calibrated;
    }

    private static int idx(int code) {
        return code > 0 ? code - 1 : 5 - code;
    }

    // -------------------------------------------------------------- признаки

    private static void cropSquare(int[] px, int w, int h, double x0, double y0, double x1, double y1, float[] out) {
        int[] xa = new int[NS], xb = new int[NS], ya = new int[NS], yb = new int[NS];
        for (int j = 0; j < NS; j++) {
            double a = x0 + (x1 - x0) * j / NS, b = x0 + (x1 - x0) * (j + 1) / NS;
            int ia = (int) Math.floor(a + 0.5), ib = (int) Math.floor(b + 0.5);
            if (ib < ia + 1) ib = ia + 1;
            int ca = Math.min(Math.max(ia, 0), w - 1);
            xa[j] = ca;
            xb[j] = Math.min(Math.max(ib, ca + 1), w);
            a = y0 + (y1 - y0) * j / NS;
            b = y0 + (y1 - y0) * (j + 1) / NS;
            ia = (int) Math.floor(a + 0.5);
            ib = (int) Math.floor(b + 0.5);
            if (ib < ia + 1) ib = ia + 1;
            ca = Math.min(Math.max(ia, 0), h - 1);
            ya[j] = ca;
            yb[j] = Math.min(Math.max(ib, ca + 1), h);
        }
        for (int i = 0; i < NS; i++) {
            for (int j = 0; j < NS; j++) {
                long sr = 0, sg = 0, sb = 0;
                int n = 0;
                for (int y = ya[i]; y < yb[i]; y++) {
                    int base = y * w;
                    for (int x = xa[j]; x < xb[j]; x++) {
                        int p = px[base + x];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                        n++;
                    }
                }
                int o = (i * NS + j) * 3;
                out[o] = (float) sr / n;
                out[o + 1] = (float) sg / n;
                out[o + 2] = (float) sb / n;
            }
        }
    }

    private static int medianOfRing(float[] crop, int ch) {
        int n = 0;
        int[] v = new int[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            if (RING_MASK[k]) v[n++] = Math.round(crop[k * 3 + ch]);
        }
        Arrays.sort(v, 0, n);
        return v[n / 2];
    }

    private static Feat features(float[] crop) {
        int bgR = medianOfRing(crop, 0), bgG = medianOfRing(crop, 1), bgB = medianOfRing(crop, 2);
        float[] diff = new float[NS * NS];
        boolean[] fg0 = new boolean[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            diff[k] = Math.abs(crop[k * 3] - bgR) + Math.abs(crop[k * 3 + 1] - bgG) + Math.abs(crop[k * 3 + 2] - bgB);
            fg0[k] = diff[k] > T_FG;
        }
        // заливка фона от границы клетки
        boolean[] outside = new boolean[NS * NS];
        int[] queue = new int[NS * NS];
        int qh = 0, qt = 0;
        for (int k = 0; k < NS * NS; k++) {
            if (RING_MASK[k] && !fg0[k]) {
                outside[k] = true;
                queue[qt++] = k;
            }
        }
        while (qh < qt) {
            int k = queue[qh++];
            int i = k / NS, j = k % NS;
            if (i > 0) qt = push(queue, qt, outside, fg0, k - NS);
            if (i < NS - 1) qt = push(queue, qt, outside, fg0, k + NS);
            if (j > 0) qt = push(queue, qt, outside, fg0, k - 1);
            if (j < NS - 1) qt = push(queue, qt, outside, fg0, k + 1);
        }
        Feat f = new Feat();
        int centerCount = 0, area = 0, realCount = 0;
        float[] realLum = new float[NS * NS];
        for (int k = 0; k < NS * NS; k++) {
            boolean m = !outside[k] && CORNER_KEEP[k];
            f.mask[k] = m;
            if (!m) continue;
            area++;
            int i = k / NS, j = k % NS;
            if (i >= C0 && i < C1 && j >= C0 && j < C1) centerCount++;
            if (diff[k] > LUM_DIFF) {
                realLum[realCount++] = 0.299f * crop[k * 3] + 0.587f * crop[k * 3 + 1] + 0.114f * crop[k * 3 + 2];
            }
        }
        f.area = area;
        f.centerFill = (float) centerCount / ((C1 - C0) * (C1 - C0));
        f.lum = realCount >= 8 ? percentile(realLum, realCount, LUM_PCT) : 128f;
        int minI = NS, maxI = -1, minJ = NS, maxJ = -1, cnt = 0;
        for (int i = 3; i < NS - 3; i++) {
            for (int j = 3; j < NS - 3; j++) {
                if (f.mask[i * NS + j]) {
                    cnt++;
                    if (i < minI) minI = i;
                    if (i > maxI) maxI = i;
                    if (j < minJ) minJ = j;
                    if (j > maxJ) maxJ = j;
                }
            }
        }
        if (cnt > 0) {
            f.bh = maxI - minI + 1;
            f.bw = maxJ - minJ + 1;
            f.fillRatio = (float) cnt / (f.bh * f.bw);
        }
        return f;
    }

    private static int push(int[] queue, int qt, boolean[] outside, boolean[] fg0, int k) {
        if (!outside[k] && !fg0[k]) {
            outside[k] = true;
            queue[qt++] = k;
        }
        return qt;
    }

    private static float percentile(float[] v, int n, int pct) {
        float[] a = Arrays.copyOf(v, n);
        Arrays.sort(a);
        double pos = (pct / 100.0) * (n - 1);
        int lo = (int) Math.floor(pos), hi = (int) Math.ceil(pos);
        return (float) (a[lo] + (a[hi] - a[lo]) * (pos - lo));
    }

    private Feat[] squareFeats(BoardImage img, boolean whiteAtBottom) {
        Feat[] feats = new Feat[64];
        double cw = img.w / 8.0, ch = img.h / 8.0;
        float[] crop = new float[NS * NS * 3];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                double x0 = col * cw + INSET * cw, x1 = (col + 1) * cw - INSET * cw;
                double y0 = row * ch + INSET * ch, y1 = (row + 1) * ch - INSET * ch;
                cropSquare(img.pixels, img.w, img.h, x0, y0, x1, y1, crop);
                int sq = whiteAtBottom ? (7 - row) * 8 + col : row * 8 + (7 - col);
                feats[sq] = features(crop);
            }
        }
        return feats;
    }

    // -------------------------------------------------------- сходство силуэтов

    private static float score(boolean[] mask, float[] t) {
        float best = 0f;
        for (int dy = -SHIFT; dy <= SHIFT; dy++) {
            for (int dx = -SHIFT; dx <= SHIFT; dx++) {
                float inter = 0f, uni = 0f;
                for (int i = 0; i < NS; i++) {
                    int ti = i + dy;
                    for (int j = 0; j < NS; j++) {
                        int tj = j + dx;
                        float tv = (ti >= 0 && ti < NS && tj >= 0 && tj < NS) ? t[ti * NS + tj] : 0f;
                        if (mask[i * NS + j]) {
                            inter += tv < 1f ? tv : 1f;
                            uni += 1f;
                        } else {
                            uni += tv;
                        }
                    }
                }
                if (uni > 0f) {
                    float s = inter / uni;
                    if (s > best) best = s;
                }
            }
        }
        return best;
    }

    private int[] classify(Feat[] feats) {
        int[] out = new int[64];
        for (int sq = 0; sq < 64; sq++) {
            Feat f = feats[sq];
            if (f.centerFill < EMPTY_FILL) {
                out[sq] = Board.EMPTY;
                continue;
            }
            boolean dotLike = (f.area < DOT_AREA * pawnArea || (f.bw <= DOT_MAXDIM && f.bh <= DOT_MAXDIM))
                    && f.fillRatio > 0.62f && f.bh > 0 && (float) f.bw / f.bh > 0.75f && (float) f.bw / f.bh < 1.33f;
            if (dotLike) {
                out[sq] = Board.EMPTY;
                continue;
            }
            boolean white = f.lum > lumThr;
            float best = -1f;
            int bestType = 0;
            for (int t = 1; t <= 6; t++) {
                float sc = Math.max(score(f.mask, tmpl[idx(t)]), score(f.mask, tmpl[idx(-t)]));
                if (sc > best) {
                    best = sc;
                    bestType = t;
                }
            }
            out[sq] = best >= MIN_SCORE ? (white ? bestType : -bestType) : Board.UNKNOWN;
        }
        return out;
    }

    // ------------------------------------------------------------- публичное API

    /**
     * Калибровка по начальной расстановке. Возвращает, сколько из 32 фигур после обучения распознаются верно
     * (меньше 32 - сетка плохо совмещена с доской).
     */
    public synchronized int learn(BoardImage img, boolean whiteAtBottom) {
        Feat[] feats = squareFeats(img, whiteAtBottom);
        int[] layout = Board.initial().sq;
        float[][] acc = new float[12][NS * NS];
        int[] cnt = new int[12];
        double sumW = 0, sumB = 0, sumPawn = 0;
        int nW = 0, nB = 0, nP = 0;
        for (int sq = 0; sq < 64; sq++) {
            int p = layout[sq];
            if (p == 0) continue;
            int i = idx(p);
            for (int k = 0; k < NS * NS; k++) if (feats[sq].mask[k]) acc[i][k] += 1f;
            cnt[i]++;
            if (p > 0) {
                sumW += feats[sq].lum;
                nW++;
            } else {
                sumB += feats[sq].lum;
                nB++;
            }
            if (Math.abs(p) == Board.PAWN) {
                sumPawn += feats[sq].area;
                nP++;
            }
        }
        for (int i = 0; i < 12; i++) {
            for (int k = 0; k < NS * NS; k++) acc[i][k] /= Math.max(cnt[i], 1);
        }
        tmpl = acc;
        lumThr = (float) ((sumW / nW + sumB / nB) / 2.0);
        pawnArea = (float) (sumPawn / nP);
        calibrated = true;
        int[] got = classify(feats);
        int good = 0;
        for (int sq = 0; sq < 64; sq++) if (layout[sq] != 0 && got[sq] == layout[sq]) good++;
        return good;
    }

    /** Распознаёт доску: 64 кода (0 пусто, ±1..6 фигуры, Board.UNKNOWN). null, если калибровки ещё не было. */
    public synchronized int[] recognize(BoardImage img, boolean whiteAtBottom) {
        if (!calibrated) return null;
        return classify(squareFeats(img, whiteAtBottom));
    }

    public synchronized void save(OutputStream os) throws IOException {
        DataOutputStream out = new DataOutputStream(os);
        out.writeInt(MAGIC);
        out.writeInt(NS);
        out.writeFloat(lumThr);
        out.writeFloat(pawnArea);
        for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) out.writeFloat(tmpl[i][k]);
        out.flush();
    }

    public synchronized boolean load(InputStream is) throws IOException {
        DataInputStream in = new DataInputStream(is);
        if (in.readInt() != MAGIC || in.readInt() != NS) return false;
        float thr = in.readFloat();
        float pa = in.readFloat();
        float[][] t = new float[12][NS * NS];
        for (int i = 0; i < 12; i++) for (int k = 0; k < NS * NS; k++) t[i][k] = in.readFloat();
        tmpl = t;
        lumThr = thr;
        pawnArea = pa;
        calibrated = true;
        return true;
    }
}
