package fish.chess.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * fish.chess v3: компактное окно с комментариями. В заголовке только самое нужное: Старт/Стоп, ⚙ (окно настроек),
 * свернуть в пузырёк и закрыть. Двигается за заголовок, размер меняется за значок ◢ (он всегда на виду).
 * Свёрнутое окно превращается в маленький пузырёк 🐟: нажмите, чтобы развернуть.
 */
public final class PanelOverlay {
    public interface Listener {
        void onStartStop();

        void onOpenControls();

        void onClose();

        void onGeometryChanged(int x, int y, int w, int h);
    }

    private static final int MAX_LOG_LINES = 160;

    private final Context ctx;
    private final WindowManager wm;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float density;

    private FrameLayout root;
    private LinearLayout content;
    private TextView statusView;
    private TextView btnStart;
    private TextView logView;
    private TextView grip;
    private TextView bubble;
    private ScrollView scroll;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;
    private boolean minimized = false;
    private int savedW;
    private int savedH;
    private final StringBuilder logBuf = new StringBuilder();
    private int logLines = 0;

    public PanelOverlay(Context ctx, WindowManager wm, Listener listener, int x, int y, int w, int h) {
        this.ctx = ctx;
        this.wm = wm;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        build();
        lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags(false), PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = x;
        lp.y = y;
    }

    private int flags(boolean keepScreenOn) {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (keepScreenOn) f |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        return f;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        return Ui.rounded(density, color, radiusDp);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, int color) {
        TextView t = text(s, 12, Ui.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        t.setBackground(rounded(color, 10));
        return t;
    }

    private void build() {
        root = new FrameLayout(ctx);
        root.setBackground(rounded(Ui.BG, 16));

        content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(6), dp(8), dp(6));
        root.addView(content, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // заголовок: перетаскивание окна + самые нужные кнопки
        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(ctx);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("🐟 fish.chess v3", 13, Ui.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        statusView = text("Готов", 11, 0xFF7DD3FC);
        statusView.setMaxLines(1);
        left.addView(title);
        left.addView(statusView);
        header.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnStart = button("▶ Старт", Ui.ACCENT);
        btnStart.setTypeface(Typeface.DEFAULT_BOLD);
        TextView btnControls = button("⚙", Ui.CHIP);
        TextView btnMin = button("–", Ui.CHIP);
        TextView btnClose = button("✕", Ui.CHIP);
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(dp(80), dp(34));
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(dp(34), dp(34));
        sp1.leftMargin = dp(4);
        sp2.leftMargin = dp(4);
        header.addView(btnStart, sp1);
        header.addView(btnControls, sp2);
        header.addView(btnMin, sp2);
        header.addView(btnClose, sp2);
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });
        content.addView(header);

        scroll = new ScrollView(ctx);
        logView = text("Нажмите ⚙: там тема фигур, калибровка и настройки. Затем ▶ Старт.", 12, 0xFFDDE6EE);
        logView.setPadding(dp(6), dp(5), dp(6), dp(40));
        scroll.addView(logView);
        scroll.setBackground(rounded(0x40000000, 10));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sl.topMargin = dp(5);
        content.addView(scroll, sl);

        // значок изменения размера: отдельный слой поверх всего, поэтому его не вытеснит содержимое
        grip = text("◢", 22, Ui.TEXT);
        grip.setGravity(Gravity.CENTER);
        grip.setBackground(rounded(0xAA3B82F6, 12));
        root.addView(grip, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END));
        grip.setOnTouchListener(new View.OnTouchListener() {
            private int startW;
            private int startH;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startW = lp.width;
                        startH = lp.height;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.width = Math.max(dp(180), startW + Math.round(e.getRawX() - downX));
                        lp.height = Math.max(dp(100), startH + Math.round(e.getRawY() - downY));
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });

        // пузырёк (свёрнутое состояние)
        bubble = text("🐟", 26, Ui.TEXT);
        bubble.setGravity(Gravity.CENTER);
        bubble.setVisibility(View.GONE);
        root.addView(bubble, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - downX) > dp(8) || Math.abs(e.getRawY() - downY) > dp(8)) moved = true;
                        if (moved) {
                            lp.x = startX + Math.round(e.getRawX() - downX);
                            lp.y = startY + Math.round(e.getRawY() - downY);
                            if (attached) wm.updateViewLayout(root, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) setMinimized(false);
                        else notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onStartStop();
            }
        });
        btnControls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onOpenControls();
            }
        });
        btnMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setMinimized(true);
            }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClose();
            }
        });
    }

    /** Положение окна на экране {x, y, w, h}. */
    public int[] screenRect() {
        return new int[]{lp.x, lp.y, lp.width, lp.height};
    }

    /** Невидимое окно не попадает в снимок экрана (нужно, если оно перекрывает доску). */
    public void setCaptureHidden(final boolean hidden) {
        main.post(new Runnable() {
            @Override
            public void run() {
                root.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
            }
        });
    }

    /**
     * Если окно перекрывает доску, убирает его: сдвигает выше или ниже доски (уменьшая высоту), а если места нет - сворачивает
     * в пузырёк в свободном углу. Вызывать в главном потоке. true - окно было перемещено.
     */
    public boolean avoidBoard(int bl, int bt, int bs, int screenW, int screenH) {
        if (!attached) return false;
        if (!(lp.x < bl + bs && lp.x + lp.width > bl && lp.y < bt + bs && lp.y + lp.height > bt)) return false;
        int gap = dp(6);
        int above = bt - gap;
        int below = screenH - (bt + bs) - gap;
        int minH = dp(110);
        if (!minimized && above >= minH) {
            lp.height = Math.min(lp.height, above);
            lp.y = Math.max(0, bt - lp.height - gap);
        } else if (!minimized && below >= minH) {
            lp.height = Math.min(lp.height, below);
            lp.y = bt + bs + gap;
        } else {
            if (!minimized) setMinimized(true);
            lp.x = Math.max(0, screenW - dp(60));
            lp.y = above >= dp(56) ? Math.max(0, bt - dp(56)) : Math.max(0, Math.min(screenH - dp(56), bt + bs + gap));
        }
        lp.x = Math.max(0, Math.min(lp.x, Math.max(0, screenW - lp.width)));
        wm.updateViewLayout(root, lp);
        notifyGeometry();
        return true;
    }

    private void setMinimized(boolean min) {
        if (min == minimized) return;
        minimized = min;
        if (min) {
            savedW = lp.width;
            savedH = lp.height;
            content.setVisibility(View.GONE);
            grip.setVisibility(View.GONE);
            bubble.setVisibility(View.VISIBLE);
            root.setBackground(Ui.outlined(density, 0xF21A2B3D, Ui.ACCENT, 26));
            lp.width = dp(52);
            lp.height = dp(52);
        } else {
            bubble.setVisibility(View.GONE);
            content.setVisibility(View.VISIBLE);
            grip.setVisibility(View.VISIBLE);
            root.setBackground(rounded(Ui.BG, 16));
            lp.width = savedW;
            lp.height = savedH;
        }
        if (attached) wm.updateViewLayout(root, lp);
    }

    private void notifyGeometry() {
        if (minimized) return;
        listener.onGeometryChanged(lp.x, lp.y, lp.width, lp.height);
    }

    // ------------------------------------------------------------------- публичное

    public void show() {
        if (attached) return;
        wm.addView(root, lp);
        attached = true;
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(root);
        } catch (RuntimeException ignored) {
            // уже снято
        }
        attached = false;
    }

    public boolean isShown() {
        return attached;
    }

    public void appendLog(final String line) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (logLines == 0 || logBuf.length() == 0) {
                    logBuf.setLength(0);
                    logLines = 0;
                }
                logBuf.append(line).append('\n');
                logLines++;
                if (logLines > MAX_LOG_LINES) {
                    int cut = logBuf.indexOf("\n") + 1;
                    logBuf.delete(0, cut);
                    logLines--;
                }
                logView.setText(logBuf.toString());
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    public void setStatus(final String s) {
        main.post(new Runnable() {
            @Override
            public void run() {
                statusView.setText(s);
            }
        });
    }

    /** Меняет кнопку Старт/Стоп и пока идёт игра не даёт экрану погаснуть (иначе снимки экрана перестают работать). */
    public void setRunning(final boolean isRunning) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnStart.setText(isRunning ? "■ Стоп" : "▶ Старт");
                btnStart.setBackground(rounded(isRunning ? Ui.DANGER : Ui.ACCENT, 10));
                lp.flags = flags(isRunning);
                if (attached) wm.updateViewLayout(root, lp);
            }
        });
    }
}
