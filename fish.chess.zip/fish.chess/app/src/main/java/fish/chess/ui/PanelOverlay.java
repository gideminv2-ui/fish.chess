package fish.chess.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Компактное окно с комментариями к партии. В заголовке только самое нужное: Старт/Стоп, ⚙ (открыть окно настроек),
 * свернуть и закрыть. Двигается за заголовок, размер меняется за значок ◢ в правом нижнем углу (он всегда на виду).
 */
public final class PanelOverlay {
    public interface Listener {
        void onStartStop();

        void onOpenControls();

        void onClose();

        void onGeometryChanged(int x, int y, int w, int h);
    }

    private static final int MAX_LOG_LINES = 160;

    private final Context ctx;
    private final WindowManager wm;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float density;

    private FrameLayout root;
    private LinearLayout content;
    private TextView statusView;
    private TextView btnStart;
    private TextView logView;
    private TextView grip;
    private ScrollView scroll;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;
    private boolean minimized = false;
    private boolean running = false;
    private int savedHeight;
    private final StringBuilder logBuf = new StringBuilder();
    private int logLines = 0;

    public PanelOverlay(Context ctx, WindowManager wm, Listener listener, int x, int y, int w, int h) {
        this.ctx = ctx;
        this.wm = wm;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        build();
        lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags(false), PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = x;
        lp.y = y;
    }

    private int flags(boolean keepScreenOn) {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (keepScreenOn) f |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        return f;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        return d;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, int color) {
        TextView t = text(s, 12, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        t.setBackground(rounded(color, 8));
        return t;
    }

    private void build() {
        root = new FrameLayout(ctx);
        root.setBackground(rounded(0xF0101820, 12));

        content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(6), dp(4), dp(6), dp(4));
        root.addView(content, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // заголовок: перетаскивание окна + самые нужные кнопки
        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(ctx);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("fish.chess", 13, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        statusView = text("Готов", 11, 0xFF9FD8FF);
        statusView.setMaxLines(1);
        left.addView(title);
        left.addView(statusView);
        header.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnStart = button("▶ Старт", 0xFF1B5E20);
        TextView btnControls = button("⚙", 0xFF2B3C4E);
        TextView btnMin = button("—", 0xFF2B3C4E);
        TextView btnClose = button("✕", 0xFF2B3C4E);
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(dp(78), dp(34));
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(dp(34), dp(34));
        sp1.leftMargin = dp(4);
        sp2.leftMargin = dp(4);
        header.addView(btnStart, sp1);
        header.addView(btnControls, sp2);
        header.addView(btnMin, sp2);
        header.addView(btnClose, sp2);
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });
        content.addView(header);

        scroll = new ScrollView(ctx);
        logView = text("Нажмите ⚙: там тема фигур, калибровка и настройки. Затем ▶ Старт.", 12, 0xFFDDE6EE);
        logView.setPadding(dp(4), dp(4), dp(4), dp(36));
        scroll.addView(logView);
        scroll.setBackground(rounded(0x40000000, 8));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sl.topMargin = dp(4);
        content.addView(scroll, sl);

        // значок изменения размера: отдельный слой поверх всего, поэтому его не вытеснит содержимое
        grip = text("◢", 22, 0xFFFFFFFF);
        grip.setGravity(Gravity.CENTER);
        grip.setBackground(rounded(0x99456B94, 10));
        root.addView(grip, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END));
        grip.setOnTouchListener(new View.OnTouchListener() {
            private int startW;
            private int startH;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startW = lp.width;
                        startH = lp.height;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.width = Math.max(dp(180), startW + Math.round(e.getRawX() - downX));
                        lp.height = Math.max(dp(100), startH + Math.round(e.getRawY() - downY));
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onStartStop();
            }
        });
        btnControls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onOpenControls();
            }
        });
        btnMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMinimized();
            }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClose();
            }
        });
    }

    private void toggleMinimized() {
        minimized = !minimized;
        if (minimized) {
            savedHeight = lp.height;
            scroll.setVisibility(View.GONE);
            grip.setVisibility(View.GONE);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            scroll.setVisibility(View.VISIBLE);
            grip.setVisibility(View.VISIBLE);
            lp.height = savedHeight;
        }
        if (attached) wm.updateViewLayout(root, lp);
    }

    private void notifyGeometry() {
        int h = minimized ? savedHeight : lp.height;
        listener.onGeometryChanged(lp.x, lp.y, lp.width, h);
    }

    // ------------------------------------------------------------------- публичное

    public void show() {
        if (attached) return;
        wm.addView(root, lp);
        attached = true;
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(root);
        } catch (RuntimeException ignored) {
            // уже снято
        }
        attached = false;
    }

    public boolean isShown() {
        return attached;
    }

    public void appendLog(final String line) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (logLines == 0 || logBuf.length() == 0) {
                    logBuf.setLength(0);
                    logLines = 0;
                }
                logBuf.append(line).append('\n');
                logLines++;
                if (logLines > MAX_LOG_LINES) {
                    int cut = logBuf.indexOf("\n") + 1;
                    logBuf.delete(0, cut);
                    logLines--;
                }
                logView.setText(logBuf.toString());
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    public void setStatus(final String s) {
        main.post(new Runnable() {
            @Override
            public void run() {
                statusView.setText(s);
            }
        });
    }

    /** Меняет кнопку Старт/Стоп и пока идёт игра не даёт экрану погаснуть (иначе снимки экрана перестают работать). */
    public void setRunning(final boolean isRunning) {
        main.post(new Runnable() {
            @Override
            public void run() {
                running = isRunning;
                btnStart.setText(isRunning ? "■ Стоп" : "▶ Старт");
                btnStart.setBackground(rounded(isRunning ? 0xFFB71C1C : 0xFF1B5E20, 8));
                lp.flags = flags(isRunning);
                if (attached) wm.updateViewLayout(root, lp);
            }
        });
    }

    public boolean isRunningShown() {
        return running;
    }
}
