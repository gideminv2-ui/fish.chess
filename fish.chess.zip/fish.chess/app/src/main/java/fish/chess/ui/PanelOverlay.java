package fish.chess.ui;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fish.chess.Prefs;

/**
 * Небольшое окно поверх приложений: кнопки управления, настройки и комментарии к партии.
 * Двигается за заголовок, размер меняется за угловой значок внизу справа.
 */
public final class PanelOverlay {
    public interface Listener {
        void onStartStop();

        void onCalibrate();

        void onToggleGridMode();

        void onClose();

        void onSettingChanged();

        void onGeometryChanged(int x, int y, int w, int h);
    }

    private abstract class Option {
        abstract String text();

        abstract void next();
    }

    private static final int MAX_LOG_LINES = 160;

    private final Context ctx;
    private final WindowManager wm;
    private final Prefs prefs;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final float density;

    private LinearLayout root;
    private LinearLayout body;
    private LinearLayout settingsBox;
    private TextView statusView;
    private TextView btnStart;
    private TextView btnGrid;
    private TextView logView;
    private ScrollView scroll;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;
    private boolean minimized = false;
    private int savedHeight;
    private final StringBuilder logBuf = new StringBuilder();
    private int logLines = 0;

    public PanelOverlay(Context ctx, WindowManager wm, Prefs prefs, Listener listener, int x, int y, int w, int h) {
        this.ctx = ctx;
        this.wm = wm;
        this.prefs = prefs;
        this.listener = listener;
        this.density = ctx.getResources().getDisplayMetrics().density;
        build();
        lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = x;
        lp.y = y;
    }

    private int dp(float v) {
        return Math.round(v * density);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        return d;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s) {
        TextView t = text(s, 12, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(7), dp(6), dp(7));
        t.setBackground(rounded(0xFF2B3C4E, 8));
        return t;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private void build() {
        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(0xF0101820, 14));
        root.setPadding(dp(8), dp(6), dp(8), dp(4));

        // заголовок: перетаскивание окна
        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("fish.chess", 15, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView btnMin = button("—");
        TextView btnClose = button("✕");
        header.addView(btnMin, new LinearLayout.LayoutParams(dp(38), LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(dp(38), LinearLayout.LayoutParams.WRAP_CONTENT);
        cl.leftMargin = dp(4);
        header.addView(btnClose, cl);
        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });
        root.addView(header);

        body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        statusView = text("Готов", 12, 0xFF9FD8FF);
        statusView.setPadding(dp(2), dp(2), dp(2), dp(2));
        body.addView(statusView);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnStart = button("▶ Старт");
        btnStart.setBackground(rounded(0xFF1B5E20, 8));
        TextView btnCal = button("Калибровка");
        btnGrid = button("Сетка: правка");
        TextView btnSettings = button("⚙");
        row.addView(btnStart, weighted());
        row.addView(btnCal, weighted());
        row.addView(btnGrid, weighted());
        row.addView(btnSettings, new LinearLayout.LayoutParams(dp(40), LinearLayout.LayoutParams.WRAP_CONTENT));
        body.addView(row);

        settingsBox = new LinearLayout(ctx);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setVisibility(View.GONE);
        addOptionRow(
                new Option() {
                    String text() {
                        return "Мои: " + (prefs.ourWhite() ? "белые" : "чёрные");
                    }

                    void next() {
                        prefs.setOurWhite(!prefs.ourWhite());
                    }
                },
                new Option() {
                    String text() {
                        return "Доска: " + (prefs.flipped() ? "перевёрнута" : "мои снизу");
                    }

                    void next() {
                        prefs.setFlipped(!prefs.flipped());
                    }
                });
        addOptionRow(
                new Option() {
                    String text() {
                        return "Думать: " + thinkLabel(prefs.thinkMs());
                    }

                    void next() {
                        prefs.setThinkMs(nextOf(Prefs.THINK_OPTIONS, prefs.thinkMs()));
                    }
                },
                new Option() {
                    String text() {
                        return "Сила: " + prefs.skill() + (prefs.skill() == 20 ? " (макс.)" : "");
                    }

                    void next() {
                        prefs.setSkill(nextOf(Prefs.SKILL_OPTIONS, prefs.skill()));
                    }
                });
        addOptionRow(
                new Option() {
                    String text() {
                        return "Ход: " + (prefs.drag() ? "перетаскивание" : "два нажатия");
                    }

                    void next() {
                        prefs.setDrag(!prefs.drag());
                    }
                },
                new Option() {
                    String text() {
                        return "Превращение: " + (prefs.promoTap() ? "+нажатие" : "без нажатия");
                    }

                    void next() {
                        prefs.setPromoTap(!prefs.promoTap());
                    }
                });
        addOptionRow(
                new Option() {
                    String text() {
                        return "Сетка в игре: " + (prefs.gridInPlay() ? "видна" : "скрыта");
                    }

                    void next() {
                        prefs.setGridInPlay(!prefs.gridInPlay());
                    }
                },
                new Option() {
                    String text() {
                        return "Старт с середины: " + (prefs.midOurTurn() ? "ход наш" : "ход соперн.");
                    }

                    void next() {
                        prefs.setMidOurTurn(!prefs.midOurTurn());
                    }
                });
        body.addView(settingsBox);

        scroll = new ScrollView(ctx);
        logView = text("Совместите сетку с доской (двигайте и тяните за круглые ручки), расставьте начальную позицию и нажмите «Калибровка».", 12, 0xFFDDE6EE);
        logView.setPadding(dp(4), dp(4), dp(4), dp(4));
        scroll.addView(logView);
        scroll.setBackground(rounded(0x40000000, 8));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sl.topMargin = dp(4);
        body.addView(scroll, sl);

        TextView grip = text("◢", 18, 0xFF9FB3C8);
        grip.setGravity(Gravity.END);
        grip.setPadding(dp(16), dp(0), dp(2), dp(0));
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        gl.gravity = Gravity.END;
        body.addView(grip, gl);
        grip.setOnTouchListener(new View.OnTouchListener() {
            private int startW;
            private int startH;
            private float downX;
            private float downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startW = lp.width;
                        startH = lp.height;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.width = Math.max(dp(220), startW + Math.round(e.getRawX() - downX));
                        lp.height = Math.max(dp(140), startH + Math.round(e.getRawY() - downY));
                        if (attached) wm.updateViewLayout(root, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        notifyGeometry();
                        return true;
                    default:
                        return false;
                }
            }
        });

        btnMin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleMinimized();
            }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClose();
            }
        });
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onStartStop();
            }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCalibrate();
            }
        });
        btnGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onToggleGridMode();
            }
        });
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingsBox.setVisibility(settingsBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
    }

    private void addOptionRow(Option a, Option b) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(optionButton(a), weighted());
        row.addView(optionButton(b), weighted());
        settingsBox.addView(row);
    }

    private TextView optionButton(final Option opt) {
        final TextView tv = button(opt.text());
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opt.next();
                tv.setText(opt.text());
                listener.onSettingChanged();
            }
        });
        return tv;
    }

    private static String thinkLabel(int ms) {
        return ms < 1000 ? (ms / 1000.0 + " с").replace('.', ',') : (ms / 1000) + " с";
    }

    private static int nextOf(int[] options, int current) {
        for (int i = 0; i < options.length; i++) {
            if (options[i] == current) return options[(i + 1) % options.length];
        }
        return options[0];
    }

    private void toggleMinimized() {
        minimized = !minimized;
        if (minimized) {
            savedHeight = lp.height;
            body.setVisibility(View.GONE);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            body.setVisibility(View.VISIBLE);
            lp.height = savedHeight;
        }
        if (attached) wm.updateViewLayout(root, lp);
    }

    private void notifyGeometry() {
        int h = minimized ? savedHeight : lp.height;
        listener.onGeometryChanged(lp.x, lp.y, lp.width, h);
    }

    // ------------------------------------------------------------------- публичное

    public void show() {
        if (attached) return;
        wm.addView(root, lp);
        attached = true;
    }

    public void hide() {
        if (!attached) return;
        try {
            wm.removeView(root);
        } catch (RuntimeException ignored) {
            // уже снято
        }
        attached = false;
    }

    public boolean isShown() {
        return attached;
    }

    public void appendLog(final String line) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (logLines == 0 || logBuf.length() == 0) {
                    logBuf.setLength(0);
                    logLines = 0;
                }
                logBuf.append(line).append('\n');
                logLines++;
                if (logLines > MAX_LOG_LINES) {
                    int cut = logBuf.indexOf("\n") + 1;
                    logBuf.delete(0, cut);
                    logLines--;
                }
                logView.setText(logBuf.toString());
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    public void setStatus(final String s) {
        main.post(new Runnable() {
            @Override
            public void run() {
                statusView.setText(s);
            }
        });
    }

    public void setRunning(final boolean running) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnStart.setText(running ? "■ Стоп" : "▶ Старт");
                btnStart.setBackground(rounded(running ? 0xFFB71C1C : 0xFF1B5E20, 8));
            }
        });
    }

    public void setGridEditing(final boolean editing) {
        main.post(new Runnable() {
            @Override
            public void run() {
                btnGrid.setText(editing ? "Сетка: правка" : "Сетка: игра");
            }
        });
    }
}
